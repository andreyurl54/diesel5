(async function() {
	'use strict';
Lampa.Platform.tv();
Lampa.Storage.set('parser_use', true)

Lampa.Template.add('parser_style_1', '<div id="parser_style_1"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(1){color: a2a2a2!important;}</style></div>');
Lampa.Template.add('parser_style_2', '<div id="parser_style_2"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(2){color: a2a2a2!important;}</style></div>');
Lampa.Template.add('parser_style_3', '<div id="parser_style_3"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(3){color: a2a2a2!important;}</style></div>');
Lampa.Template.add('parser_style_4', '<div id="parser_style_4"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(4){color: a2a2a2!important;}</style></div>');
Lampa.Template.add('parser_style_5', '<div id="parser_style_5"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(5){color: a2a2a2!important;}</style></div>');
$('body').append(Lampa.Template.get('parser_style_1', {}, true));
$('body').append(Lampa.Template.get('parser_style_2', {}, true));
$('body').append(Lampa.Template.get('parser_style_3', {}, true));
$('body').append(Lampa.Template.get('parser_style_4', {}, true));
$('body').append(Lampa.Template.get('parser_style_5', {}, true));	  
Lampa.Template.add('parser_style_1g', '<div id="parser_style_1"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(1){color: 1aff00!important;}</style></div>');
Lampa.Template.add('parser_style_2g', '<div id="parser_style_2"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(2){color: 1aff00!important;}</style></div>');
Lampa.Template.add('parser_style_3g', '<div id="parser_style_3"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(3){color: 1aff00!important;}</style></div>');
Lampa.Template.add('parser_style_4g', '<div id="parser_style_4"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(4){color: 1aff00!important;}</style></div>');
Lampa.Template.add('parser_style_5g', '<div id="parser_style_5"><style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(5){color: 1aff00!important;}</style></div>');
 

async function CheckParserStart1(url_to_check_start) {
let url = url_to_check_start;
fetch(url)
	.then(response => $('body').append(Lampa.Template.get('parser_style_1g', {}, true)))
	.catch(err => Lampa.Platform.tv())
 }
 
 async function CheckParserStart2(url_to_check_start) {
let url = url_to_check_start;
fetch(url)
	.then(response => $('body').append(Lampa.Template.get('parser_style_2g', {}, true)))
	.catch(err => Lampa.Platform.tv())
 }

async function CheckParserStart3(url_to_check_start) {
let url = url_to_check_start;
fetch(url)
	.then(response => $('body').append(Lampa.Template.get('parser_style_3g', {}, true)))
	.catch(err => Lampa.Platform.tv())
 }
 
async function CheckParserStart4(url_to_check_start) {
let url = url_to_check_start;
fetch(url)
	.then(response => $('body').append(Lampa.Template.get('parser_style_4g', {}, true)))
	.catch(err => Lampa.Platform.tv())
 }
 
async function CheckParserStart5(url_to_check_start) {
let url = url_to_check_start;
fetch(url)
	.then(response => $('body').append(Lampa.Template.get('parser_style_5g', {}, true)))
	.catch(err => Lampa.Platform.tv())
 }

CheckParserStart1('http://jac.lampa32.ru/api/v2.0/indexers/status:healthy/results?apikey=&search=Avatar')
CheckParserStart2('http://j.yourok.ru/api/v2.0/indexers/status:healthy/results?apikey=1&search=Avatar')
CheckParserStart3('http://jacc.drstein.xyz/api/v2.0/indexers/status:healthy/results?apikey=&search=Avatar')
CheckParserStart4('http://jac.my.to/api/v2.0/indexers/status:healthy/results?apikey=&search=Avatar')
CheckParserStart5('http://spawn.pp.ua:59117/api/v2.0/indexers/status:healthy/results?apikey=2&search=Avatar')

Lampa.SettingsApi.addParam({ 
    component: 'parser', 
    param: { 
     name: 'jackett_url2',  
     type: 'select',     
     values: {      
        jac_lampa32_ru:   'jac.lampa32.ru', 
        j_yourok_ru:      'j.yourok.ru',     
        jacc_drstein_xyz: 'jacc.drstein.xyz', 
        jac_my_to:        'jac.my.to', 
		spawn_pp_ua:      'spawn.pp.ua',
     }, 
     default: 'jac_lampa32_ru'     
    }, 
    field: { 
     name: 'Общественные JACKETT',     
     description: 'Обновится после выхода из настроек'  
    }, 
    onChange: function (value) {   
     if (value == 'jac_lampa32_ru')  Lampa.Storage.set('jackett_url', 'jac.lampa32.ru')&Lampa.Storage.set('jackett_key', '')&Lampa.Storage.set('jackett_interview','healthy')&Lampa.Storage.set('parse_in_search', false); 
     if (value == 'j_yourok_ru') Lampa.Storage.set('jackett_url', 'j.yourok.ru')&Lampa.Storage.set('jackett_key', '1')&Lampa.Storage.set('jackett_interview','healthy')&Lampa.Storage.set('parse_in_search', false); 
     if (value == 'jacc_drstein_xyz') Lampa.Storage.set('jackett_url', 'jacc.drstein.xyz')&Lampa.Storage.set('jackett_key', '')&Lampa.Storage.set('jackett_interview','healthy')&Lampa.Storage.set('parse_in_search', false); 
     if (value == 'jac_my_to') Lampa.Storage.set('jackett_url', 'jac.my.to')&Lampa.Storage.set('jackett_key', '')&Lampa.Storage.set('jackett_interview','healthy')&Lampa.Storage.set('parse_in_search', false); 
     if (value == 'spawn_pp_ua') Lampa.Storage.set('jackett_url', 'spawn.pp.ua:59117')&Lampa.Storage.set('jackett_key', '2')&Lampa.Storage.set('jackett_interview','healthy')&Lampa.Storage.set('parse_in_search', false); 
     Lampa.Settings.update();        
    }, 
     onRender: function (item) { 
       setTimeout(function() { 
        $('div[data-children="parser"]').on('hover:enter', function(){ 
        Lampa.Settings.update();        
        }); 
        if(Lampa.Storage.field('parser_use')) {item.show()&$('.settings-param__name', item).css('color','f3d900')&$('div[data-name="jackett_url2"]').insertAfter('div[data-children="parser"]'); 
CheckParser(Lampa.Storage.field('jackett_url'));
}
        else item.hide(); 
          }, 0); 
        } 
   });
async function CheckParser(url_to_check) {
 var My_Jac_Key = Lampa.Storage.field('jackett_key')
 var My_Jac_Interview = Lampa.Storage.field('jackett_interview')

let url = 'http://' + url_to_check + '/api/v2.0/indexers/status:' + My_Jac_Interview + '/results?apikey=' + My_Jac_Key + '&search=Avatar';
fetch(url)
	.then(response => $('div[data-name="jackett_url2"]').append('<div><div class="settings-param__status active"></div></div>'))
	.catch(err => $('div[data-name="jackett_url2"]').append('<div><div class="settings-param__status error"></div></div>'))
 }



function updateJackett() {
	setTimeout(function(){
	var element = $(".extensions");
	var elementMODS = $('div[data-name="mods_fork"]');
	var elementParserChoice = $('div[data-name="jackett_url2"]');
	if(element.length > 0){ 
		$('#parser_style_1').remove()
		$('#parser_style_2').remove()
		$('#parser_style_3').remove()
		$('#parser_style_4').remove()
		$('#parser_style_5').remove()
	}
	if(elementMODS.length > 0){
		$('#parser_style_1').remove()
		$('#parser_style_2').remove()
		$('#parser_style_3').remove()
		$('#parser_style_4').remove()
		$('#parser_style_5').remove()
	}
	if(elementParserChoice.length > 0){
		CheckParserStart1('http://jac.lampa32.ru/api/v2.0/indexers/status:healthy/results?apikey=&search=Avatar')
		CheckParserStart2('http://j.yourok.ru/api/v2.0/indexers/status:healthy/results?apikey=1&search=Avatar')
		CheckParserStart3('http://jacc.drstein.xyz/api/v2.0/indexers/status:healthy/results?apikey=&search=Avatar')
		CheckParserStart4('http://jac.my.to/api/v2.0/indexers/status:healthy/results?apikey=&search=Avatar')
		CheckParserStart5('http://spawn.pp.ua:59117/api/v2.0/indexers/status:healthy/results?apikey=2&search=Avatar')
	}

	},0); 
}
let timerJacket;
timerJacket = setInterval(updateJackett, 500);
updateJackett();


//$('#parser_style_1').remove()
//$('#parser_style_2').remove()
 })(); 