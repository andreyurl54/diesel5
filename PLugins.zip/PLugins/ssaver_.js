(function () {
Lampa.Platform.tv(); 
 'use strict';
Lampa.Keypad.listener.follow('keydown', function (e) {
//      if (Lampa.Player.opened()) {
        if (code === 406) {
          Lampa.Storage.set('screensaver', 'false');
		  console.log ("Заставка выключена");
        } 
//        else
//		  Lampa.Storage.set('screensaver', 'true');
//		  console.log ("Заставка включена");
//      }; 
});
			})();