(function () {
Lampa.Platform.tv(); 
 'use strict';
 var mail = localStorage.getItem('account_email');
 //local
 console.log (mail);
 Lampa.Noty.show(mail);
			})();