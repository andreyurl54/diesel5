(function () {
Lampa.Platform.tv(); 
 'use strict';
 if (Lampa.Player.opened()) {
		  	if ($('body').find('.player-video__paused').hasClass('hide')) {
			//Lampa.Noty.show("Не вижу")}
			Lampa.Storage.set('screensaver', 'false');}
			else {
			//Lampa.Noty.show("Вижу")
			Lampa.Storage.set('screensaver', 'true');
			}
} 
Lampa.Keypad.listener.destroy(); 
Lampa.Keypad.listener.follow('keydown', function (e) {
	  var code = e.code;
      if (Lampa.Player.opened()) {
        if (code === 406) {
          Lampa.Storage.set('screensaver', 'false');
		  console.log ("Заставка выключена");
		  Lampa.Noty.show("Заставка выключена");
        }; 
		if (code === 405) {
          Lampa.Storage.set('screensaver', 'true');
		  console.log ("Заставка включена");
		  Lampa.Noty.show("Заставка включена");
		}; 
        }; 
      });
			})();