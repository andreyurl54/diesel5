(function() {
	'use strict';
Lampa.Platform.tv();
Lampa.Storage.set('parser_use', true)
Lampa.Template.add('default_parser_style', '<style>#app > div.settings > div.settings__content.layer--height > div.settings__body > div > div > div > div > div[data-name="jackett_url2"] > div.settings-param__name{color: f3d900!important;}</style>');
$('body').append(Lampa.Template.get('default_parser_style', {}, true));
Lampa.SettingsApi.addParam({
					component: 'parser',
					param: {
						name: 'jackett_url2', 
						type: 'select', 			
						values: {					
						   jac_lampa32_ru:   'jac.lampa32.ru',
						   j_yourok_ru:      'j.yourok.ru',    
						   jacc_drstein_xyz: 'jacc.drstein.xyz',
						   jac_my_to:        'jac.my.to',
						},
						default: 'jac_lampa32_ru'				
					},
					field: {
						name: 'Общественный JACKETT', 			
						description: 'Обновится после выхода из настроек' 
					},
					onChange: function (value) { 	
						Lampa.Settings.update();
						if (Lampa.Storage.field('jackett_url2') == 'jac_lampa32_ru') 	Lampa.Storage.set('jackett_url', 'jac.lampa32.ru')&Lampa.Storage.set('jackett_key', '')&Lampa.Storage.set('jackett_interview','healthy');
						if (Lampa.Storage.field('jackett_url2') == 'j_yourok_ru') 		Lampa.Storage.set('jackett_url', 'j.yourok.ru')&Lampa.Storage.set('jackett_key', '1')&Lampa.Storage.set('jackett_interview','healthy');
						if (Lampa.Storage.field('jackett_url2') == 'jacc_drstein_xyz') 	Lampa.Storage.set('jackett_url', 'jacc.drstein.xyz')&Lampa.Storage.set('jackett_key', '')&Lampa.Storage.set('jackett_interview','healthy');
						if (Lampa.Storage.field('jackett_url2') == 'jac_my_to') 		Lampa.Storage.set('jackett_url', 'jac.my.to')&Lampa.Storage.set('jackett_key', '')&Lampa.Storage.set('jackett_interview','healthy');
						Lampa.Settings.update();							
							$('.MyJacKid').insertAfter($('.MyJac'));
					},
				onRender: function (item) {

				}
					});

function updateJackett() {

  let date = new Date(); 
  let hours = date.getHours();
  if (hours < 10) hours = '0' + hours;
  let minutes = date.getMinutes();
  if (minutes < 10) minutes = '0' + minutes;
  let seconds = date.getSeconds();
  if (seconds < 10) seconds = '0' + seconds;
  var element0 = $('div[data-name="parser_use"]');
	if(element0.length > 0){
	setTimeout(function(){
	if (Lampa.Storage.field('parser_use') == false) { 
		$('div[data-name="jackett_url2"]').addClass('hide').addClass('MyJacKid');
		$('div[data-children="parser"]').addClass('MyJac');
		$('.MyJacKid').insertAfter($('.MyJac'));
		
		}
	if (Lampa.Storage.field('parser_use') == true) { 
		$('div[data-name="jackett_url2"]').removeClass('hide').addClass('MyJacKid'); 
		$('div[data-children="parser"]').addClass('MyJac');
		$('.MyJacKid').insertAfter($('.MyJac'));
		}
	
	},0); 
	}
}

let timerJacket;
timerJacket = setInterval(updateJackett, 300);
updateJackett(); 

})(); 