(function () {
Lampa.Platform.tv(); 
 'use strict';
 
Lampa.Template.add('timeline_style', '<style>div.player-panel{opacity: 0%!important;display: none;}</style>');
$('body').append(Lampa.Template.get('timeline_style', {}, true));


			})();