(function () {
    'use strict';	

		Lampa.Listener.follow('app',(e)=>{
        if(e.type == 'ready'){
			setTimeout(function(){
				$("[data-action=movie]").eq(0).remove();
				$("[data-action=catalog]").eq(0).remove();
				$("[data-action=tv]").eq(0).remove();
				$("[data-action=filter]").eq(0).remove();
				$("[data-action=relise]").eq(0).remove();
				$("[data-type=wath]").eq(0).remove();
				$("[data-type=history]").eq(0).remove();
				$("[data-action=subscribes]").eq(0).remove();
				$("[data-action=timetable]").eq(0).remove();
				$("[data-action=mytorrents]").eq(0).remove();
				
			},100); 
        }
    });

})();