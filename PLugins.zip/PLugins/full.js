(function () {
    'use strict';

    Lampa.Storage.set('parser_use', 'true');
    Lampa.Storage.set('parser_torrent_type', 'jackett');
    Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');
    Lampa.Storage.set('jackett_key', '1');
    Lampa.Storage.set('parse_lang', 'df_lg');
    Lampa.Storage.set('parse_in_search', 'false');
    Lampa.Storage.set('torrserver_url', 'http://to3.tsarea.us:8880');
    Lampa.Storage.set('tmdb_proxy_image', 'http://cors.pavelpgp.ru');
    var script = document.createElement ('script');
script.src = 'http://lampa32.ru/radio.js';
document.getElementsByTagName ('head')[0].appendChild (script);
    var script = document.createElement ('script');
script.src = 'http://lampa32.ru/online.js';
document.getElementsByTagName ('head')[0].appendChild (script);
    var script = document.createElement ('script');
script.src = 'http://lampa32.ru/rating.js';
document.getElementsByTagName ('head')[0].appendChild (script);
})();
