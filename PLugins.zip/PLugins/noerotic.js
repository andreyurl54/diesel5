;(function () {
    'use strict';
			setInterval(function() {
				var elementE = $('div.iptv-menu__list > div:contains("взрослые")');
				if(elementE.length > 0) elementE.hide();
			},500)
})();