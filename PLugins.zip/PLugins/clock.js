(function () {
	'use strict';
Lampa.Platform.tv(); 
//Lampa.Template.add('clock_style', '<style>.head{z-index: 555!important;}</style>');
//$('body').append(Lampa.Template.get('clock_style', {}, true));
<div class=\"head__time-now time--clock\"></div>
		Lampa.Listener.follow('app',(e)=>{
        if(e.type == 'ready'){
			setTimeout(function(){
				html('<div class=\"head__time-now time--clock\"></div>');
			},10); 
        }
    });



			})();
//$('.no-network').removeClass('hide')
//document.getElementsByTagName('body')[0].appendChild(script);