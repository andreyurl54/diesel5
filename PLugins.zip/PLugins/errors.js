(function () {
Lampa.Platform.tv(); 
 'use strict';
var mymymy_items = $('<div class="mymymy">MYMYMYTEXT</div>');
$('body').eq(0).append(mymymy_items);
//If (Lampa.Player.opened()) {
//	$('body').find('.value--speed').remove();}; 
Lampa.Template.add('head_style', '<style>.mymymy{z-index: 55!important;position: absolute}</style>');
$('body').append(Lampa.Template.get('head_style', {}, true));
//});
			})();
			
			