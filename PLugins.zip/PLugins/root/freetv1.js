(function() {
	'use strict';

//Плагин к Lampa для перключения серий клавишами пульта для ТВ LG
	//listen to button
	
	 Lampa.Keypad.listener.follow('keydown', function (e) {
      var code = e.code;
     // Lampa.Noty.show('code_ '+ code);
      if (Lampa.Player.opened()) {
        if (code === 428 || code === 34) {
          Lampa.PlayerPlaylist.prev();
          //$('body').find('.player-panel__prev.button.selector').click();
  			 // console.log ("[P- button hit]");
        } 
        if (code === 427 || code === 33) {
          Lampa.PlayerPlaylist.next();
		    	//$('body').find('.player-panel__next.button.selector').click();
  			  //console.log ("[P+ button hit]");
        } 
      } 
    });

//Стиль
	Lampa.Template.add('tv_style', '<style>#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div.activity.layer--width.activity--active > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div.card.selector.card--collection.card--loaded.focus > div.card__view > img{box-shadow: 0 0 0 0.5em #fff10d!important;}</style>');
	$('body').append(Lampa.Template.get('tv_style', {}, true));
//	Object.defineProperty(navigator, 'userAgent', {
//    get: function () { return 'http-user-agent=WINK/1.28.2 (AndroidTV/9) HlsWinkPlayer'; }});
	
	function freetv_n(object) {
		var network = new Lampa.Reguest();
		var scroll = new Lampa.Scroll({
			mask: true,
			over: true,
			step: 250
		});
		var items = [];
		var html = $('<div></div>');
		var body = $('<div class="freetv_n category-full"></div>');
		var info;
		var last;
		var cors = '';
		var catalogs = [{
        title: 'Полный список',
        url: 'http://45.15.159.227/json/all.json'
      },  {
        title: 'Общие и Новостные',
        url: 'http://45.15.159.227/json/news.json'
      },  {
        title: 'Развивающие',
        url: 'http://45.15.159.227/json/razviv.json'
      },  {
        title: 'Кино',
        url: 'http://45.15.159.227/json/cinema.json'
      },  {
        title: 'Разное',
        url: 'http://45.15.159.227/json/raznoe.json'
      },  {
        title: 'Детские',
        url: 'http://45.15.159.227/json/kids.json'
      },  {
        title: 'Спорт',
        url: 'http://45.15.159.227/json/sport.json'
      },  {
        title: 'Музыка',
        url: 'http://45.15.159.227/json/music.json'
      },  {
        title: 'Заявки',
        url: 'http://45.15.159.227/json/zayavki.json'
      },  {
        title: 'Эротика',
        url: 'http://45.15.159.227/json/erotic.json'
      },  {
        title: 'Wink',
        url: 'http://45.15.159.227/json/wink.json'
      },  {
        title: 'Регионы',
        url: 'http://45.15.159.227/json/region.json'
      },  {
        title: 'Україна',
        url: 'http://45.15.159.227/json/ua.json'
      },  {
        title: 'Беларусь',
        url: 'http://45.15.159.227/json/belarus.json'
      }];
		this.create = function() {
			var _this = this;
			this.activity.loader(true);
			network.silent(object.url, this.build.bind(this), function() {
				var empty = new Lampa.Empty();
				html.append(empty.render());
				_this.start = empty.start;
				_this.activity.loader(false);
				_this.activity.toggle();
			});
			return this.render();
		};
		this.append = function (data) {
			var _this3 = this;
			data.forEach(function (element) {
				var card = Lampa.Template.get('card', {
					title: element.name,
					release_year: ''
				});
				card.addClass('card--collection');
				card.find('.card__img').css({
					'cursor': 'pointer',
					'background-color': '#353535a6'
				});
				var img = card.find('.card__img')[0];
				img.onload = function () {
					card.addClass('card--loaded');
				};
				img.onerror = function (e) {
					img.src = './img/img_broken.svg';
				};
				img.src = element.picture;
				card.on('hover:focus', function () {
					last = card[0];
					scroll.update(card, true);
					info.find('.info__title').text(element.name);
					info.find('.info__title-original').text(element.time);
				});
				card.on('hover:enter', function () {
					var video = {
						title: element.name,
						url: element.video
					};
					Lampa.Player.play(video);
					var playlist = [];
					var i = 1;
					data.forEach(function (elem) {
						playlist.push({
							title: i + ' - ' + elem.name,
							url: elem.video
						});
						i++;
					});
					Lampa.Player.playlist(playlist);
				});
				body.append(card);
				items.push(card);
			});
		};
		this.build = function(data) {
			var _this2 = this;
			Lampa.Background.change('http://lampa.stream/r/back.jpg');
			Lampa.Template.add('button_category', "<style>@media screen and (max-width: 2560px) {.freetv_n .card--collection {width: 16.6%!important;}}@media screen and (max-width: 800px) {.freetv_n .card--collection {width: 24.6%!important;}}@media screen and (max-width: 500px) {.freetv_n .card--collection {width: 33.3%!important;}}</style><div class=\"full-start__button selector view--category\"><svg style=\"enable-background:new 0 0 512 512;\" version=\"1.1\" viewBox=\"0 0 24 24\" xml:space=\"preserve\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\"><g id=\"info\"/><g id=\"icons\"><g id=\"menu\"><path d=\"M20,10H4c-1.1,0-2,0.9-2,2c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2C22,10.9,21.1,10,20,10z\" fill=\"currentColor\"/><path d=\"M4,8h12c1.1,0,2-0.9,2-2c0-1.1-0.9-2-2-2H4C2.9,4,2,4.9,2,6C2,7.1,2.9,8,4,8z\" fill=\"currentColor\"/><path d=\"M16,16H4c-1.1,0-2,0.9-2,2c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2C18,16.9,17.1,16,16,16z\" fill=\"currentColor\"/></g></g></svg>   <span>Категории</span>\n    </div>");
			Lampa.Template.add('button_hdon', "<div style=\"position:absolute;\" class=\"full-start__button selector view--hdon\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-piggy-bank\" viewBox=\"0 0 16 16\"><path d=\"M5 6.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0zm1.138-1.496A6.613 6.613 0 0 1 7.964 4.5c.666 0 1.303.097 1.893.273a.5.5 0 0 0 .286-.958A7.602 7.602 0 0 0 7.964 3.5c-.734 0-1.441.103-2.102.292a.5.5 0 1 0 .276.962z\"/><path fill-rule=\"evenodd\" d=\"M7.964 1.527c-2.977 0-5.571 1.704-6.32 4.125h-.55A1 1 0 0 0 .11 6.824l.254 1.46a1.5 1.5 0 0 0 1.478 1.243h.263c.3.513.688.978 1.145 1.382l-.729 2.477a.5.5 0 0 0 .48.641h2a.5.5 0 0 0 .471-.332l.482-1.351c.635.173 1.31.267 2.011.267.707 0 1.388-.095 2.028-.272l.543 1.372a.5.5 0 0 0 .465.316h2a.5.5 0 0 0 .478-.645l-.761-2.506C13.81 9.895 14.5 8.559 14.5 7.069c0-.145-.007-.29-.02-.431.261-.11.508-.266.705-.444.315.306.815.306.815-.417 0 .223-.5.223-.461-.026a.95.95 0 0 0 .09-.255.7.7 0 0 0-.202-.645.58.58 0 0 0-.707-.098.735.735 0 0 0-.375.562c-.024.243.082.48.32.654a2.112 2.112 0 0 1-.259.153c-.534-2.664-3.284-4.595-6.442-4.595zM2.516 6.26c.455-2.066 2.667-3.733 5.448-3.733 3.146 0 5.536 2.114 5.536 4.542 0 1.254-.624 2.41-1.67 3.248a.5.5 0 0 0-.165.535l.66 2.175h-.985l-.59-1.487a.5.5 0 0 0-.629-.288c-.661.23-1.39.359-2.157.359a6.558 6.558 0 0 1-2.157-.359.5.5 0 0 0-.635.304l-.525 1.471h-.979l.633-2.15a.5.5 0 0 0-.17-.534 4.649 4.649 0 0 1-1.284-1.541.5.5 0 0 0-.446-.275h-.56a.5.5 0 0 1-.492-.414l-.254-1.46h.933a.5.5 0 0 0 .488-.393zm12.621-.857a.565.565 0 0 1-.098.21.704.704 0 0 1-.044-.025c-.146-.09-.157-.175-.152-.223a.236.236 0 0 1 .117-.173c.049-.027.08-.021.113.012a.202.202 0 0 1 .064.199z\"/></svg>&nbsp;<span>РџРѕРґРґРµСЂР¶Р°С‚СЊ!!</span>\n  </div>");

			
			Lampa.Template.add('info_radio', '<div class="info layer--width"><div class="info__left"><div class="info__title"></div><div class="info__title-original"></div><div class="info__create"></div></div><div class="info__right">  <div id="stantion_filtr"></div></div></div>');
			var btn = Lampa.Template.get('button_category');
			var btn2 = Lampa.Template.get('button_hdon');

			info = Lampa.Template.get('info_radio');
		  info.find('#stantion_filtr').append(btn);
		    info.find('#stantion_filtr').append(btn2);
		  
			info.find('.view--category').on('hover:enter hover:click', function () {
				_this2.selectGroup();
			});
			info.find('.view--hdon').on('hover:enter hover:click', function () {
				_this2.selectGroup2();
			});
			
			
			scroll.render().addClass('layer--wheight').data('mheight', info);
			html.append(info.append());
			html.append(scroll.render());
			this.append(data);
			scroll.append(body);
			this.activity.loader(false);
			this.activity.toggle();
		};
		this.selectGroup = function () {
		  Lampa.Select.show({
				title: 'Категории',
				items: catalogs,
				onSelect: function onSelect(a) {
					Lampa.Activity.push({
						url: cors + a.url,
						title: a.title,
						component: 'freetv_n',
						page: 1
					});
				},
				onBack: function onBack() {
					Lampa.Controller.toggle('content');
				}
			});
		};

		this.selectGroup2 = function () {
		  var modal = $('<div class="broadcast__text">РќСЂР°РІРёС‚СЃСЏ РЅР°С€ РїР»Р°РіРёРЅ Рё С…РѕС‡РµС€СЊ РїРѕРґРґРµСЂР¶Р°С‚СЊ?</div><div class="broadcast__text" style="text-align:left;">РџСЂРёРІРµС‚С‹ РЈРІР°Р¶Р°РµРјС‹Рµ РєР°РЅР°Р»Рѕ-Р·СЂРёС‚РµР»Рё! РЎРїР°СЃРёР±Рѕ С‡С‚Рѕ РІСЃРµ РµС‰С‘ РІС‹Р±РёСЂР°РµС‚Рµ РјРѕР№ РїР»Р°РіРёРЅ РґР»СЏ РїСЂРѕСЃРјРѕС‚СЂР° РєР°РЅР°Р»РѕРІ.<br><br>РљР°Рє РЅР°РІРµСЂРЅРѕРµ РІС‹ Р·РЅР°РµС‚Рµ РїР»Р°РіРёРЅ Рё РєР°РЅР°Р»С‹ Р¶РёРІСѓС‚ Рё СЂР°Р±РѕС‚Р°СЋС‚ РЅР° РїРѕР»РЅРѕРј СЌРЅС‚СѓР·РёР°Р·РјРµ Р±РµР· РєР°РєРѕРіРѕ Р»РёР±Рѕ РґРѕС…РѕРґР° СЃ СЌС‚РѕРіРѕ. РџРѕСЌС‚РѕРјСѓ РµСЃР»Рё Сѓ Р’Р°СЃ РµСЃС‚СЊ РєР°РєРѕРµ Р»РёР±Рѕ Р¶РµР»Р°РЅРёРµ Рё РІРѕР·РјРѕР¶РЅРѕСЃС‚СЊ РїРѕРјРѕС‡СЊ РїСЂРѕРµРєС‚Сѓ, Р’С‹ РјРѕР¶РµС‚Рµ Р·Р° РґРѕРЅР°С‚РёС‚СЊ РЅР° РµРіРѕ РґРѕР»СЊРЅРµР№С€РµРµ СЃСѓС‰РµСЃС‚РІРѕРІР°РЅРёРµ Рё СѓР»СѓС‡С€РµРЅРёРµ. Р”Р»СЏ СЌС‚РѕРіРѕ Р±С‹Р» СЃРѕР·РґР°РЅ СЃРїРµС†РёР°Р»СЊРЅРѕ Telegram Р‘РѕС‚ <span style="color:aquamarine;">@RenDonutBot</span> С‡РµСЂРµР· РєРѕС‚РѕСЂРѕРіРѕ Р’С‹ РјРѕР¶РµС‚Рµ РєР°Рє: <span style="font-size: 12.6px;">РЎРІСЏР·Р°С‚СЊСЃСЏ СЃРѕ РјРЅРѕР№ (РµСЃР»Рё Сѓ Р’Р°СЃ РµСЃС‚СЊ Р»РёР±Рѕ Р±СѓРґСѓС‚ РІРѕРїСЂРѕСЃС‹/РїРѕР¶РµР»Р°РЅРёСЏ) Рё РЎРґРµР»Р°С‚СЊ РїРѕР¶РµСЂС‚РІРѕРІР°РЅРёРµ<br><br>РџРѕСЃР»Рµ РїРѕР¶РµСЂС‚РІРѕРІР°РЅРёСЏ РІР°Рј С‚Р°Рє Р¶Рµ Р±СѓРґРµС‚ РґРѕСЃС‚СѓРїРµРЅ РєР°РЅР°Р» РІ РєРѕС‚РѕСЂРѕРј Р±СѓРґСѓС‚ РІСЃРµ РЅРѕРІРѕСЃС‚Рё РїРѕ РЅР°С€РµРјСѓ РїР»Р°РіРёРЅСѓ (РґРѕР±Р°РІР»РµРЅРёСЏ/РёР·РјРµРЅРµРЅРёСЏ РєР°РЅР°Р»РѕРІ) Рё С‚.Рґ.<br>Рђ С‚Р°Рє Р¶Рµ Сѓ РІР°СЃ Р±СѓРґРµС‚ РІРѕР·РјРѕР¶РЅРѕСЃС‚СЊ Р·Р°РєР°Р·Р°С‚СЊ РґРѕР±Р°РІР»РµРЅРёРµ РєР°РЅР°Р»Р°.</span><br><br> РўР°Рє Р¶Рµ РѕР±С‰РёРµ РІРѕРїСЂРѕСЃС‹ РїРѕ РєР°РЅР°Р»РѕРј Рё РґСЂСѓРіРёС… РїР»Р°РіРёРЅРѕРІ СЃРІСЏР·Р°РЅРЅС‹Рµ СЃ РЅРёРјРё РІС‹ РјРѕР¶РµС‚Рµ Р·Р°РґР°С‚СЊ РІ РіСЂСѓРїРїРµ <span style="color:aquamarine;">@lampa_channels</span><div style="height: 25px;">РЎРїР°СЃРёР±Рѕ Р§С‚Рѕ РѕСЃС‚Р°С‘С‚РµСЃСЊ СЃ РЅР°РјРё! <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="currentColor" class="bi bi-balloon-heart" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="m8 2.42-.717-.737c-1.13-1.161-3.243-.777-4.01.72-.35.685-.451 1.707.236 3.062C4.16 6.753 5.52 8.32 8 10.042c2.479-1.723 3.839-3.29 4.491-4.577.687-1.355.587-2.377.236-3.061-.767-1.498-2.88-1.882-4.01-.721L8 2.42Zm-.49 8.5c-10.78-7.44-3-13.155.359-10.063.045.041.089.084.132.129.043-.045.087-.088.132-.129 3.36-3.092 11.137 2.624.357 10.063l.235.468a.25.25 0 1 1-.448.224l-.008-.017c.008.11.02.202.037.29.054.27.161.488.419 1.003.288.578.235 1.15.076 1.629-.157.469-.422.867-.588 1.115l-.004.007a.25.25 0 1 1-.416-.278c.168-.252.4-.6.533-1.003.133-.396.163-.824-.049-1.246l-.013-.028c-.24-.48-.38-.758-.448-1.102a3.177 3.177 0 0 1-.052-.45l-.04.08a.25.25 0 1 1-.447-.224l.235-.468ZM6.013 2.06c-.649-.18-1.483.083-1.85.798-.131.258-.245.689-.08 1.335.063.244.414.198.487-.043.21-.697.627-1.447 1.359-1.692.217-.073.304-.337.084-.398Z"></path></svg></div></div>');
			var enabled = Lampa.Controller.enabled().name;
			Lampa.Modal.open({
				title: '',
				html: modal,
				size: 'medium',
				mask: true,
				onBack: function onBack() {
					Lampa.Modal.close();
					Lampa.Controller.toggle(enabled);
				},
				onSelect: function onSelect() {
					
				}
			});		
		};



		this.start = function () {
			var _this = this;
			Lampa.Controller.add('content', {
				toggle: function toggle() {
					Lampa.Controller.collectionSet(scroll.render());
					Lampa.Controller.collectionFocus(last || false, scroll.render());
				},
				left: function left() {
					if (Navigator.canmove('left')) Navigator.move('left');
					else Lampa.Controller.toggle('menu');
				},
				right: function right() {
					if (Navigator.canmove('right')) Navigator.move('right');
					else _this.selectGroup();
				},
				up: function up() {
					if (Navigator.canmove('up')) {
						Navigator.move('up');
					} else {
					 	if (!info.find('.view--category').hasClass('focus')) {
							if (!info.find('.view--category').hasClass('focus')) {
								Lampa.Controller.collectionSet(info);
					  		Navigator.move('right')
							}
						} else Lampa.Controller.toggle('head');
					}
				},
				down: function down() {
					if (Navigator.canmove('down')) Navigator.move('down');
					else if (info.find('.view--category').hasClass('focus')) {
						 Lampa.Controller.toggle('content');
					} 
				},
				back: function back() {
					Lampa.Activity.backward();
				}
			});
			Lampa.Controller.toggle('content');
		};
		this.pause = function() {};
		this.stop = function() {};
		this.render = function() {
			return html;
		};
		this.destroy = function() {
			network.clear();
			scroll.destroy();
			if (info) info.remove();
			html.remove();
			body.remove();
			network = null;
			items = null;
			html = null;
			body = null;
			info = null;
		};
	}

	function startfreetv_n() {
		window.plugin_freetv_N_ready = true;
		Lampa.Component.add('freetv_n', freetv_n);
		Lampa.Listener.follow('app', function(r) {
			if (r.type == 'ready') {
				var ico = '<svg width="16px" height="16px" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" style=\"fill-rule:evenodd;\" fill=\"currentColor\"> class="bi bi-tv"><path d="M2.5 13.5A.5.5 0 0 1 3 13h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zM13.991 3l.024.001a1.46 1.46 0 0 1 .538.143.757.757 0 0 1 .302.254c.067.1.145.277.145.602v5.991l-.001.024a1.464 1.464 0 0 1-.143.538.758.758 0 0 1-.254.302c-.1.067-.277.145-.602.145H2.009l-.024-.001a1.464 1.464 0 0 1-.538-.143.758.758 0 0 1-.302-.254C1.078 10.502 1 10.325 1 10V4.009l.001-.024a1.46 1.46 0 0 1 .143-.538.758.758 0 0 1 .254-.302C1.498 3.078 1.675 3 2 3h11.991zM14 2H2C0 2 0 4 0 4v6c0 2 2 2 2 2h12c2 0 2-2 2-2V4c0-2-2-2-2-2z"/></svg>';
				var menu_itemm = $('<li class="menu__item selector focus" data-action="freetv_r"><div class="menu__ico">' + ico + '</div><div class="menu__text">FreeТВ1</div></li>');
				menu_itemm.on('hover:enter', function() {
					Lampa.Activity.push({
						url: 'http://45.15.159.227/json/all.json',
						title: 'Основные',
						component: 'freetv_n',
						page: 1
					});
				});
				$('.menu .menu__list').eq(0).append(menu_itemm);
			}
		});
	}
	if (!window.plugin_freetv_N_ready) startfreetv_n();

Lampa.Template.add('nomenuiptv', '<style>div[data-name="1901885695"]{opacity: 0%!important;display: none;}</style>');
$('body').append(Lampa.Template.get('nomenuiptv', {}, true));

Lampa.Template.add('PlayerError', '<style>body > div.player > div.player-info.info--visible > div > div.player-info__error{opacity: 0%!important;display: none;}</style>');
$('body').append(Lampa.Template.get('PlayerError', {}, true));

		Lampa.Listener.follow('app', function(r) {
			if (r.type == 'ready') {
				var icon = '<svg width="16px" height="16px" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" style=\"fill-rule:evenodd;\" fill=\"currentColor\"> class="bi bi-tv"><path d="M2.5 13.5A.5.5 0 0 1 3 13h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zM13.991 3l.024.001a1.46 1.46 0 0 1 .538.143.757.757 0 0 1 .302.254c.067.1.145.277.145.602v5.991l-.001.024a1.464 1.464 0 0 1-.143.538.758.758 0 0 1-.254.302c-.1.067-.277.145-.602.145H2.009l-.024-.001a1.464 1.464 0 0 1-.538-.143.758.758 0 0 1-.302-.254C1.078 10.502 1 10.325 1 10V4.009l.001-.024a1.46 1.46 0 0 1 .143-.538.758.758 0 0 1 .254-.302C1.498 3.078 1.675 3 2 3h11.991zM14 2H2C0 2 0 4 0 4v6c0 2 2 2 2 2h12c2 0 2-2 2-2V4c0-2-2-2-2-2z"/></svg>';
				var menu_itemmm = $('<ul class="menu__list"><li class="menu__item selector focus" data-action="freetv_r"><div class="menu__ico">' + icon + '</div><div class="menu__text">FreeТВ2</div></li></ul>');
				menu_itemmm.on('hover:enter', function() {
					Lampa.Activity.push({
						url: 'http://45.15.159.227/json/all.json',
						title: 'Основные',
						component: 'freetv_n',
						page: 1
					});
				});

$('.menu .menu__case').eq(0).append(menu_itemmm);
			}
		});

})();