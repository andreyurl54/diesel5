(function() {
	'use strict';
Lampa.Platform.tv();

Lampa.Storage.set ('screensaver_aerial_items', '[{"id":"","accessibilityLabel":"","src":{"H2641080p":"http://lampatv.site/birds.mkv"},"name":"","pointsOfInterest":{"0":""},"type":"","timeOfDay":""},{"id":"","accessibilityLabel":"","src":{"H2641080p":"http://lampatv.site/birds.mkv"},"name":"","pointsOfInterest":{"0":""},"type":"","timeOfDay":""}]')
})();

  /*
  {
    "id": "",
    "accessibilityLabel": "",
    "src": {
      "H2641080p": "https://sylvan.apple.com/Videos/comp_A103_C002_0205DG_v12_SDR_FINAL_20180706_SDR_2K_AVC.mov"
    },
    "name": "",
    "pointsOfInterest": {
      "0": ""
    },
    "type": "",
    "timeOfDay": ""
  },
  {
    "id": "",
    "accessibilityLabel": "",
    "src": {
      "H2641080p": "https://sylvan.apple.com/Videos/comp_GMT312_162NC_139M_1041_AFRICA_NIGHT_v14_SDR_FINAL_20180706_SDR_2K_AVC.mov"
    },
    "name": "",
    "pointsOfInterest": {
      "0": ""
    },
    "type": "",
    "timeOfDay": ""
  }
  */