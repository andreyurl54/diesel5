(function () {
    'use strict';
	
	//parser_use, true
	//jackett_interview, healthy
	//jackett_url, 12345url

Lampa.SettingsApi.addParam({
					component: 'parser', //Название компонента
					param: {
						name: 'jackett_url', 			//название в Storage
						type: 'select', 			//доступно select,input,trigger,title,static
						values: {					//значения (слева) выставляемые в поле TVmenu через Storage, справа - их видимое название в меню
						   jac_lampa32_ru:   'lampa32',
						   j_yourok_ru:      'yourok',    
						   jacc_drstein_xyz: 'drstein',
						   jacred_cf:        'jacred',
						},
						default: 'jacred_cf'				//Здесь прописываем вариант по-умолчанию, а именно левую часть в VALUES (не значение, а имя параметра - слева!), иначе - undefined
					},
					field: {
						name: 'Предустановленный JACKETT', 			//Название подпункта меню
						description: '' //Комментарий к подпункту
					},
					onChange: function (value) { 	//Действия при изменении подпункта
						Lampa.Noty.show("Перезагрузите Lampa для применения настроек!"); //Уведомление
						Lampa.Settings.update();

					}
				});
                                     
//Lampa.Template.add('default_parser_style', '<style>#app > div.settings > div.settings__content.layer--height > div.settings__body > div > div > div > div > div:nth-child(2) > div:nth-child(3){opacity: 0%!important;display: none;}</style>');
//$('body').append(Lampa.Template.get('default_parser_style', {}, true));

}();