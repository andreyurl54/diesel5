(function () {
    'use strict';

    Lampa.Storage.set('parser_use', 'true');
    Lampa.Storage.set('parser_torrent_type', 'jackett');
    Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');
    Lampa.Storage.set('jackett_key', '1');
    Lampa.Storage.set('parse_lang', 'df_lg');
    Lampa.Storage.set('parse_in_search', 'false');
    Lampa.Storage.set('torrserver_url', '85.192.40.71:8090');
    Lampa.Storage.set('jackett_interview', 'healthy');
    Lampa.Storage.set('online_proxy_all', 'http://full.lampa32.ru/proxy/');



Lampa.Platform.tv();
function include(url) {
	var script = document.createElement('script'); 
	script.src = url; 
	document.getElementsByTagName('body')[0].appendChild(script);}
include("http://full.lampa32.ru/dlna.js?v=" + Math.random());



})();
