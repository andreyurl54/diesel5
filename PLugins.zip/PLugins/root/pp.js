(function () {
    'use strict';
	Lampa.Keypad.listener.destroy();
Lampa.Platform.tv();
	 Lampa.Keypad.listener.follow('keydown', function (e) {
      var code = e.code;
        if (code === 37) { //a
          player.seekTo(player.getCurrentTime() - 60, true)
        } 
        if (code === 39) { //d
          player.seekTo(player.getCurrentTime() + 60, true)
        }
    });

//Lampa.Controller.toggle('youtube');
})();