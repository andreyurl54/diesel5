(function () {
    'use strict';

//Настройки
    Lampa.Storage.set('parser_use', 'true');
    Lampa.Storage.set('parser_torrent_type', 'jackett');
    Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');
    Lampa.Storage.set('jackett_key', '1');
    Lampa.Storage.set('parse_lang', 'df_lg');
    Lampa.Storage.set('parse_in_search', 'false');
    Lampa.Storage.set('torrserver_url', 'http://85.192.40.71:8090');
    Lampa.Storage.set('jackett_interview', 'healthy');
    Lampa.Storage.set('online_proxy_all', 'http://full.lampa32.ru/proxy/');

//tmdb_proxy

    var tmdb_proxy = {
      name: 'TMDB Proxy',
      version: '1.0.1',
      description: 'Проксирование постеров и API сайта TMDB',
      path_image: 'http://imagetmdb.com/',
      path_api: 'http://apitmdb.cub.watch/3/'
    };

    Lampa.TMDB.image = function (url) {
      var base = Lampa.Utils.protocol() + 'image.tmdb.org/' + url;
      return Lampa.Storage.field('proxy_tmdb') ? tmdb_proxy.path_image + url : base;
    };

    Lampa.TMDB.api = function (url) {
      var base = Lampa.Utils.protocol() + 'api.themoviedb.org/3/' + url;
      return Lampa.Storage.field('proxy_tmdb') ? tmdb_proxy.path_api + url : base;
    };

    Lampa.Settings.listener.follow('open', function (e) {
      if (e.name == 'tmdb') {
        e.body.find('[data-parent="proxy"]').remove();
      }
    });

//http://cdn.kulik.uz/cors

Lampa.Template.add('kuliks_style', '<style>@media screen and (max-width: 2560px) { .chaneles_n .card--collection {width: 14.2%!important;} .scroll__content {padding:1.5em 0!important;} .chaneles_tv .info {height:9em!important;} .chaneles_tv .info__title-original {font-size:1.2em;} } @media screen and (max-width: 385px) {.chaneles_n .card--collection {width: 33.3%!important;}} @media screen and (max-width: 580px) {.info__right {display:contents;}.chaneles_n .card--collection {width:25%!important;}} #app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div.activity.layer--width.activity--active > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div.card.selector.card--collection.card--loaded.focus > div.card__view > img{box-shadow: 0 0 0 0.4em #035985!important;}</style>');
$('body').append(Lampa.Template.get('kuliks_style', {}, true));

    	Lampa.Listener.follow('app',(e)=>{
        if(e.type == 'ready'){
			setTimeout(function(){
				$("[data-action=tvtv_r]").eq(0).remove();
			},10); 
        }
    });
	
	
	function chaneles_n(object) {
		var network = new Lampa.Reguest();
		var scroll = new Lampa.Scroll({
			mask: true,
			over: true,
			step: 250
		});
		var items = [];
		var html = $('<div></div>');
		var body = $('<div class="chaneles_n category-full"></div>');
		var info;
		var last;
		var catalogs = [{
        title: 'Основные',
        url: 'http://cdn.kulik.uz/chanls.php?lst=osn'
      },
	  {
        title: 'Кино',
        url: 'http://cdn.kulik.uz/chanls.php?lst=kino'
      },
	  {
        title: 'Интересное',
        url: 'http://cdn.kulik.uz/chanls.php?lst=inter'
      },
	  {
        title: 'Детские',
        url: 'http://cdn.kulik.uz/chanls.php?lst=kids'
      },
	  {
        title: 'Музыка',
        url: 'http://cdn.kulik.uz/chanls.php?lst=music'
      },
	  {
        title: 'КиноЗалы',
        url: 'http://cdn.kulik.uz/chanls.php?lst=cinemas'
      },
      {
        title: 'Спорт',
        url: 'http://cdn.kulik.uz/chanls.php?lst=spots'
      },
      {
        title: 'Региональные',
        url: 'http://cdn.kulik.uz/chanls.php?lst=region'
      },
      {
        title: 'Украина',
        url: 'http://cdn.kulik.uz/chanls.php?lst=ua'
      },
      {
        title: 'Беларусь',
        url: 'http://cdn.kulik.uz/chanls.php?lst=bel'
      },
      {
        title: 'Узбекские',
        url: 'http://cdn.kulik.uz/chanls.php?lst=uzbe'
 //     },
 //     {
  //      title: 'Все каналы',
 //       url: 'http://cdn.kulik.uz/tv/channels.json'
  //    },
     // {
    //    title: 'Ночная лампа',
   //     url: 'http://nightlampa.cf/night.json'
      }];
	this.create = function() {
			var _this = this;
			this.activity.loader(true);
			network.silent(object.url, this.build.bind(this), function() {
				var empty = new Lampa.Empty();
				html.append(empty.render());
				_this.start = empty.start;
				_this.activity.loader(false);
				_this.activity.toggle();
			});
			return this.render();
		};
		this.append = function (data) {
			var _this3 = this;
			data.forEach(function (element) {
				var card = Lampa.Template.get('card', {
					title: element.name,
					release_year: element.time ? element.time + (element.epg ? ' / ' + element.epg : '') : ''
				});
				card.addClass('list-tv card--collection');
				card.find('.card__img').css({
					'cursor': 'pointer',
					'background-color': '#353535a6'
				});
				var img = card.find('.card__img')[0];
				img.onload = function () {
					card.addClass('card--loaded');
				};
				img.onerror = function (e) {
					img.src = './img/img_broken.svg';
				};
				img.src = element.picture;
				card.on('hover:focus', function () {
					last = card[0];
					scroll.update(card, true);
					info.find('.info__title').text(element.name);
					info.find('.info__title-original').text(element.category);
				});
				card.on('hover:enter', function () {
					var video = {
						title: element.name,
						url: element.video
					};
					Lampa.Player.play(video);
					var playlist = [];
					var i = 1;
					data.forEach(function (elem) {
						playlist.push({
							title: i + ' - ' + elem.name,
							url: elem.video
						});
						i++;
					});
					Lampa.Player.playlist(playlist);
					
				if (Lampa.Player.opened()) {
	Lampa.Keypad.listener.destroy();
	Lampa.Keypad.listener.follow('keydown', function (e) {
      var codes = e.code;
      if (Lampa.Player.opened()) {
        if (codes === 428 || codes === 34) {
          Lampa.PlayerPlaylist.prev();
        } 
        if (codes === 427 || codes === 33) {
          Lampa.PlayerPlaylist.next();
        } 
      } 
    });}	
					
			});
				body.append(card);
				items.push(card);
			});
		};
		this.build = function(data) {
			var _this2 = this;
			Lampa.Background.change('http://cdn.kulik.uz/fon2.jpg');
			Lampa.Template.add('button_category', "<div style=\"float:left;margin-left:-100%;\" class=\"full-start__button selector view--category\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-card-list\" viewBox=\"0 0 16 16\"><path d=\"M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z\"/><path d=\"M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z\"/></svg>&nbsp;<span>Категории</span>\n </div>");
			
			Lampa.Template.add('button_hdon', "<div style=\"position:absolute;\" class=\"full-start__button selector view--hdon\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-piggy-bank\" viewBox=\"0 0 16 16\"><path d=\"M5 6.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0zm1.138-1.496A6.613 6.613 0 0 1 7.964 4.5c.666 0 1.303.097 1.893.273a.5.5 0 0 0 .286-.958A7.602 7.602 0 0 0 7.964 3.5c-.734 0-1.441.103-2.102.292a.5.5 0 1 0 .276.962z\"/><path fill-rule=\"evenodd\" d=\"M7.964 1.527c-2.977 0-5.571 1.704-6.32 4.125h-.55A1 1 0 0 0 .11 6.824l.254 1.46a1.5 1.5 0 0 0 1.478 1.243h.263c.3.513.688.978 1.145 1.382l-.729 2.477a.5.5 0 0 0 .48.641h2a.5.5 0 0 0 .471-.332l.482-1.351c.635.173 1.31.267 2.011.267.707 0 1.388-.095 2.028-.272l.543 1.372a.5.5 0 0 0 .465.316h2a.5.5 0 0 0 .478-.645l-.761-2.506C13.81 9.895 14.5 8.559 14.5 7.069c0-.145-.007-.29-.02-.431.261-.11.508-.266.705-.444.315.306.815.306.815-.417 0 .223-.5.223-.461-.026a.95.95 0 0 0 .09-.255.7.7 0 0 0-.202-.645.58.58 0 0 0-.707-.098.735.735 0 0 0-.375.562c-.024.243.082.48.32.654a2.112 2.112 0 0 1-.259.153c-.534-2.664-3.284-4.595-6.442-4.595zM2.516 6.26c.455-2.066 2.667-3.733 5.448-3.733 3.146 0 5.536 2.114 5.536 4.542 0 1.254-.624 2.41-1.67 3.248a.5.5 0 0 0-.165.535l.66 2.175h-.985l-.59-1.487a.5.5 0 0 0-.629-.288c-.661.23-1.39.359-2.157.359a6.558 6.558 0 0 1-2.157-.359.5.5 0 0 0-.635.304l-.525 1.471h-.979l.633-2.15a.5.5 0 0 0-.17-.534 4.649 4.649 0 0 1-1.284-1.541.5.5 0 0 0-.446-.275h-.56a.5.5 0 0 1-.492-.414l-.254-1.46h.933a.5.5 0 0 0 .488-.393zm12.621-.857a.565.565 0 0 1-.098.21.704.704 0 0 1-.044-.025c-.146-.09-.157-.175-.152-.223a.236.236 0 0 1 .117-.173c.049-.027.08-.021.113.012a.202.202 0 0 1 .064.199z\"/></svg>&nbsp;<span>Поддержать!!</span>\n  </div>");
			
			Lampa.Template.add('info_chanelesi', '<div class="chaneles_tv info layer--width"><div class="info__left"><div class="info__title"></div><div class="chaneles_tv info__title-original"></div><div class="info__create"></div></div><div class="info__right">  <div id="stantion_filtr"></div></div></div>');
			var btn = Lampa.Template.get('button_category');
			
			var btn2 = Lampa.Template.get('button_hdon');
			
			info = Lampa.Template.get('info_chanelesi');
		    info.find('#stantion_filtr').append(btn);
		    info.find('#stantion_filtr').append(btn2);
			info.find('.view--category').on('hover:enter hover:click', function () {
				_this2.selectGroup();
			});
			
			
			info.find('.view--hdon').on('hover:enter hover:click', function () {
				_this2.selectGroup2();
			});
			
			
			scroll.render().addClass('layer--wheight').data('mheight', info);
			html.append(info.append());
			html.append(scroll.render());
			this.append(data);
			scroll.append(body);
			this.activity.loader(false);
			this.activity.toggle();
		};
		this.selectGroup = function () {
		  Lampa.Select.show({
				title: 'Категории',
				items: catalogs,
				onSelect: function onSelect(a) {
					Lampa.Activity.push({
						url: a.url,
						title: a.title,
						component: 'chaneles_n',
						page: 1
					});
				},
				onBack: function onBack() {
					Lampa.Controller.toggle('content');
				}
			});
		};
		
		
		this.selectGroup2 = function () {
		  var modal = $('<div class="broadcast__text">Нравится наш плагин и хочешь поддержать?</div><div class="broadcast__text" style="text-align:left;">Приветы Уважаемые канало-зрители! Спасибо что все ещё выбираете мой плагин для просмотра каналов.<br><br>Как наверное вы знаете плагин и каналы живут и работают на полном энтузиазме без какого либо дохода с этого. Поэтому если у Вас есть какое либо желание и возможность помочь проекту, Вы можете за донатить на его дольнейшее существование и улучшение. Для этого был создан специально Telegram Бот <span style="color:aquamarine;">@RenDonutBot</span> через которого Вы можете как: <span style="font-size: 12.6px;">Связаться со мной (если у Вас есть либо будут вопросы/пожелания) и Сделать пожертвование<br><br>После пожертвования вам так же будет доступен канал в котором будут все новости по нашему плагину (добавления/изменения каналов) и т.д.<br>А так же у вас будет возможность заказать добавление канала.</span><br><br> Так же общие вопросы по каналом и других плагинов связанные с ними вы можете задать в группе <span style="color:aquamarine;">@lampa_channels</span><div style="height: 25px;">Спасибо Что остаётесь с нами! <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="currentColor" class="bi bi-balloon-heart" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="m8 2.42-.717-.737c-1.13-1.161-3.243-.777-4.01.72-.35.685-.451 1.707.236 3.062C4.16 6.753 5.52 8.32 8 10.042c2.479-1.723 3.839-3.29 4.491-4.577.687-1.355.587-2.377.236-3.061-.767-1.498-2.88-1.882-4.01-.721L8 2.42Zm-.49 8.5c-10.78-7.44-3-13.155.359-10.063.045.041.089.084.132.129.043-.045.087-.088.132-.129 3.36-3.092 11.137 2.624.357 10.063l.235.468a.25.25 0 1 1-.448.224l-.008-.017c.008.11.02.202.037.29.054.27.161.488.419 1.003.288.578.235 1.15.076 1.629-.157.469-.422.867-.588 1.115l-.004.007a.25.25 0 1 1-.416-.278c.168-.252.4-.6.533-1.003.133-.396.163-.824-.049-1.246l-.013-.028c-.24-.48-.38-.758-.448-1.102a3.177 3.177 0 0 1-.052-.45l-.04.08a.25.25 0 1 1-.447-.224l.235-.468ZM6.013 2.06c-.649-.18-1.483.083-1.85.798-.131.258-.245.689-.08 1.335.063.244.414.198.487-.043.21-.697.627-1.447 1.359-1.692.217-.073.304-.337.084-.398Z"></path></svg></div></div>');
			var enabled = Lampa.Controller.enabled().name;
			Lampa.Modal.open({
				title: '',
				html: modal,
				size: 'medium',
				mask: true,
				onBack: function onBack() {
					Lampa.Modal.close();
					Lampa.Controller.toggle(enabled);
				},
				onSelect: function onSelect() {
					
				}
			});		
		};
		
		
		
		
		
		
		this.start = function () {
			var _this = this;
			Lampa.Controller.add('content', {
				toggle: function toggle() {
					Lampa.Controller.collectionSet(scroll.render());
					Lampa.Controller.collectionFocus(last || false, scroll.render());
				},
				left: function left() {
					if (Navigator.canmove('left')) Navigator.move('left');
					else Lampa.Controller.toggle('menu');
				},
				right: function right() {
					if (Navigator.canmove('right')) Navigator.move('right');
					else _this.selectGroup();
				},
				up: function up() {
					if (Navigator.canmove('up')) {
						Navigator.move('up');
					} else {
					 	if (!info.find('.view--category').hasClass('focus')) {
							if (!info.find('.view--category').hasClass('focus')) {
								Lampa.Controller.collectionSet(info);
					  		Navigator.move('right')
							}
						} else Lampa.Controller.toggle('head');
					}
				},
				down: function down() {
					if (Navigator.canmove('down')) Navigator.move('down');
					else if (info.find('.view--category').hasClass('focus')) {
						 Lampa.Controller.toggle('content');
					} 
				},
				back: function back() {
					Lampa.Activity.backward();
				}
			});
			Lampa.Controller.toggle('content');
		};
		this.pause = function() {};
		this.stop = function() {};
		this.render = function() {
			return html;
		};
		this.destroy = function() {
			network.clear();
			scroll.destroy();
			if (info) info.remove();
			html.remove();
			body.remove();
			network = null;
			items = null;
			html = null;
			body = null;
			info = null;
		};
	}

	function startchaneles_n() {
		window.plugin_chaneles_n_ready = true;
		Lampa.Component.add('chaneles_n', chaneles_n);
		Lampa.Listener.follow('app', function(r) {
			if (r.type == 'ready') {
				var ico = '<img src="http://cdn.kulik.uz/pics/retro-tv.png"/>';
				var menu_items = $('<li class="menu__item selector focus" data-action="chanelesi_r"><div class="menu__ico">' + ico + '</div><div class="menu__text">Каналы</div></li>');
				menu_items.on('hover:enter', function() {
					Lampa.Activity.push({
						url: 'http://cdn.kulik.uz/chanls.php?lst=osn',
						title: 'Основные',
						component: 'chaneles_n',
						page: 1
					});
				});
				$('.menu .menu__list').eq(0).append(menu_items);
			}
		});
	}
	if (!window.plugin_chaneles_n_ready) startchaneles_n();
	
//http://full.lampa32.ru/online.js

    function component(object) {
      var network = new Lampa.Reguest();
      var scroll = new Lampa.Scroll({
        mask: true,
        over: true
      });
      var files = new Lampa.Explorer(object);
      var filter = new Lampa.Filter(object);
      var sources = {};
      var last;
      var source;
      var balanser;
      var initialized;
      var balanser_timer;
      var images = [];
      var number_of_requests = 0;
      var number_of_requests_timer;
      var back_url;
      var last_request_url = '';
      var filter_sources = {};
      var filter_translate = {
        season: Lampa.Lang.translate('torrent_serial_season'),
        voice: Lampa.Lang.translate('torrent_parser_voice'),
        source: Lampa.Lang.translate('settings_rest_source')
      };
      var filter_find = {
        season: [],
        voice: []
      };
      this.initialize = function () {
        var _this = this;
        this.loading(true);
        filter.onSearch = function (value) {
          Lampa.Activity.replace({
            search: value,
            clarification: true
          });
        };
        filter.onBack = function () {
          _this.start();
        };
        filter.render().find('.selector').on('hover:enter', function () {
          clearInterval(balanser_timer);
        });
        filter.onSelect = function (type, a, b) {
          if (type == 'filter') {
            if (a.reset) {
              _this.replaceChoice({
                season: 0,
                voice: 0,
                voice_url: '',
                voice_name: ''
              });
              setTimeout(function () {
                Lampa.Select.close();
                Lampa.Activity.replace();
              }, 10);
            } else {
              var url = filter_find[a.stype][b.index].url;
              var choice = _this.getChoice();
              if (a.stype == 'voice') {
                choice.voice_name = filter_find.voice[b.index].title;
                choice.voice_url = url;
              }
              choice[a.stype] = b.index;
              _this.saveChoice(choice);
              _this.reset();
              _this.loading(true);
              _this.request(url);
              setTimeout(Lampa.Select.close, 10);
            }
          } else if (type == 'sort') {
            Lampa.Select.close();
            object.lampac_custom_select = a.source;
            _this.changeBalanser(a.source);
          }
        };
        if (filter.addButtonBack) filter.addButtonBack();
        filter.render().find('.filter--sort span').text(Lampa.Lang.translate('lampac_balanser'));
        scroll.body().addClass('torrent-list');
        this.createSource().then(function () {
          files.appendFiles(scroll.render());
          files.appendHead(filter.render());
          if (['seasonvar', 'lostfilmhd', 'kinotochka', 'kinopub', 'kinoprofi', 'kinokrad', 'kinobase', 'filmix', 'redheadsound', 'animevost', 'animego', 'animedia', 'animebesst', 'anilibria'].indexOf(balanser) == -1) {
            filter.render().find('.filter--search').addClass('hide');
          }
          scroll.minus(files.render().find('.explorer__files-head'));
          Lampa.Controller.enable('content');
          _this.search();
        })["catch"](function (e) {
          _this.noConnectToServer();
        });
      };
      this.changeBalanser = function (balanser_name) {
        var last_select_balanser = Lampa.Storage.cache('online_last_balanser', 3000, {});
        last_select_balanser[object.movie.id] = balanser_name;
        Lampa.Storage.set('online_last_balanser', last_select_balanser);
        Lampa.Storage.set('online_balanser', balanser_name);
        var to = this.getChoice(balanser_name);
        var from = this.getChoice();
        if (from.voice_name) to.voice_name = from.voice_name;
        this.saveChoice(to, balanser_name);
        Lampa.Activity.replace();
      };
      this.requestParams = function (url) {
        var query = [];
        query.push('id=' + object.movie.id);
        if (object.movie.imdb_id) query.push('imdb_id=' + (object.movie.imdb_id || ''));
        if (object.movie.kinopoisk_id) query.push('kinopoisk_id=' + (object.movie.kinopoisk_id || ''));
        query.push('title=' + encodeURIComponent(object.clarification ? object.search : object.movie.title || object.movie.name));
        query.push('original_title=' + encodeURIComponent(object.movie.original_title || object.movie.original_name));
        query.push('serial=' + (object.movie.original_language == 'ja' ? 5 : object.movie.name ? 1 : 0));
        query.push('year=' + ((object.movie.release_date || object.movie.first_air_date || '0000') + '').slice(0, 4));
        query.push('source=' + Lampa.Storage.field('source'));
        query.push('clarification=' + (object.clarification ? 1 : 0));
        if (Lampa.Storage.get('account_email', '')) query.push('cub_id=' + Lampa.Utils.hash(Lampa.Storage.get('account_email', '')));
        return url + (url.indexOf('?') >= 0 ? '&' : '?') + query.join('&');
      };
      this.createSource = function () {
        var _this2 = this;
        return new Promise(function (resolve, reject) {
          var url = _this2.requestParams(window.lampac_localhost + 'lite.js');
          network.silent(url, function (str) {
            try {
              var json = str.replace(/\n|\t|\r/g, '').match(/append = \[(.*?)\]/);
              var splt = json[1].split('},');
              splt.forEach(function (item) {
                var match = item.match(/name:\'(.*?)\',url:\'(.*?)\',show:(true|false)/);
                if (!match) match = item.match(/name:\'(.*?)\',url:\'(.*?)\'/);
                if (match) {
                  var name = match[1].toLowerCase();
                  if (name !== 'jackett') sources[name] = {
                    url: match[2],
                    show: match[3] ? match[3].trim() == 'true' : true
                  };
                }
              });
              filter_sources = Lampa.Arrays.getKeys(sources);
              if (filter_sources.length) {
                var last_select_balanser = Lampa.Storage.cache('online_last_balanser', 3000, {});
                if (last_select_balanser[object.movie.id]) {
                  balanser = last_select_balanser[object.movie.id];
                  Lampa.Storage.set('online_last_balanser', last_select_balanser);
                } else {
                  balanser = Lampa.Storage.get('online_balanser', filter_sources[0]);
                }
                if (!sources[balanser]) balanser = filter_sources[0];
                if (!sources[balanser].show && !object.lampac_custom_select) balanser = filter_sources[0];
                source = sources[balanser].url;
                resolve();
              } else {
                reject();
              }
            } catch (e) {
              reject();
            }
          }, reject, false, {
            dataType: 'text'
          });
        });
      };

      /**
       * Подготовка
       */
      this.create = function () {
        return this.render();
      };

      /**
       * Начать поиск
       */
      this.search = function () {
        this.loading(true);
        this.filter({
          source: filter_sources
        }, this.getChoice());
        this.find();
      };
      this.find = function () {
        this.request(this.requestParams(source));
      };
      this.request = function (url) {
        number_of_requests++;
        if (number_of_requests < 10) {
          last_request_url = url;
          network["native"](url, this.parse.bind(this), this.doesNotAnswer.bind(this), false, {
            dataType: 'text'
          });
          clearTimeout(number_of_requests_timer);
          number_of_requests_timer = setTimeout(function () {
            number_of_requests = 0;
          }, 4000);
        } else this.empty();
      };
      this.parseJsonDate = function (str, name) {
        try {
          var html = $('<div>' + str + '</div>');
          var elems = [];
          html.find(name).each(function () {
            var item = $(this);
            var data = JSON.parse(item.attr('data-json'));
            var season = item.attr('s');
            var episode = item.attr('e');
            var text = item.text();
            if (!object.movie.name) {
              if (text.match(/\d+p/i)) {
                if (!data.quality) {
                  data.quality = {};
                  data.quality[text] = data.url;
                }
                text = object.movie.title;
              }
              if (text == 'По умолчанию') {
                text = object.movie.title;
              }
            }
            if (episode) data.episode = parseInt(episode);
            if (season) data.season = parseInt(season);
            if (text) data.text = text;
            data.active = item.hasClass('active');
            elems.push(data);
          });
          return elems;
        } catch (e) {
          return [];
        }
      };
      this.getFileUrl = function (file, call) {
        if (file.method == 'play') call(file);else {
          network["native"](file.url, function (json) {
            call(json);
          }, function () {
            call();
          });
        }
      };
      this.toPlayElement = function (file) {
        var play = {
          title: file.title,
          url: file.url,
          quality: file.qualitys,
          timeline: file.timeline,
          subtitles: file.subtitles,
          callback: file.mark
        };
        return play;
      };
      this.display = function (videos) {
        var _this3 = this;
        this.draw(videos, {
          onEnter: function onEnter(item, html) {
            _this3.getFileUrl(item, function (json) {
              if (json && json.url) {
                var playlist = [];
                var first = _this3.toPlayElement(item);
                first.url = json.url;
                first.quality = json.quality || item.qualitys;
                first.subtitles = json.subtitles;
                if (item.season) {
                  videos.forEach(function (elem) {
                    var cell = _this3.toPlayElement(elem);
                    if (elem == item) cell.url = json.url;else {
                      if (elem.method == 'call') {
                        cell.url = function (call) {
                          _this3.getFileUrl(elem, function (stream) {
                            cell.url = stream.url;
                            cell.quality = stream.quality || elem.qualitys;
                            cell.subtitles = stream.subtitles;
                            elem.mark();
                            call();
                          }, function () {
                            cell.url = '';
                            call();
                          });
                        };
                      } else {
                        cell.url = elem.url;
                      }
                    }
                    playlist.push(cell);
                  });
                  Lampa.Player.playlist(playlist);
                } else {
                  playlist.push(first);
                }
                if (playlist.length > 1) first.playlist = playlist;
                Lampa.Player.play(first);
                Lampa.Player.playlist(playlist);
                item.mark();
              } else Lampa.Noty.show(Lampa.Lang.translate('lampac_nolink'));
            });
          },
          onContextMenu: function onContextMenu(item, html, data, call) {
            _this3.getFileUrl(item, function (stream) {
              call({
                file: stream,
                quality: item.qualitys
              });
            });
          }
        });
        this.filter({
          season: filter_find.season.map(function (s) {
            return s.title;
          }),
          voice: filter_find.voice.map(function (b) {
            return b.title;
          })
        }, this.getChoice());
      };
      this.parse = function (str) {
        try {
          var items = this.parseJsonDate(str, '.videos__item');
          var buttons = this.parseJsonDate(str, '.videos__button');
          if (items.length == 1 && items[0].method == 'link' && !items[0].similar) {
            filter_find.season = items.map(function (s) {
              return {
                title: s.text,
                url: s.url
              };
            });
            this.replaceChoice({
              season: 0
            });
            this.request(items[0].url);
          } else {
            this.activity.loader(false);
            var videos = items.filter(function (v) {
              return v.method == 'play' || v.method == 'call';
            });
            var similar = items.filter(function (v) {
              return v.similar;
            });
            if (videos.length) {
              if (buttons.length) {
                filter_find.voice = buttons.map(function (b) {
                  return {
                    title: b.text,
                    url: b.url
                  };
                });
                var select_voice_url = this.getChoice(balanser).voice_url;
                var find_voice_url = buttons.find(function (v) {
                  return v.url == select_voice_url;
                });
                if (find_voice_url && !find_voice_url.active) {
                  console.log('Lampac', 'go to voice', find_voice_url);
                  this.request(find_voice_url.url);
                } else {
                  this.display(videos);
                }
              } else {
                this.replaceChoice({
                  voice: 0,
                  voice_url: '',
                  voice_name: ''
                });
                this.display(videos);
              }
            } else if (items.length) {
              if (similar.length) {
                this.similars(similar);
                back_url = last_request_url;
                this.activity.loader(false);
              } else {
                this.activity.loader(true);
                filter_find.season = items.map(function (s) {
                  return {
                    title: s.text,
                    url: s.url
                  };
                });
                var select_season = this.getChoice(balanser).season;
                var season = filter_find.season[select_season];
                if (!season) season = filter_find.season[0];
                console.log('Lampac', 'go to season', season);
                this.request(season.url);
              }
            } else {
              this.doesNotAnswer();
            }
          }
        } catch (e) {
          console.log('Lampac', 'error', e.stack);
          this.doesNotAnswer();
        }
      };
      this.similars = function (json) {
        var _this4 = this;
        json.forEach(function (elem) {
          elem.title = elem.text;
          elem.info = '';
          var info = [];
          var year = ((elem.start_date || elem.year || object.movie.release_date || object.movie.first_air_date || '') + '').slice(0, 4);
          if (year) info.push(year);
          var name = elem.title || elem.text;
          elem.title = name;
          elem.time = elem.time || '';
          elem.info = info.join('<span class="online-prestige-split">●</span>');
          var item = Lampa.Template.get('lampac_prestige_folder', elem);
          item.on('hover:enter', function () {
            _this4.activity.loader(true);
            _this4.reset();
            _this4.request(elem.url);
          }).on('hover:focus', function (e) {
            last = e.target;
            scroll.update($(e.target), true);
          });
          scroll.append(item);
        });
        Lampa.Controller.enable('content');
      };
      this.getChoice = function (for_balanser) {
        var data = Lampa.Storage.cache('online_choice_' + (for_balanser || balanser), 3000, {});
        var save = data[object.movie.id] || {};
        Lampa.Arrays.extend(save, {
          season: 0,
          voice: 0,
          voice_name: '',
          voice_id: 0,
          episodes_view: {},
          movie_view: ''
        });
        return save;
      };
      this.saveChoice = function (choice, for_balanser) {
        var data = Lampa.Storage.cache('online_choice_' + (for_balanser || balanser), 3000, {});
        data[object.movie.id] = choice;
        Lampa.Storage.set('online_choice_' + (for_balanser || balanser), data);
      };
      this.replaceChoice = function (choice, for_balanser) {
        var to = this.getChoice(for_balanser);
        Lampa.Arrays.extend(to, choice, true);
        this.saveChoice(to, for_balanser);
      };
      this.clearImages = function () {
        images.forEach(function (img) {
          img.onerror = function () {};
          img.onload = function () {};
          img.src = '';
        });
        images = [];
      };

      /**
       * Очистить список файлов
       */
      this.reset = function () {
        last = false;
        clearInterval(balanser_timer);
        network.clear();
        this.clearImages();
        scroll.render().find('.empty').remove();
        scroll.clear();
        scroll.reset();
      };

      /**
       * Загрузка
       */
      this.loading = function (status) {
        if (status) this.activity.loader(true);else {
          this.activity.loader(false);
          this.activity.toggle();
        }
      };

      /**
       * Построить фильтр
       */
      this.filter = function (filter_items, choice) {
        var _this5 = this;
        var select = [];
        var add = function add(type, title) {
          var need = _this5.getChoice();
          var items = filter_items[type];
          var subitems = [];
          var value = need[type];
          items.forEach(function (name, i) {
            subitems.push({
              title: name,
              selected: value == i,
              index: i
            });
          });
          select.push({
            title: title,
            subtitle: items[value],
            items: subitems,
            stype: type
          });
        };
        filter_items.source = filter_sources;
        select.push({
          title: Lampa.Lang.translate('torrent_parser_reset'),
          reset: true
        });
        this.saveChoice(choice);
        if (filter_items.voice && filter_items.voice.length) add('voice', Lampa.Lang.translate('torrent_parser_voice'));
        if (filter_items.season && filter_items.season.length) add('season', Lampa.Lang.translate('torrent_serial_season'));
        filter.set('filter', select);
        filter.set('sort', filter_sources.map(function (e) {
          return {
            title: e,
            source: e,
            selected: e == balanser,
            ghost: !sources[e].show
          };
        }));
        this.selected(filter_items);
      };

      /**
       * Показать что выбрано в фильтре
       */
      this.selected = function (filter_items) {
        var need = this.getChoice(),
          select = [];
        for (var i in need) {
          if (filter_items[i] && filter_items[i].length) {
            if (i == 'voice') {
              select.push(filter_translate[i] + ': ' + filter_items[i][need[i]]);
            } else if (i !== 'source') {
              if (filter_items.season.length >= 1) {
                select.push(filter_translate.season + ': ' + filter_items[i][need[i]]);
              }
            }
          }
        }
        filter.chosen('filter', select);
        filter.chosen('sort', [balanser]);
      };
      this.getEpisodes = function (season, call) {
        var episodes = [];
        if (typeof object.movie.id == 'number' && object.movie.name) {
          var tmdburl = 'tv/' + object.movie.id + '/season/' + season + '?api_key=' + Lampa.TMDB.key() + '&language=' + Lampa.Storage.get('language', 'ru');
          var baseurl = Lampa.TMDB.api(tmdburl);
          network.timeout(1000 * 10);
          network["native"](baseurl, function (data) {
            episodes = data.episodes || [];
            call(episodes);
          }, function (a, c) {
            call(episodes);
          });
        } else call(episodes);
      };

      /**
       * Отрисовка файлов
       */
      this.draw = function (items) {
        var _this6 = this;
        var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
        if (!items.length) return this.empty();
        this.getEpisodes(items[0].season, function (episodes) {
          var viewed = Lampa.Storage.cache('online_view', 5000, []);
          var serial = object.movie.name ? true : false;
          var choice = _this6.getChoice();
          var fully = window.innerWidth > 480;
          var scroll_to_element = false;
          var scroll_to_mark = false;
          items.forEach(function (element, index) {
            var episode = serial && episodes.length && !params.similars ? episodes.find(function (e) {
              return e.episode_number == element.episode;
            }) : false;
            var episode_num = element.episode || index + 1;
            var episode_last = choice.episodes_view[element.season];
            var voice_name = choice.voice_name || (filter_find.voice[0] ? filter_find.voice[0].title : false) || element.voice_name || 'Неизвестно';
            if (element.quality) {
              element.qualitys = element.quality;
              element.quality = Lampa.Arrays.getKeys(element.quality)[0];
            }
            Lampa.Arrays.extend(element, {
              voice_name: voice_name,
              info: voice_name.length > 60 ? voice_name.substr(0, 60) + '...' : voice_name,
              quality: '',
              time: Lampa.Utils.secondsToTime((episode ? episode.runtime : object.movie.runtime) * 60, true)
            });
            var hash_timeline = Lampa.Utils.hash(element.season ? [element.season, element.episode, object.movie.original_title].join('') : object.movie.original_title);
            var hash_behold = Lampa.Utils.hash(element.season ? [element.season, element.episode, object.movie.original_title, element.voice_name].join('') : object.movie.original_title + element.voice_name);
            var data = {
              hash_timeline: hash_timeline,
              hash_behold: hash_behold
            };
            var info = [];
            if (element.season) {
              element.translate_episode_end = _this6.getLastEpisode(items);
              element.translate_voice = element.voice_name;
            }
            if (element.text && !episode) element.title = element.text;
            element.timeline = Lampa.Timeline.view(hash_timeline);
            if (episode) {
              element.title = episode.name;
              if (element.info.length < 30 && episode.vote_average) info.push(Lampa.Template.get('lampac_prestige_rate', {
                rate: parseFloat(episode.vote_average + '').toFixed(1)
              }, true));
              if (episode.air_date && fully) info.push(Lampa.Utils.parseTime(episode.air_date).full);
            } else if (object.movie.release_date && fully) {
              info.push(Lampa.Utils.parseTime(object.movie.release_date).full);
            }
            if (!serial && object.movie.tagline && element.info.length < 30) info.push(object.movie.tagline);
            if (element.info) info.push(element.info);
            if (info.length) element.info = info.map(function (i) {
              return '<span>' + i + '</span>';
            }).join('<span class="online-prestige-split">●</span>');
            var html = Lampa.Template.get('lampac_prestige_full', element);
            var loader = html.find('.online-prestige__loader');
            var image = html.find('.online-prestige__img');
            if (!serial) {
              if (choice.movie_view == hash_behold) scroll_to_element = html;
            } else if (typeof episode_last !== 'undefined' && episode_last == episode_num) {
              scroll_to_element = html;
            }
            if (serial && !episode) {
              image.append('<div class="online-prestige__episode-number">' + ('0' + (element.episode || index + 1)).slice(-2) + '</div>');
              loader.remove();
            } else {
              var img = html.find('img')[0];
              img.onerror = function () {
                img.src = './img/img_broken.svg';
              };
              img.onload = function () {
                image.addClass('online-prestige__img--loaded');
                loader.remove();
                if (serial) image.append('<div class="online-prestige__episode-number">' + ('0' + (element.episode || index + 1)).slice(-2) + '</div>');
              };
              img.src = Lampa.TMDB.image('t/p/w300' + (episode ? episode.still_path : object.movie.backdrop_path));
              images.push(img);
            }
            html.find('.online-prestige__timeline').append(Lampa.Timeline.render(element.timeline));
            if (viewed.indexOf(hash_behold) !== -1) {
              scroll_to_mark = html;
              html.find('.online-prestige__img').append('<div class="online-prestige__viewed">' + Lampa.Template.get('icon_viewed', {}, true) + '</div>');
            }
            element.mark = function () {
              viewed = Lampa.Storage.cache('online_view', 5000, []);
              if (viewed.indexOf(hash_behold) == -1) {
                viewed.push(hash_behold);
                Lampa.Storage.set('online_view', viewed);
                if (html.find('.online-prestige__viewed').length == 0) {
                  html.find('.online-prestige__img').append('<div class="online-prestige__viewed">' + Lampa.Template.get('icon_viewed', {}, true) + '</div>');
                }
              }
              choice = _this6.getChoice();
              if (!serial) {
                choice.movie_view = hash_behold;
              } else {
                choice.episodes_view[element.season] = episode_num;
              }
              _this6.saveChoice(choice);
            };
            element.unmark = function () {
              viewed = Lampa.Storage.cache('online_view', 5000, []);
              if (viewed.indexOf(hash_behold) !== -1) {
                Lampa.Arrays.remove(viewed, hash_behold);
                Lampa.Storage.set('online_view', viewed);
                Lampa.Account.removeStorage('online_view', hash_behold);
                html.find('.online-prestige__viewed').remove();
              }
            };
            element.timeclear = function () {
              element.timeline.percent = 0;
              element.timeline.time = 0;
              element.timeline.duration = 0;
              Lampa.Timeline.update(element.timeline);
            };
            html.on('hover:enter', function () {
              if (object.movie.id) Lampa.Favorite.add('history', object.movie, 100);
              if (params.onEnter) params.onEnter(element, html, data);
            }).on('hover:focus', function (e) {
              last = e.target;
              if (params.onFocus) params.onFocus(element, html, data);
              scroll.update($(e.target), true);
            });
            if (params.onRender) params.onRender(element, html, data);
            _this6.contextMenu({
              html: html,
              element: element,
              onFile: function onFile(call) {
                if (params.onContextMenu) params.onContextMenu(element, html, data, call);
              },
              onClearAllMark: function onClearAllMark() {
                items.forEach(function (elem) {
                  elem.unmark();
                });
              },
              onClearAllTime: function onClearAllTime() {
                items.forEach(function (elem) {
                  elem.timeclear();
                });
              }
            });
            scroll.append(html);
          });
          if (scroll_to_element) {
            last = scroll_to_element[0];
          } else if (scroll_to_mark) {
            last = scroll_to_mark[0];
          }
          Lampa.Controller.enable('content');
        });
      };

      /**
       * Меню
       */
      this.contextMenu = function (params) {
        params.html.on('hover:long', function () {
          function show(extra) {
            var enabled = Lampa.Controller.enabled().name;
            var menu = [];
            if (Lampa.Platform.is('webos')) {
              menu.push({
                title: Lampa.Lang.translate('player_lauch') + ' - Webos',
                player: 'webos'
              });
            }
            if (Lampa.Platform.is('android')) {
              menu.push({
                title: Lampa.Lang.translate('player_lauch') + ' - Android',
                player: 'android'
              });
            }
            menu.push({
              title: Lampa.Lang.translate('player_lauch') + ' - Lampa',
              player: 'lampa'
            });
            menu.push({
              title: Lampa.Lang.translate('lampac_video'),
              separator: true
            });
            menu.push({
              title: Lampa.Lang.translate('torrent_parser_label_title'),
              mark: true
            });
            menu.push({
              title: Lampa.Lang.translate('torrent_parser_label_cancel_title'),
              unmark: true
            });
            menu.push({
              title: Lampa.Lang.translate('time_reset'),
              timeclear: true
            });
            if (extra) {
              menu.push({
                title: Lampa.Lang.translate('copy_link'),
                copylink: true
              });
            }
            menu.push({
              title: Lampa.Lang.translate('more'),
              separator: true
            });
            if (Lampa.Account.logged() && params.element && typeof params.element.season !== 'undefined' && params.element.translate_voice) {
              menu.push({
                title: Lampa.Lang.translate('lampac_voice_subscribe'),
                subscribe: true
              });
            }
            menu.push({
              title: Lampa.Lang.translate('lampac_clear_all_marks'),
              clearallmark: true
            });
            menu.push({
              title: Lampa.Lang.translate('lampac_clear_all_timecodes'),
              timeclearall: true
            });
            Lampa.Select.show({
              title: Lampa.Lang.translate('title_action'),
              items: menu,
              onBack: function onBack() {
                Lampa.Controller.toggle(enabled);
              },
              onSelect: function onSelect(a) {
                if (a.mark) params.element.mark();
                if (a.unmark) params.element.unmark();
                if (a.timeclear) params.element.timeclear();
                if (a.clearallmark) params.onClearAllMark();
                if (a.timeclearall) params.onClearAllTime();
                Lampa.Controller.toggle(enabled);
                if (a.player) {
                  Lampa.Player.runas(a.player);
                  params.html.trigger('hover:enter');
                }
                if (a.copylink) {
                  if (extra.quality) {
                    var qual = [];
                    for (var i in extra.quality) {
                      qual.push({
                        title: i,
                        file: extra.quality[i]
                      });
                    }
                    Lampa.Select.show({
                      title: Lampa.Lang.translate('settings_server_links'),
                      items: qual,
                      onBack: function onBack() {
                        Lampa.Controller.toggle(enabled);
                      },
                      onSelect: function onSelect(b) {
                        Lampa.Utils.copyTextToClipboard(b.file, function () {
                          Lampa.Noty.show(Lampa.Lang.translate('copy_secuses'));
                        }, function () {
                          Lampa.Noty.show(Lampa.Lang.translate('copy_error'));
                        });
                      }
                    });
                  } else {
                    Lampa.Utils.copyTextToClipboard(extra.file, function () {
                      Lampa.Noty.show(Lampa.Lang.translate('copy_secuses'));
                    }, function () {
                      Lampa.Noty.show(Lampa.Lang.translate('copy_error'));
                    });
                  }
                }
                if (a.subscribe) {
                  Lampa.Account.subscribeToTranslation({
                    card: object.movie,
                    season: params.element.season,
                    episode: params.element.translate_episode_end,
                    voice: params.element.translate_voice
                  }, function () {
                    Lampa.Noty.show(Lampa.Lang.translate('lampac_voice_success'));
                  }, function () {
                    Lampa.Noty.show(Lampa.Lang.translate('lampac_voice_error'));
                  });
                }
              }
            });
          }
          params.onFile(show);
        }).on('hover:focus', function () {
          if (Lampa.Helper) Lampa.Helper.show('online_file', Lampa.Lang.translate('helper_online_file'), params.html);
        });
      };

      /**
       * Показать пустой результат
       */
      this.empty = function () {
        var html = Lampa.Template.get('lampac_does_not_answer', {});
        html.find('.online-empty__buttons').remove();
        html.find('.online-empty__title').text(Lampa.Lang.translate('empty_title_two'));
        html.find('.online-empty__time').text(Lampa.Lang.translate('empty_text'));
        scroll.append(html);
        this.loading(false);
      };
      this.noConnectToServer = function () {
        var html = Lampa.Template.get('lampac_does_not_answer', {});
        html.find('.online-empty__buttons').remove();
        html.find('.online-empty__title').text(Lampa.Lang.translate('title_error'));
        html.find('.online-empty__time').text(Lampa.Lang.translate('lampac_does_not_answer_text'));
        files.appendHead(html);
        this.loading(false);
      };
      this.doesNotAnswer = function () {
        var _this7 = this;
        this.reset();
        var html = Lampa.Template.get('lampac_does_not_answer', {
          balanser: balanser
        });
        var tic = 10;
        html.find('.cancel').on('hover:enter', function () {
          clearInterval(balanser_timer);
        });
        html.find('.change').on('hover:enter', function () {
          clearInterval(balanser_timer);
          filter.render().find('.filter--sort').trigger('hover:enter');
        });
        scroll.append(html);
        this.loading(false);
        balanser_timer = setInterval(function () {
          tic--;
          html.find('.timeout').text(tic);
          if (tic == 0) {
            clearInterval(balanser_timer);
            var keys = Lampa.Arrays.getKeys(sources);
            var indx = keys.indexOf(balanser);
            var next = keys[indx + 1];
            if (!next) next = keys[0];
            balanser = next;
            if (Lampa.Activity.active().activity == _this7.activity) _this7.changeBalanser(balanser);
          }
        }, 1000);
      };
      this.getLastEpisode = function (items) {
        var last_episode = 0;
        items.forEach(function (e) {
          if (typeof e.episode !== 'undefined') last_episode = Math.max(last_episode, parseInt(e.episode));
        });
        return last_episode;
      };

      /**
       * Начать навигацию по файлам
       */
      this.start = function () {
        if (Lampa.Activity.active().activity !== this.activity) return;
        if (!initialized) {
          initialized = true;
          this.initialize();
        }
        Lampa.Background.immediately(Lampa.Utils.cardImgBackgroundBlur(object.movie));
        Lampa.Controller.add('content', {
          toggle: function toggle() {
            Lampa.Controller.collectionSet(scroll.render(), files.render());
            Lampa.Controller.collectionFocus(last || false, scroll.render());
          },
          gone: function gone() {
            clearTimeout(balanser_timer);
          },
          up: function up() {
            if (Navigator.canmove('up')) {
              Navigator.move('up');
            } else Lampa.Controller.toggle('head');
          },
          down: function down() {
            Navigator.move('down');
          },
          right: function right() {
            if (Navigator.canmove('right')) Navigator.move('right');else filter.show(Lampa.Lang.translate('title_filter'), 'filter');
          },
          left: function left() {
            if (Navigator.canmove('left')) Navigator.move('left');else Lampa.Controller.toggle('menu');
          },
          back: this.back.bind(this)
        });
        Lampa.Controller.toggle('content');
      };
      this.render = function () {
        return files.render();
      };
      this.back = function () {
        if (back_url) {
          this.activity.loader(true);
          this.reset();
          this.request(back_url);
          back_url = false;
        } else Lampa.Activity.backward();
      };
      this.pause = function () {};
      this.stop = function () {};
      this.destroy = function () {
        network.clear();
        this.clearImages();
        files.destroy();
        scroll.destroy();
        clearInterval(balanser_timer);
      };
    }

    function startPlugin() {
      window.lampac_plugin = true;
      window.lampac_localhost = 'http://79.137.204.8:9118/';
      Lampa.Manifest.plugins = {
        type: 'video',
        version: '1.0.3',
        name: 'Lampac',
        description: 'Плагин для просмотра онлайн сериалов и фильмов',
        component: 'lampac',
        onContextMenu: function onContextMenu(object) {
          return {
            name: Lampa.Lang.translate('lampac_watch'),
            description: ''
          };
        },
        onContextLauch: function onContextLauch(object) {
          resetTemplates();
          Lampa.Component.add('lampac', component);
          Lampa.Activity.push({
            url: '',
            title: Lampa.Lang.translate('title_online'),
            component: 'lampac',
            search: object.title,
            search_one: object.title,
            search_two: object.original_title,
            movie: object,
            page: 1
          });
        }
      };
      Lampa.Lang.add({
        lampac_watch: {
          //
          ru: 'Смотреть онлайн',
          en: 'Watch online',
          ua: 'Дивитися онлайн',
          zh: '在线观看'
        },
        lampac_video: {
          //
          ru: 'Видео',
          en: 'Video',
          ua: 'Відео',
          zh: '视频'
        },
        lampac_nolink: {
          ru: 'Не удалось извлечь ссылку',
          uk: 'Неможливо отримати посилання',
          en: 'Failed to fetch link',
          zh: '获取链接失败'
        },
        lampac_balanser: {
          //
          ru: 'Балансер',
          uk: 'Балансер',
          en: 'Balancer',
          zh: '平衡器'
        },
        helper_online_file: {
          //
          ru: 'Удерживайте клавишу "ОК" для вызова контекстного меню',
          uk: 'Утримуйте клавішу "ОК" для виклику контекстного меню',
          en: 'Hold the "OK" key to bring up the context menu',
          zh: '按住“确定”键调出上下文菜单'
        },
        title_online: {
          //
          ru: 'Онлайн',
          uk: 'Онлайн',
          en: 'Online',
          zh: '在线的'
        },
        lampac_voice_subscribe: {
          //
          ru: 'Подписаться на перевод',
          uk: 'Підписатися на переклад',
          en: 'Subscribe to translation',
          zh: '订阅翻译'
        },
        lampac_voice_success: {
          //
          ru: 'Вы успешно подписались',
          uk: 'Ви успішно підписалися',
          en: 'You have successfully subscribed',
          zh: '您已成功订阅'
        },
        lampac_voice_error: {
          //
          ru: 'Возникла ошибка',
          uk: 'Виникла помилка',
          en: 'An error has occurred',
          zh: '发生了错误'
        },
        lampac_clear_all_marks: {
          //
          ru: 'Очистить все метки',
          uk: 'Очистити всі мітки',
          en: 'Clear all labels',
          zh: '清除所有标签'
        },
        lampac_clear_all_timecodes: {
          //
          ru: 'Очистить все тайм-коды',
          uk: 'Очистити всі тайм-коди',
          en: 'Clear all timecodes',
          zh: '清除所有时间代码'
        },
        lampac_change_balanser: {
          //
          ru: 'Изменить балансер',
          uk: 'Змінити балансер',
          en: 'Change balancer',
          zh: '更改平衡器'
        },
        lampac_balanser_dont_work: {
          //
          ru: 'Балансер ({balanser}) не отвечает на запрос.',
          uk: 'Балансер ({balanser}) не відповідає на запит.',
          en: 'Balancer ({balanser}) does not respond to the request.',
          zh: '平衡器（{balanser}）未响应请求。'
        },
        lampac_balanser_timeout: {
          //
          ru: 'Балансер будет переключен автоматически через <span class="timeout">10</span> секунд.',
          uk: 'Балансер буде переключено автоматично через <span class="timeout">10</span> секунд.',
          en: 'Balancer will be switched automatically in <span class="timeout">10</span> seconds.',
          zh: '平衡器将在<span class="timeout">10</span>秒内自动切换。'
        },
        lampac_does_not_answer_text: {
          ru: 'Сервер не отвечает на запрос.',
          uk: 'Сервер не відповідає на запит.',
          en: 'Server does not respond to the request.',
          zh: '服务器未响应请求。'
        }
      });
      Lampa.Template.add('lampac_css', "\n        <style>\n        .online-prestige{position:relative;-webkit-border-radius:.3em;border-radius:.3em;background-color:rgba(0,0,0,0.3);display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex}.online-prestige__body{padding:1.2em;line-height:1.3;-webkit-box-flex:1;-webkit-flex-grow:1;-moz-box-flex:1;-ms-flex-positive:1;flex-grow:1;position:relative}@media screen and (max-width:480px){.online-prestige__body{padding:.8em 1.2em}}.online-prestige__img{position:relative;width:13em;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;min-height:8.2em}.online-prestige__img>img{position:absolute;top:0;left:0;width:100%;height:100%;-o-object-fit:cover;object-fit:cover;-webkit-border-radius:.3em;border-radius:.3em;opacity:0;-webkit-transition:opacity .3s;-o-transition:opacity .3s;-moz-transition:opacity .3s;transition:opacity .3s}.online-prestige__img--loaded>img{opacity:1}@media screen and (max-width:480px){.online-prestige__img{width:7em;min-height:6em}}.online-prestige__folder{padding:1em;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0}.online-prestige__folder>svg{width:4.4em !important;height:4.4em !important}.online-prestige__viewed{position:absolute;top:1em;left:1em;background:rgba(0,0,0,0.45);-webkit-border-radius:100%;border-radius:100%;padding:.25em;font-size:.76em}.online-prestige__viewed>svg{width:1.5em !important;height:1.5em !important}.online-prestige__episode-number{position:absolute;top:0;left:0;right:0;bottom:0;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;-moz-box-pack:center;-ms-flex-pack:center;justify-content:center;font-size:2em}.online-prestige__loader{position:absolute;top:50%;left:50%;width:2em;height:2em;margin-left:-1em;margin-top:-1em;background:url(./img/loader.svg) no-repeat center center;-webkit-background-size:contain;-o-background-size:contain;background-size:contain}.online-prestige__head,.online-prestige__footer{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-moz-box-pack:justify;-ms-flex-pack:justify;justify-content:space-between;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center}.online-prestige__timeline{margin:.8em 0}.online-prestige__timeline>.time-line{display:block !important}.online-prestige__title{font-size:1.7em;overflow:hidden;-o-text-overflow:ellipsis;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:1;line-clamp:1;-webkit-box-orient:vertical}@media screen and (max-width:480px){.online-prestige__title{font-size:1.4em}}.online-prestige__time{padding-left:2em}.online-prestige__info{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center}.online-prestige__info>*{overflow:hidden;-o-text-overflow:ellipsis;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:1;line-clamp:1;-webkit-box-orient:vertical}.online-prestige__quality{padding-left:1em;white-space:nowrap}.online-prestige__scan-file{position:absolute;bottom:0;left:0;right:0}.online-prestige__scan-file .broadcast__scan{margin:0}.online-prestige .online-prestige-split{font-size:.8em;margin:0 1em;-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0}.online-prestige.focus::after{content:'';position:absolute;top:-0.6em;left:-0.6em;right:-0.6em;bottom:-0.6em;-webkit-border-radius:.7em;border-radius:.7em;border:solid .3em #fff;z-index:-1;pointer-events:none}.online-prestige+.online-prestige{margin-top:1.5em}.online-prestige--folder .online-prestige__footer{margin-top:.8em}.online-prestige-rate{display:-webkit-inline-box;display:-webkit-inline-flex;display:-moz-inline-box;display:-ms-inline-flexbox;display:inline-flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center}.online-prestige-rate>svg{width:1.3em !important;height:1.3em !important}.online-prestige-rate>span{font-weight:600;font-size:1.1em;padding-left:.7em}.online-empty{line-height:1.4}.online-empty__title{font-size:1.8em;margin-bottom:.3em}.online-empty__time{font-size:1.2em;font-weight:300;margin-bottom:1.6em}.online-empty__buttons{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex}.online-empty__buttons>*+*{margin-left:1em}.online-empty__button{background:rgba(0,0,0,0.3);font-size:1.2em;padding:.5em 1.2em;-webkit-border-radius:.2em;border-radius:.2em;margin-bottom:2.4em}.online-empty__button.focus{background:#fff;color:black}.online-empty__templates .online-empty-template:nth-child(2){opacity:.5}.online-empty__templates .online-empty-template:nth-child(3){opacity:.2}.online-empty-template{background-color:rgba(255,255,255,0.3);padding:1em;display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;-webkit-border-radius:.3em;border-radius:.3em}.online-empty-template>*{background:rgba(0,0,0,0.3);-webkit-border-radius:.3em;border-radius:.3em}.online-empty-template__ico{width:4em;height:4em;margin-right:2.4em}.online-empty-template__body{height:1.7em;width:70%}.online-empty-template+.online-empty-template{margin-top:1em}\n        </style>\n    ");
      $('body').append(Lampa.Template.get('lampac_css', {}, true));
      function resetTemplates() {
        Lampa.Template.add('lampac_prestige_full', "<div class=\"online-prestige online-prestige--full selector\">\n            <div class=\"online-prestige__img\">\n                <img alt=\"\">\n                <div class=\"online-prestige__loader\"></div>\n            </div>\n            <div class=\"online-prestige__body\">\n                <div class=\"online-prestige__head\">\n                    <div class=\"online-prestige__title\">{title}</div>\n                    <div class=\"online-prestige__time\">{time}</div>\n                </div>\n\n                <div class=\"online-prestige__timeline\"></div>\n\n                <div class=\"online-prestige__footer\">\n                    <div class=\"online-prestige__info\">{info}</div>\n                    <div class=\"online-prestige__quality\">{quality}</div>\n                </div>\n            </div>\n        </div>");
        Lampa.Template.add('lampac_does_not_answer', "<div class=\"online-empty\">\n            <div class=\"online-empty__title\">\n                #{lampac_balanser_dont_work}\n            </div>\n            <div class=\"online-empty__time\">\n                #{lampac_balanser_timeout}\n            </div>\n            <div class=\"online-empty__buttons\">\n                <div class=\"online-empty__button selector cancel\">#{cancel}</div>\n                <div class=\"online-empty__button selector change\">#{lampac_change_balanser}</div>\n            </div>\n            <div class=\"online-empty__templates\">\n                <div class=\"online-empty-template\">\n                    <div class=\"online-empty-template__ico\"></div>\n                    <div class=\"online-empty-template__body\"></div>\n                </div>\n                <div class=\"online-empty-template\">\n                    <div class=\"online-empty-template__ico\"></div>\n                    <div class=\"online-empty-template__body\"></div>\n                </div>\n                <div class=\"online-empty-template\">\n                    <div class=\"online-empty-template__ico\"></div>\n                    <div class=\"online-empty-template__body\"></div>\n                </div>\n            </div>\n        </div>");
        Lampa.Template.add('lampac_prestige_rate', "<div class=\"online-prestige-rate\">\n            <svg width=\"17\" height=\"16\" viewBox=\"0 0 17 16\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                <path d=\"M8.39409 0.192139L10.99 5.30994L16.7882 6.20387L12.5475 10.4277L13.5819 15.9311L8.39409 13.2425L3.20626 15.9311L4.24065 10.4277L0 6.20387L5.79819 5.30994L8.39409 0.192139Z\" fill=\"#fff\"></path>\n            </svg>\n            <span>{rate}</span>\n        </div>");
        Lampa.Template.add('lampac_prestige_folder', "<div class=\"online-prestige online-prestige--folder selector\">\n            <div class=\"online-prestige__folder\">\n                <svg viewBox=\"0 0 128 112\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <rect y=\"20\" width=\"128\" height=\"92\" rx=\"13\" fill=\"white\"></rect>\n                    <path d=\"M29.9963 8H98.0037C96.0446 3.3021 91.4079 0 86 0H42C36.5921 0 31.9555 3.3021 29.9963 8Z\" fill=\"white\" fill-opacity=\"0.23\"></path>\n                    <rect x=\"11\" y=\"8\" width=\"106\" height=\"76\" rx=\"13\" fill=\"white\" fill-opacity=\"0.51\"></rect>\n                </svg>\n            </div>\n            <div class=\"online-prestige__body\">\n                <div class=\"online-prestige__head\">\n                    <div class=\"online-prestige__title\">{title}</div>\n                    <div class=\"online-prestige__time\">{time}</div>\n                </div>\n\n                <div class=\"online-prestige__footer\">\n                    <div class=\"online-prestige__info\">{info}</div>\n                </div>\n            </div>\n        </div>");
      }
      var button = "<div class=\"full-start__button selector view--online\" data-subtitle=\"Lampac v1.0.3\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" xmlns:xlink=\"http://www.w3.org/1999/xlink\" viewBox=\"0 0 392.697 392.697\" xml:space=\"preserve\">\n            <path d=\"M21.837,83.419l36.496,16.678L227.72,19.886c1.229-0.592,2.002-1.846,1.98-3.209c-0.021-1.365-0.834-2.592-2.082-3.145\n                L197.766,0.3c-0.903-0.4-1.933-0.4-2.837,0L21.873,77.036c-1.259,0.559-2.073,1.803-2.081,3.18\n                C19.784,81.593,20.584,82.847,21.837,83.419z\" fill=\"currentColor\"></path>\n            <path d=\"M185.689,177.261l-64.988-30.01v91.617c0,0.856-0.44,1.655-1.167,2.114c-0.406,0.257-0.869,0.386-1.333,0.386\n                c-0.368,0-0.736-0.082-1.079-0.244l-68.874-32.625c-0.869-0.416-1.421-1.293-1.421-2.256v-92.229L6.804,95.5\n                c-1.083-0.496-2.344-0.406-3.347,0.238c-1.002,0.645-1.608,1.754-1.608,2.944v208.744c0,1.371,0.799,2.615,2.045,3.185\n                l178.886,81.768c0.464,0.211,0.96,0.315,1.455,0.315c0.661,0,1.318-0.188,1.892-0.555c1.002-0.645,1.608-1.754,1.608-2.945\n                V180.445C187.735,179.076,186.936,177.831,185.689,177.261z\" fill=\"currentColor\"></path>\n            <path d=\"M389.24,95.74c-1.002-0.644-2.264-0.732-3.347-0.238l-178.876,81.76c-1.246,0.57-2.045,1.814-2.045,3.185v208.751\n                c0,1.191,0.606,2.302,1.608,2.945c0.572,0.367,1.23,0.555,1.892,0.555c0.495,0,0.991-0.104,1.455-0.315l178.876-81.768\n                c1.246-0.568,2.045-1.813,2.045-3.185V98.685C390.849,97.494,390.242,96.384,389.24,95.74z\" fill=\"currentColor\"></path>\n            <path d=\"M372.915,80.216c-0.009-1.377-0.823-2.621-2.082-3.18l-60.182-26.681c-0.938-0.418-2.013-0.399-2.938,0.045\n                l-173.755,82.992l60.933,29.117c0.462,0.211,0.958,0.316,1.455,0.316s0.993-0.105,1.455-0.316l173.066-79.092\n                C372.122,82.847,372.923,81.593,372.915,80.216z\" fill=\"currentColor\"></path>\n        </svg>\n\n        <span>#{title_online}</span>\n    </div>";

      // нужна заглушка, а то при страте лампы говорит пусто
      Lampa.Component.add('lampac', component);

      //то же самое
      resetTemplates();
      Lampa.Listener.follow('full', function (e) {
        if (e.type == 'complite') {
          var btn = $(Lampa.Lang.translate(button));
          btn.on('hover:enter', function () {
            resetTemplates();
            Lampa.Component.add('lampac', component);
            Lampa.Activity.push({
              url: '',
              title: Lampa.Lang.translate('title_online'),
              component: 'lampac',
              search: e.data.movie.title,
              search_one: e.data.movie.title,
              search_two: e.data.movie.original_title,
              movie: e.data.movie,
              page: 1
            });
          });
          e.object.activity.render().find('.view--torrent').after(btn);
        }
      });
    }
    if (!window.lampac_plugin) startPlugin();

//http://lampa32.ru/rating.js

	function rating_kp_imdb(card) {
		var network = new Lampa.Reguest();
		var clean_title = card.title.replace(/[ .,:;!?]+/g, ' ').trim();
		var search_date = card.release_date || card.first_air_date || card.last_air_date || '0000';
		var search_year = parseInt((search_date + '').slice(0, 4));
		var orig = card.original_title || card.original_name;
		//var kp_prox = Lampa.Storage.field('online_mod_proxy_kp') === true ? 'https://lampa-cors.herokuapp.com/' : '';
		var kp_prox = Lampa.Storage.field('online_mod_proxy_kp') === true ? 'https://cors-fallback.herokuapp.com/' : '';
		var params = {
			id: card.id,
			url: kp_prox + 'https://kinopoiskapiunofficial.tech/',
			rating_url: kp_prox + 'https://rating.kinopoisk.ru/',
			headers: {
				'X-API-KEY': '2a4a0808-81a3-40ae-b0d3-e11335ede616'
			},
			cache_time: 60 * 60 * 24 * 1000 //86400000 сек = 1день Время кэша в секундах
		};
		getRating();

		function getRating() {
			var movieRating = _getCache(params.id);
			if (movieRating) {
				return _showRating(movieRating[params.id]);
			} else {
				searchFilm();
			}
		}

		function searchFilm() {
			var url = params.url;
			var url_by_title = Lampa.Utils.addUrlComponent(url + 'api/v2.1/films/search-by-keyword', 'keyword=' + encodeURIComponent(clean_title));
			if (card.imdb_id) url = Lampa.Utils.addUrlComponent(url + 'api/v2.2/films', 'imdbId=' + encodeURIComponent(card.imdb_id));
			else url = url_by_title;
			network.clear();
			network.timeout(15000);
			network.silent(url, function (json) {
				if (json.items && json.items.length) chooseFilm(json.items);
				else if (json.films && json.films.length) chooseFilm(json.films);
				else if (card.imdb_id) {
					network.clear();
					network.timeout(15000);
					network.silent(url_by_title, function (json) {
						if (json.items && json.items.length) chooseFilm(json.items);
						else if (json.films && json.films.length) chooseFilm(json.films);
						else chooseFilm([]);
					}, function (a, c) {
						Lampa.Noty.show('Рейтинг KP   ' + network.errorDecode(a, c));
					}, false, {
						headers: params.headers
					});
				} else chooseFilm([]);
			}, function (a, c) {
				Lampa.Noty.show('Рейтинг KP   ' + network.errorDecode(a, c));
			}, false, {
				headers: params.headers
			});
		}

		function chooseFilm(items) {
			if (items && items.length) {
				var is_sure = false;
				if (card.imdb_id) {
					var tmp = items.filter(function (elem) {
						return (elem.imdb_id || elem.imdbId) == card.imdb_id;
					});
					if (tmp.length) {
						items = tmp;
						is_sure = true;
					}
				}
				var cards = items.filter(function (c) {
					var year = c.start_date || c.year || '0000';
					c.tmp_year = parseInt((year + '').slice(0, 4));
					return !c.tmp_year || !search_year || c.tmp_year > search_year - 2 && c.tmp_year < search_year + 2;
				});
				if (orig) {
					var _tmp = cards.filter(function (elem) {
						return equalTitle(elem.orig_title || elem.nameOriginal || elem.en_title || elem.nameEn || elem.ru_title || elem.nameRu, orig);
					});
					if (_tmp.length) {
						cards = _tmp;
						is_sure = true;
					}
				}
				if (card.title) {
					var _tmp2 = cards.filter(function (elem) {
						return equalTitle(elem.title || elem.ru_title || elem.nameRu || elem.en_title || elem.nameEn || elem.orig_title || elem.nameOriginal, card.title);
					});
					if (_tmp2.length) {
						cards = _tmp2;
						is_sure = true;
					}
				}
				if (cards.length > 1 && search_year) {
					var _tmp3 = cards.filter(function (c) {
						return c.tmp_year == search_year;
					});
					if (_tmp3.length) cards = _tmp3;
				}
				if (cards.length == 1 && is_sure) {
					var id = cards[0].kp_id || cards[0].kinopoiskId || cards[0].filmId;
					network.clear();
					network.timeout(5000);
					network["native"](params.rating_url + id + '.xml', function (str) {
						var ratingKinopoisk = 0;
						var ratingImdb = 0;
						var xml = $($.parseXML(str));
						var kp_rating = xml.find('kp_rating');
						if (kp_rating.length) {
							ratingKinopoisk = parseFloat(kp_rating.text());
						}
						var imdb_rating = xml.find('imdb_rating');
						if (imdb_rating.length) {
							ratingImdb = parseFloat(imdb_rating.text());
						}
						var movieRating = _setCache(params.id, {
							kp: ratingKinopoisk,
							imdb: ratingImdb,
							timestamp: new Date().getTime()
						}); // Кешируем данные
						return _showRating(movieRating, params.id);
					}, function (a, c) {
						network.clear();
						network.timeout(15000);
						network.silent(params.url + 'api/v2.2/films/' + id, function (data) {
							var movieRating = _setCache(params.id, {
								kp: data.ratingKinopoisk,
								imdb: data.ratingImdb,
								timestamp: new Date().getTime()
							}); // Кешируем данные
							return _showRating(movieRating, params.id);
						}, function (a, c) {
							Lampa.Noty.show(network.errorDecode(a, c));
						}, false, {
							headers: params.headers
						});
					}, false, {
						dataType: 'text'
					});
				} else {
					var movieRating = _setCache(params.id, {
						kp: 0,
						imdb: 0,
						timestamp: new Date().getTime()
					}); // Кешируем данные
					return _showRating(movieRating);
				}
			} else {
				var _movieRating = _setCache(params.id, {
					kp: 0,
					imdb: 0,
					timestamp: new Date().getTime()
				}); // Кешируем данные
				return _showRating(_movieRating);
			}
		}

		function equalTitle(t1, t2) {
			return typeof t1 === 'string' && typeof t2 === 'string' && t1.toLowerCase().replace(/—/g, '-') === t2.toLowerCase().replace(/—/g, '-');
		}

		function _getCache(movie) {
			var timestamp = new Date().getTime();
			var cache = Lampa.Storage.cache('kp_rating', 500, {}); //500 это лимит ключей
			if (cache[movie]) {
				if ((timestamp - cache[movie].timestamp) > params.cache_time) {
					// Если кеш истёк, чистим его
					delete cache[movie];
					Lampa.Storage.set('kp_rating', cache);
					return false;
				}
			} else return false;
			return cache;
		}

		function _setCache(movie, data) {
			var timestamp = new Date().getTime();
			var cache = Lampa.Storage.cache('kp_rating', 500, {}); //500 это лимит ключей
			if (!cache[movie]) {
				cache[movie] = data;
				Lampa.Storage.set('kp_rating', cache);
			} else {
				if ((timestamp - cache[movie].timestamp) > params.cache_time) {
					data.timestamp = timestamp;
					cache[movie] = data;
					Lampa.Storage.set('kp_rating', cache);
				} else data = cache[movie];
			}
			return data;
		}

		function _showRating(data, movie) {
			if (data) {
				var kp_rating = !isNaN(data.kp) && data.kp !== null ? parseFloat(data.kp).toFixed(1) : '0.0';
				var imdb_rating = !isNaN(data.imdb) && data.imdb !== null ? parseFloat(data.imdb).toFixed(1) : '0.0';
				var render = Lampa.Activity.active().activity.render();
				$('.wait_rating', render).remove();
				$('.rate--imdb', render).removeClass('hide').find('> div').eq(0).text(imdb_rating);
				$('.rate--kp', render).removeClass('hide').find('> div').eq(0).text(kp_rating);
			}
		}
	}

	function startPlugin() {
		window.rating_plugin = true;
		Lampa.Listener.follow('full', function (e) {
			if (e.type == 'complite') {
				var render = e.object.activity.render();
				if ($('.rate--kp', render).hasClass('hide') && !$('.wait_rating', render).length) {
					$('.info__rate', render).after('<div style="width:2em;margin-top:1em;margin-right:1em" class="wait_rating"><div class="broadcast__scan"><div></div></div><div>');
					rating_kp_imdb(e.data.movie);
				}
			}
		});
	}
	if (!window.rating_plugin) startPlugin();

//http://full.lampa32.ru/radio.js

    function item(data) {
      var item = Lampa.Template.get('radio_item', {
        name: data.title
      });
      var img = item.find('img')[0];

      img.onerror = function () {
        img.src = './img/img_broken.svg';
      };

      img.src = data.icon_gray;

      this.render = function () {
        return item;
      };

      this.destroy = function () {
        img.onerror = function () {};

        img.onload = function () {};

        img.src = '';
        item.remove();
      };
    }

    function create(data) {
      var content = Lampa.Template.get('items_line', {
        title: data.title
      });
      var body = content.find('.items-line__body');
      var scroll = new Lampa.Scroll({
        horizontal: true,
        step: 300
      });
      var player = window.radio_player;
      var items = [];
      var active = 0;
      var last;

      this.create = function () {
        scroll.render().find('.scroll__body').addClass('items-cards');
        content.find('.items-line__title').text(data.title);
        data.results.forEach(this.append.bind(this));
        body.append(scroll.render());
      };

      this.append = function (element) {
        var item$1 = new item(element);
        item$1.render().on('hover:focus', function () {
          last = item$1.render()[0];
          active = items.indexOf(item$1);
          scroll.update(items[active].render(), true);
        }).on('hover:enter', function () {
          player.play(element);
        });
        scroll.append(item$1.render());
        items.push(item$1);
      };

      this.toggle = function () {
        var _this = this;

        Lampa.Controller.add('radio_line', {
          toggle: function toggle() {
            Lampa.Controller.collectionSet(scroll.render());
            Lampa.Controller.collectionFocus(last || false, scroll.render());
          },
          right: function right() {
            Navigator.move('right');
            Lampa.Controller.enable('radio_line');
          },
          left: function left() {
            if (Navigator.canmove('left')) Navigator.move('left');else if (_this.onLeft) _this.onLeft();else Lampa.Controller.toggle('menu');
          },
          down: this.onDown,
          up: this.onUp,
          gone: function gone() {},
          back: this.onBack
        });
        Lampa.Controller.toggle('radio_line');
      };

      this.render = function () {
        return content;
      };

      this.destroy = function () {
        Lampa.Arrays.destroy(items);
        scroll.destroy();
        content.remove();
        items = null;
      };
    }

    function component() {
      var network = new Lampa.Reguest();
      var scroll = new Lampa.Scroll({
        mask: true,
        over: true
      });
      var items = [];
      var html = $('<div></div>');
      var active = 0;

      this.create = function () {
        var _this = this;

        this.activity.loader(true);
        var prox = Lampa.Platform.is('webos') || Lampa.Platform.is('tizen') || Lampa.Storage.field('proxy_other') === false ? '' : 'http://full.lampa32.ru/proxy/';
        network["native"](prox + 'http://www.radiorecord.ru/api/stations/', this.build.bind(this), function () {
          var empty = new Lampa.Empty();
          html.append(empty.render());
          _this.start = empty.start;

          _this.activity.loader(false);

          _this.activity.toggle();
        });
        Lampa.Background.immediately('');
        return this.render();
      };

      this.build = function (data) {
        var _this2 = this;

        scroll.minus();
        html.append(scroll.render());
        data.result.genre.forEach(function (element) {
          var results = data.result.stations.filter(function (station) {
            return station.genre.filter(function (genre) {
              return genre.id == element.id;
            }).length;
          });

          _this2.append({
            title: element.name,
            results: results
          });
        });
        this.activity.loader(false);
        this.activity.toggle();
      };

      this.append = function (element) {
        var item = new create(element);
        item.create();
        item.onDown = this.down.bind(this);
        item.onUp = this.up.bind(this);
        item.onBack = this.back.bind(this);
        scroll.append(item.render());
        items.push(item);
      };

      this.back = function () {
        Lampa.Activity.backward();
      };

      this.down = function () {
        active++;
        active = Math.min(active, items.length - 1);
        items[active].toggle();
        scroll.update(items[active].render());
      };

      this.up = function () {
        active--;

        if (active < 0) {
          active = 0;
          Lampa.Controller.toggle('head');
        } else {
          items[active].toggle();
        }

        scroll.update(items[active].render());
      };

      this.start = function () {
        Lampa.Controller.add('content', {
          toggle: function toggle() {
            if (items.length) {
              items[active].toggle();
            }
          },
          back: this.back
        });
        Lampa.Controller.toggle('content');
      };

      this.pause = function () {};

      this.stop = function () {};

      this.render = function () {
        return html;
      };

      this.destroy = function () {
        network.clear();
        Lampa.Arrays.destroy(items);
        scroll.destroy();
        html.remove();
        items = null;
        network = null;
      };
    }

    function player() {
      var html = Lampa.Template.get('radio_player', {});
      var audio = new Audio();
      var url = '';
      var played = false;
      var hls;
      audio.addEventListener("play", function (event) {
        played = true;
        html.toggleClass('loading', false);
      });

      function prepare() {
        if (audio.canPlayType('application/vnd.apple.mpegurl') || url.indexOf('.aacp') > 0) load();else if (Hls.isSupported()) {
          try {
            hls = new Hls();
            hls.attachMedia(audio);
            hls.loadSource(url);
            hls.on(Hls.Events.ERROR, function (event, data) {
              if (data.details === Hls.ErrorDetails.MANIFEST_PARSING_ERROR) {
                if (data.reason === "no EXTM3U delimiter") {
                  Lampa.Noty.show('Ошибка в загрузке потока');
                }
              }
            });
            hls.on(Hls.Events.MANIFEST_LOADED, function () {
              start();
            });
          } catch (e) {
            Lampa.Noty.show('Ошибка в загрузке потока');
          }
        } else load();
      }

      function load() {
        audio.src = url;
        audio.load();
        start();
      }

      function start() {
        var playPromise;

        try {
          playPromise = audio.play();
        } catch (e) {}

        if (playPromise !== undefined) {
          playPromise.then(function () {
            console.log('Radio', 'start plaining');
          })["catch"](function (e) {
            console.log('Radio', 'play promise error:', e.message);
          });
        }
      }

      function play() {
        html.toggleClass('loading', true);
        html.toggleClass('stop', false);
        prepare();
      }

      function stop() {
        played = false;
        html.toggleClass('stop', true);
        html.toggleClass('loading', false);

        if (hls) {
          hls.destroy();
          hls = false;
        }

        audio.src = '';
      }

      html.on('hover:enter', function () {
        if (played) stop();else if (url) play();
      });

      this.create = function () {
        $('.head__actions .open--search').before(html);
      };

      this.play = function (data) {
        stop();
        url = data.stream_320 ? data.stream_320 : data.stream_128 ? data.stream_128 : data.stream_hls.replace('playlist.m3u8', '96/playlist.m3u8');
        html.find('.radio-player__name').text(data.title);
        html.toggleClass('hide', false);
        play();
      };
    }

    function startPlugin() {
      window.radio = true;
      Lampa.Component.add('radio', component);
      Lampa.Template.add('radio_item', "<div class=\"selector radio-item\">\n        <div class=\"radio-item__imgbox\">\n            <img class=\"radio-item__img\" />\n        </div>\n\n        <div class=\"radio-item__name\">{name}</div>\n    </div>");
      Lampa.Template.add('radio_player', "<div class=\"selector radio-player stop hide\">\n        <div class=\"radio-player__name\">Radio Record</div>\n\n        <div class=\"radio-player__button\">\n            <i></i>\n            <i></i>\n            <i></i>\n            <i></i>\n        </div>\n    </div>");
      Lampa.Template.add('radio_style', "<style>\n    .radio-item {\n        width: 8em;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-item__imgbox {\n        background-color: #3E3E3E;\n        padding-bottom: 83%;\n        position: relative;\n        -webkit-border-radius: 0.3em;\n           -moz-border-radius: 0.3em;\n                border-radius: 0.3em;\n      }\n      .radio-item__img {\n        position: absolute;\n        top: 0;\n        left: 0;\n        width: 100%;\n        height: 100%;\n      }\n      .radio-item__name {\n        font-size: 1.1em;\n        margin-top: 0.8em;\n      }\n      .radio-item.focus .radio-item__imgbox:after {\n        border: solid 0.4em #fff;\n        content: \"\";\n        display: block;\n        position: absolute;\n        left: 0;\n        top: 0;\n        right: 0;\n        bottom: 0;\n        -webkit-border-radius: 0.3em;\n           -moz-border-radius: 0.3em;\n                border-radius: 0.3em;\n      }\n      .radio-item + .radio-item {\n        margin-left: 1em;\n      }\n      \n      @-webkit-keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      \n      @-moz-keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      \n      @-o-keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      \n      @keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      @-webkit-keyframes sound-loading {\n        0% {\n          -webkit-transform: rotate(0deg);\n                  transform: rotate(0deg);\n        }\n        100% {\n          -webkit-transform: rotate(360deg);\n                  transform: rotate(360deg);\n        }\n      }\n      @-moz-keyframes sound-loading {\n        0% {\n          -moz-transform: rotate(0deg);\n               transform: rotate(0deg);\n        }\n        100% {\n          -moz-transform: rotate(360deg);\n               transform: rotate(360deg);\n        }\n      }\n      @-o-keyframes sound-loading {\n        0% {\n          -o-transform: rotate(0deg);\n             transform: rotate(0deg);\n        }\n        100% {\n          -o-transform: rotate(360deg);\n             transform: rotate(360deg);\n        }\n      }\n      @keyframes sound-loading {\n        0% {\n          -webkit-transform: rotate(0deg);\n             -moz-transform: rotate(0deg);\n               -o-transform: rotate(0deg);\n                  transform: rotate(0deg);\n        }\n        100% {\n          -webkit-transform: rotate(360deg);\n             -moz-transform: rotate(360deg);\n               -o-transform: rotate(360deg);\n                  transform: rotate(360deg);\n        }\n      }\n      .radio-player {\n        display: -webkit-box;\n        display: -webkit-flex;\n        display: -moz-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-align: center;\n        -webkit-align-items: center;\n           -moz-box-align: center;\n            -ms-flex-align: center;\n                align-items: center;\n        -webkit-border-radius: 0.3em;\n           -moz-border-radius: 0.3em;\n                border-radius: 0.3em;\n        padding: 0.2em 0.8em;\n        background-color: #3e3e3e;\n      }\n      .radio-player__name {\n        margin-right: 1em;\n        white-space: nowrap;\n        overflow: hidden;\n        -o-text-overflow: ellipsis;\n           text-overflow: ellipsis;\n        max-width: 8em;\n      }\n      @media screen and (max-width: 385px) {\n        .radio-player__name {\n          display: none;\n        }\n      }\n      .radio-player__button {\n        position: relative;\n        width: 1.5em;\n        height: 1.5em;\n        display: -webkit-box;\n        display: -webkit-flex;\n        display: -moz-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-align: center;\n        -webkit-align-items: center;\n           -moz-box-align: center;\n            -ms-flex-align: center;\n                align-items: center;\n        -webkit-box-pack: center;\n        -webkit-justify-content: center;\n           -moz-box-pack: center;\n            -ms-flex-pack: center;\n                justify-content: center;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-player__button i {\n        display: block;\n        width: 0.2em;\n        background-color: #fff;\n        margin: 0 0.1em;\n        -webkit-animation: sound 0ms -800ms linear infinite alternate;\n           -moz-animation: sound 0ms -800ms linear infinite alternate;\n             -o-animation: sound 0ms -800ms linear infinite alternate;\n                animation: sound 0ms -800ms linear infinite alternate;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-player__button i:nth-child(1) {\n        -webkit-animation-duration: 474ms;\n           -moz-animation-duration: 474ms;\n             -o-animation-duration: 474ms;\n                animation-duration: 474ms;\n      }\n      .radio-player__button i:nth-child(2) {\n        -webkit-animation-duration: 433ms;\n           -moz-animation-duration: 433ms;\n             -o-animation-duration: 433ms;\n                animation-duration: 433ms;\n      }\n      .radio-player__button i:nth-child(3) {\n        -webkit-animation-duration: 407ms;\n           -moz-animation-duration: 407ms;\n             -o-animation-duration: 407ms;\n                animation-duration: 407ms;\n      }\n      .radio-player__button i:nth-child(4) {\n        -webkit-animation-duration: 458ms;\n           -moz-animation-duration: 458ms;\n             -o-animation-duration: 458ms;\n                animation-duration: 458ms;\n      }\n      .radio-player.stop .radio-player__button {\n        -webkit-border-radius: 100%;\n           -moz-border-radius: 100%;\n                border-radius: 100%;\n        border: 0.2em solid #fff;\n      }\n      .radio-player.stop .radio-player__button i {\n        display: none;\n      }\n      .radio-player.stop .radio-player__button:after {\n        content: \"\";\n        width: 0.5em;\n        height: 0.5em;\n        background-color: #fff;\n      }\n      .radio-player.loading .radio-player__button:before {\n        content: \"\";\n        display: block;\n        border-top: 0.2em solid #fff;\n        border-left: 0.2em solid transparent;\n        border-right: 0.2em solid transparent;\n        border-bottom: 0.2em solid transparent;\n        -webkit-animation: sound-loading 1s linear infinite;\n           -moz-animation: sound-loading 1s linear infinite;\n             -o-animation: sound-loading 1s linear infinite;\n                animation: sound-loading 1s linear infinite;\n        width: 0.9em;\n        height: 0.9em;\n        -webkit-border-radius: 100%;\n           -moz-border-radius: 100%;\n                border-radius: 100%;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-player.loading .radio-player__button i {\n        display: none;\n      }\n      .radio-player.focus {\n        background-color: #fff;\n        color: #000;\n      }\n      .radio-player.focus .radio-player__button {\n        border-color: #000;\n      }\n      .radio-player.focus .radio-player__button i, .radio-player.focus .radio-player__button:after {\n        background-color: #000;\n      }\n      .radio-player.focus .radio-player__button:before {\n        border-top-color: #000;\n      }\n    </style>");
      window.radio_player = new player();
      Lampa.Listener.follow('app', function (e) {
        if (e.type == 'ready') {
          var button = $("<li class=\"menu__item selector\" data-action=\"radio\">\n                <div class=\"menu__ico\">\n                    <svg width=\"38\" height=\"31\" viewBox=\"0 0 38 31\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <rect x=\"17.613\" width=\"3\" height=\"16.3327\" rx=\"1.5\" transform=\"rotate(63.4707 17.613 0)\" fill=\"white\"/>\n                    <circle cx=\"13\" cy=\"19\" r=\"6\" fill=\"white\"/>\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0 11C0 8.79086 1.79083 7 4 7H34C36.2091 7 38 8.79086 38 11V27C38 29.2091 36.2092 31 34 31H4C1.79083 31 0 29.2091 0 27V11ZM21 19C21 23.4183 17.4183 27 13 27C8.58173 27 5 23.4183 5 19C5 14.5817 8.58173 11 13 11C17.4183 11 21 14.5817 21 19ZM30.5 18C31.8807 18 33 16.8807 33 15.5C33 14.1193 31.8807 13 30.5 13C29.1193 13 28 14.1193 28 15.5C28 16.8807 29.1193 18 30.5 18Z\" fill=\"white\"/>\n                    </svg>\n                </div>\n                <div class=\"menu__text\">\u0420\u0430\u0434\u0438\u043E</div>\n            </li>");
          button.on('hover:enter', function () {
            Lampa.Activity.push({
              url: '',
              title: 'Радио',
              component: 'radio',
              page: 1
            });
          });
          $('.menu .menu__list').eq(0).append(button);
          $('body').append(Lampa.Template.get('radio_style', {}, true));
          window.radio_player.create();
        }
      });
    }

    if (!window.radio) startPlugin();

		Lampa.Listener.follow('app',(e)=>{
        if(e.type == 'ready'){
			setTimeout(function(){
				$("[data-action=radio]").eq(0).remove();
			},10); 
        }
    });

Lampa.Template.add('remove_lang_ua', '<style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(2){opacity: 0%!important;display: none;}</style>');
$('body').append(Lampa.Template.get('remove_lang_ua', {}, true));


})();