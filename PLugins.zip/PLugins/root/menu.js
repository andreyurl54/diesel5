(function() {
	'use strict';
Lampa.Platform.tv();
//var diesel_server_selected = Lampa.Storage.field('TVmenu'); //выбранный сервер
//var diesel_playlist = 'http://45.15.159.227/users/' + usermail + '/playlist.' + diesel_server_selected + '.m3u8'; //полный путь до плейлиста по выбранному серверу
//var diesel_playlist = 'http://45.15.159.227/users/' + usermail + '/playlist.' + diesel_server_selected + '.m3u8'; //полный путь до плейлиста по выбранному серверу
//Lampa.Storage.set('keyboard_type', 'integrate');
//Lampa.Storage.set('helper', 'false');
//Lampa.Storage.set('screensaver', 'false');

//плейлист в строке 693

//В ССЫЛКЕ ПЛАГИНА НУЖНО ПРИНУДИТЕЛЬНО ОБХОДИТЬ КЕШ ?123 632
Lampa.Storage.set('DIESEL_cat', '');
	
Lampa.SettingsApi.addComponent({
					component: 'My_Menu_Component',
					name: 'TVmenuP', //Задаём название меню
					icon: '<svg viewBox="0 0 24 24" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><path d="M19.7.5H4.3C2.2.5.5 2.2.5 4.3v15.4c0 2.1 1.7 3.8 3.8 3.8h15.4c2.1 0 3.8-1.7 3.8-3.8V4.3c0-2.1-1.7-3.8-3.8-3.8zM13 14.6H8.6c-.3 0-.5.2-.5.5v4.2H6V4.7h7c2.7 0 5 2.2 5 5 0 2.7-2.2 4.9-5 4.9z" fill="#ffffff" class="fill-000000 fill-ffffff"></path><path d="M13 6.8H8.6c-.3 0-.5.2-.5.5V12c0 .3.2.5.5.5H13c1.6 0 2.8-1.3 2.8-2.8.1-1.6-1.2-2.9-2.8-2.9z" fill="#ffffff" class="fill-000000 fill-ffffff"></path></svg>'
					});

Lampa.SettingsApi.addParam({
					component: 'My_Menu_Component', //Название компонента
					param: {
						name: 'TVmenu', 			//название в Storage
						type: 'select', 			//доступно select,input,trigger,title,static
						values: {					//значения (слева) выставляемые в поле TVmenu через Storage, справа - их видимое название в меню
							RU_1: 'Россия_1',
							RU_KFC: 'Россия_2',
							RU_BN: 'Россия_3',
							DE_DE: 'Германия',
							KZ_KZ: 'Казахстан',
							UA_GN: 'Украина',
						},
						default: 'RU_1'				//Здесь прописываем вариант по-умолчанию, а именно левую часть в VALUES (не значение, а имя параметра - слева!), иначе - undefined
					},
					field: {
						name: 'Источник', 			//Название подпункта меню
						description: 'Выбранный сервер трансляции' //Комментарий к подпункту
					},
					onChange: function (value) { 	//Действия при изменении подпункта
						Lampa.Noty.show("Перезагрузите Lampa для применения настроек!"); //Уведомление
						Lampa.Settings.update();

					}
				});
				
Lampa.SettingsApi.addParam({
					component: 'parser', //Название компонента
					param: {
						name: 'jackett_url', 			//название в Storage
						type: 'select', 			//доступно select,input,trigger,title,static
						values: {					//значения (слева) выставляемые в поле TVmenu через Storage, справа - их видимое название в меню
						   jac_lampa32_ru:   'lampa32',
						   j_yourok_ru:      'yourok',    
						   jacc_drstein_xyz: 'drstein',
						   jacred_cf:        'jacred',
						},
						default: 'jacred_cf'				//Здесь прописываем вариант по-умолчанию, а именно левую часть в VALUES (не значение, а имя параметра - слева!), иначе - undefined
					},
					field: {
						name: 'Общественный JACKETT', 			//Название подпункта меню
						description: '' //Комментарий к подпункту
					},
					onChange: function (value) { 	//Действия при изменении подпункта
						Lampa.Settings.update();
						if (Lampa.Storage.field('jackett_url') == 'jac_lampa32_ru') Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');
						if (Lampa.Storage.field('jackett_url') == 'j_yourok_ru') Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');
						if (Lampa.Storage.field('jackett_url') == 'jacc_drstein_xyz') Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');
						if (Lampa.Storage.field('jackett_url') == 'jacred_cf') Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');

					}
				});

//document.querySelector("#app > div.settings > div.settings__content.layer--height > div.settings__body > div > div > div > div > div:nth-child(2)").innerHTML = "<div data-parent="parser"><div class="settings-param selector hide" data-type="toggle" data-name="parser_torrent_type" data-children="type" data-children-value="jackett"><div class="settings-param__name">Тип парсера для торрентов</div><div class="settings-param__value">Jackett</div></div><div class="settings-param-title" data-parent="type"><span>Jackett</span></div><div class="settings-param selector" data-type="select" data-name="jackett_url" placeholder="Например: 192.168.х" data-parent="type"><div class="settings-param__name">Ссылка</div><div class="settings-param__value">Россия_1</div><div class="settings-param__descr">Укажите ссылку на скрипт Jackett</div></div><div class="settings-param selector" data-type="input" data-name="jackett_key" data-string="true" placeholder="Например: sa0sk83d.." data-parent="type"><div class="settings-param__name">Api-ключ</div><div class="settings-param__value">Например: sa0sk83d..</div><div class="settings-param__descr">Находится в Jackett</div></div><div class="settings-param selector" data-type="toggle" data-name="jackett_interview" data-parent="type"><div class="settings-param__name">Опрашивать трекеры</div><div class="settings-param__value">Только доступные</div></div><div class="settings-param-title"><span>Еще</span></div><div class="settings-param selector" data-type="select" data-name="parse_lang"><div class="settings-param__name">Поиск</div><div class="settings-param__value">Оригинал</div><div class="settings-param__descr">На каком языке производить поиск?</div></div><div class="settings-param selector" data-type="toggle" data-name="parse_timeout"><div class="settings-param__name">Таймаут парсера</div><div class="settings-param__value">15</div><div class="settings-param__descr">Время (в секундах) ожидания ответа от сервера</div></div><div class="settings-param selector" data-type="toggle" data-name="parse_in_search"><div class="settings-param__name">Парсер в поиске</div><div class="settings-param__value">Нет</div><div class="settings-param__descr">Показывать результаты в поиске?</div></div></div>";
//Lampa.Template.add('default_parser_style', '<style>#app > div.settings > div.settings__content.layer--height > div.settings__body > div > div > div > div > div:nth-child(2) > div:nth-child(3){opacity: 0%!important;display: none;}</style>');
//$('body').append(Lampa.Template.get('default_parser_style', {}, true));


Lampa.SettingsApi.addParam({
					component: 'My_Menu_Component', //freetv_n
					param: {
						name: 'PICon',
						type: 'trigger', //доступно select,input,trigger,title,static
						default: false
					},
					field: {
						name: 'Пикон', //Название подпункта меню
						description: 'Как отображать значок канала' //Комментарий к подпункту
					},
					onChange: function (value) { //Действия при изменении подпункта
						Lampa.Storage.set('picon_view', 'quad');
						$('.card__view').css('padding-bottom', 100 + '%');
						//var loggg = Lampa.Storage.field('picon_view');
						//console.log (loggg);
						Lampa.Settings.update();
					}
				});
				
Lampa.SettingsApi.addParam({
					component: 'My_Menu_Component', //Название компонента
					param: {
						name: 'ICONS_in_row', 		//название в Storage
						type: 'select', 			//доступно select,input,trigger,title,static
						values: {					//значения (слева) выставляемые в поле TVmenu через Storage, справа - их видимое название в меню
							ICONS_6: '6 иконок',	// 6 иконок
							ICONS_7: '7 иконок',	// 7 иконок
							ICONS_8: '8 иконок',	// 8 иконок
						},
						default: 'ICONS_7'			//Здесь прописываем вариант по-умолчанию, а именно левую часть в VALUES (не значение, а имя параметра - слева!), иначе - undefined
					},
					field: {
						name: 'Количество каналов в строке', 	//Название подпункта меню
						description: 'Сколько каналов в одной строке' //Комментарий к подпункту
					},
					onChange: function (value) { 	//Действия при изменении подпункта
						Lampa.Noty.show("Перезагрузите Lampa для применения настроек!"); //Уведомление
						Lampa.Settings.update();
					}
				});

Lampa.SettingsApi.addParam({
					component: 'My_Menu_Component', //Название компонента
					param: {
						name: 'FRAME_AROUND_pic', 	//название в Storage
						type: 'select', 			//доступно select,input,trigger,title,static
						values: {					//значения (слева) выставляемые в поле TVmenu через Storage, справа - их видимое название в меню
							COLOUR_yellow: 	'Жёлтый',	// жёлтый
							COLOUR_blue: 	'Синий',	// синий
							COLOUR_white: 	'Белый',	// белый
						},
						default: 'COLOUR_yellow'			//Здесь прописываем вариант по-умолчанию, а именно левую часть в VALUES (не значение, а имя параметра - слева!), иначе - undefined
					},
					field: {
						name: 'Цвет рамки выбранного канала', 	//Название подпункта меню
						description: 'Выберите цвет выделения' //Комментарий к подпункту
					},
					onChange: function (value) { 	//Действия при изменении подпункта
						Lampa.Noty.show("Перезагрузите Lampa для применения настроек!"); //Уведомление
						Lampa.Settings.update();
					}
				});

Lampa.SettingsApi.addParam({
					component: 'My_Menu_Component', //Название компонента
					param: {
						name: 'PICon', 		//название в Storage
						type: 'select', 			//доступно select,input,trigger,title,static
						values: {					//значения (слева) выставляемые в поле TVmenu через Storage, справа - их видимое название в меню
							QUAD: 'Квадратный',		// Квадрат
							CLASSIC: 'Прямоугольный',	// Классика
						},
						default: 'QUAD'			//Здесь прописываем вариант по-умолчанию, а именно левую часть в VALUES (не значение, а имя параметра - слева!), иначе - undefined
					},
					field: {
						name: 'Вид иконки канала', 	//Название подпункта меню
						description: 'Форма иконки' //Комментарий к подпункту
					},
					onChange: function (value) { 	//Действия при изменении подпункта
						Lampa.Noty.show("Перезагрузите Lampa для применения настроек!"); //Уведомление
						Lampa.Settings.update();
					}
				});

Lampa.SettingsApi.addParam({
				component: 'My_Menu_Component',
				param: {
					name: 'PLAYLIST_copy',
					type: 'static', //доступно select,input,trigger,title,static
					default: ''
				},
				field: {
					name: 'Плейлист',
					description: 'Для копирования ссылки'
				},
				onRender: function (item) {
					//if (Lampa.Storage.get('DIESEL_cat')) {
						item.show();
					//} else item.hide();
					item.on('hover:enter', function () {
						//Lampa.Storage.set('DIESEL_cat', '');
						
						Lampa.Noty.show('Успешно скопирован');
					});
				}
			});

Lampa.SettingsApi.addParam({
					component: 'My_Menu_Component', 
					param: {
						name: 'DIESEL_debug',
						type: 'trigger', //доступно select,input,trigger,title,static
						default: false
					},
					field: {
						name: 'Режим отладки', //Название подпункта меню
						description: 'Диагностический режим работы плагина' //Комментарий к подпункту
					},
					onChange: function (value) { //Действия при изменении подпункта
						Lampa.Noty.show("Перезагрузите Lampa для применения настроек!"); //Уведомление
						Lampa.Settings.update();
					}
				});
				
Lampa.SettingsApi.addParam({
					component: 'My_Menu_Component', 
					param: {
						name: 'DIESEL_GEO_BLOCK',
						type: 'trigger', //доступно select,input,trigger,title,static
						default: false
					},
					field: {
						name: 'Обход геоблока провайдера', //Название подпункта меню
						description: '' //Комментарий к подпункту
					},
					onChange: function (value) { //Действия при изменении подпункта
						Lampa.Noty.show("Перезагрузите Lampa для применения настроек!"); //Уведомление
						Lampa.Settings.update();
					}
				});				

//Плейлист
	if (Lampa.Storage.field('TVmenu') == 'RU_1')		Lampa.Storage.set('diesel_source', 'playlist.RU_1.m3u8');
	if (Lampa.Storage.field('TVmenu') == 'RU_KFC')		Lampa.Storage.set('diesel_source', 'playlist.RU_KFC.m3u8');
	if (Lampa.Storage.field('TVmenu') == 'RU_BN')		Lampa.Storage.set('diesel_source', 'playlist.RU_BN.m3u8');
	if (Lampa.Storage.field('TVmenu') == 'DE_DE')		Lampa.Storage.set('diesel_source', 'playlist.DE_DE.m3u8');
	if (Lampa.Storage.field('TVmenu') == 'KZ_KZ')		Lampa.Storage.set('diesel_source', 'playlist.KZ_KZ.m3u8');
	if (Lampa.Storage.field('TVmenu') == 'UA_GN')		Lampa.Storage.set('diesel_source', 'playlist.UA_GN.m3u8');
//Иконки
	if (Lampa.Storage.field('ICONS_in_row') == 'ICONS_6')		Lampa.Storage.set('custom_icons', '16.6');
	if (Lampa.Storage.field('ICONS_in_row') == 'ICONS_7')		Lampa.Storage.set('custom_icons', '14.2');
	if (Lampa.Storage.field('ICONS_in_row') == 'ICONS_8')		Lampa.Storage.set('custom_icons', '12.5');
//Цвет рамки выделения
	if (Lampa.Storage.field('FRAME_AROUND_pic') == 'COLOUR_yellow')		Lampa.Storage.set('custom_colour', 'yellow'); 	//fff10d
	if (Lampa.Storage.field('FRAME_AROUND_pic') == 'COLOUR_blue')		Lampa.Storage.set('custom_colour', 'blue');		//0078ff
	if (Lampa.Storage.field('FRAME_AROUND_pic') == 'COLOUR_white')		Lampa.Storage.set('custom_colour', 'white');	//ffffff
//Форма иконки
	if (Lampa.Storage.field('PICon') == 'QUAD')			Lampa.Storage.set('custom_shape', '100');		//Квадрат
	if (Lampa.Storage.field('PICon') == 'CLASSIC')		Lampa.Storage.set('custom_shape', '60');	//Классика



var custom_icons = Lampa.Storage.field('custom_icons'); 			//размер иконок в ряд
var custom_colour = Lampa.Storage.field('custom_colour'); 			//цвет выделения
var custom_shape = Lampa.Storage.field('custom_shape'); 			//цвет выделения

var usermail = Lampa.Storage.field('account_email').toLowerCase(); //почта пользователя
var diesel_server_selected = Lampa.Storage.field('diesel_source'); //извлекается из меню последством переменной
var diesel_playlist = 'http://45.15.159.227/users/' + usermail + '/' + diesel_server_selected; //полный путь до плейлиста по выбранному серверу (из трёх частей)
	if (Lampa.Storage.field('DIESEL_GEO_BLOCK') == true) diesel_playlist = 'http://lampatv.site/users/' + usermail + '/' + diesel_server_selected;


//Стиль "Жёлтая обводка"
	Lampa.Template.add('tv_style', '<style>#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div.activity.layer--width.activity--active > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div.card.selector.card--collection.card--loaded.focus > div.card__view > img{box-shadow: 0 0 0 0.5em #' + custom_colour +'!important;}</style>');
	$('body').append(Lampa.Template.get('tv_style', {}, true));
//Стиль "Форма"
	Lampa.Template.add('shape_style', '<style>#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div.activity.layer--width.activity--active > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div.card.selector.card--collection.card--loaded.focus > div.card__view > img{padding-bottom: ' + custom_shape +'%!important;}</style>');
	$('body').append(Lampa.Template.get('shape_style', {}, true));

console.log (diesel_playlist); //выводим в консоль




			})();

//Lampa.Storage.set('TVmenu', '');
//Lampa.Storage.set('diesel_source', 'playlist.RU_1.m3u8');
//Lampa.Storage.set('diesel_server_selected', 'RU_1');
//if (Lampa.Storage.field('TVmenu')) Lampa.Noty.show("TVmenu exist!"); //Проверяем существование опции
//Lampa.Storage.set('diesel_source', 'playlist.RU_1.m3u8');
//var diesel_playlist = 'http://45.15.159.227/users/' + usermail + '/' + diesel_server_selected; //полный путь до плейлиста по выбранному серверу
//console.log (Lampa.Storage.field('account_email')); //выводим в консоль