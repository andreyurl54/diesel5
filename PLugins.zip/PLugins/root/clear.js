(function() {
	'use strict';

	Lampa.Listener.follow('app', function(e) {
		if(e.type == 'ready') {
			setInterval(function() {
				var element = $("#clearButton");
				if(!element.length > 0) { //Кнопки нет
				
				//$('#clearButton').remove()
				
				var clearbutton = '<div id="clearButton" class="search-source selector"><div class="search-source__tab">ОЧИСТИТЬ</div></div>'
				$("#app > div.main-search > div > div > div > div > div.search__sources > div > div > div").append(clearbutton)
				//$('#clearButton').removeClass('hide')
				
					$('#clearButton').on("hover:enter hover:click hover:touch", function () {
						document.querySelector(".search__input").textContent = "Введите текст..."
					}); //End of_click
				}}, 5000); //End Interval
		} //End IF
	});
})();