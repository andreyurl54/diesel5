(function() {
	'use strict';
Lampa.Platform.tv();
		console.log('God', 'enabled');
		Lampa.Noty.show("GOD enabled");
setTimeout(function() {
        window.god_enabled = false;
		console.log('God', 'disabled');
		Lampa.Noty.show("GOD disabled");
},30000)

 })(); 
