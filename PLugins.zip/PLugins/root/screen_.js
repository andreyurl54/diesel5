(function() {
	'use strict';
Lampa.Platform.tv();

if(window.appready) {
		setTimeout(function() {
					var video = {
						url: 'http://lampatv.fun/YTube/aqua.m3u8'
								};
					Lampa.Player.play(video);
					//if (Lampa.Storage.field('ClockInPlayer') == true) {
						//Lampa.Storage.set('ClockInPlayer') == false
						$('.player-panel__body').hide()
						$('.player-info__body').hide()
						if (Lampa.Player.opened()) {
							Lampa.Keypad.listener.follow('keydown', function (e) {
								$('.player').remove()
								Lampa.Keypad.listener.destroy()
							})
						}
						//Lampa.Storage.set('ClockInPlayer') == true
					//}
		}, 18000);
} else {
		setTimeout(function() {
					var video = {
						url: 'http://lampatv.fun/YTube/aqua.m3u8'
								};
					Lampa.Player.play(video);
					//if (Lampa.Storage.field('ClockInPlayer') == true) {
						//Lampa.Storage.set('ClockInPlayer') == false
						$('.player-panel__body').hide()
						$('.player-info__body').hide()
						if (Lampa.Player.opened()) {
							Lampa.Keypad.listener.follow('keydown', function (e) {
								$('.player').remove()
								Lampa.Keypad.listener.destroy()
							})
						}
						//Lampa.Storage.set('screensaver_aerial_items', '[  {    "id": "2F72BC1E-3D76-456C-81EB-842EBA488C27",    "accessibilityLabel": "Africa and the Middle East",    "src": {      "H2641080p": "https://sylvan.apple.com/Aerials/2x/Videos/comp_A103_C002_0205DG_v12_SDR_FINAL_20180706_SDR_4K_HEVC.mov"    },    "name": "Africa and the Middle East",    "pointsOfInterest": {      "0": "Over the Horn of Africa traveling toward the Gulf of Adeno",      "45": "The southeastern Arabian Peninsula",      "115": "The Gulf of Oman approaching the Makran Coast",      "145": "The Makran Coast of Iran and Pakistan",      "160": "Over Iran moving toward Afghanistan and Pakistan",      "180": "Over Afghanistan and Pakistan moving toward the Karakoram Range",      "235": "Over the Karakoram Range traveling into China",      "280": "The Takla Makan Desert in western China",      "315": "The Tian Shan mountains in Central Asia"    },    "type": "space",    "timeOfDay": "day"  },  {    "id": "A837FA8C-C643-4705-AE92-074EFDD067F7",    "accessibilityLabel": "Africa Night",    "src": {      "H2641080p": "https://sylvan.apple.com/Aerials/2x/Videos/comp_GMT312_162NC_139M_1041_AFRICA_NIGHT_v14_SDR_FINAL_20180706_SDR_4K_HEVC.mov"    },    "name": "Africa Night",    "pointsOfInterest": {      "0": "Traveling northeast over the Sahara at night",      "70": "Over the Grand Erg Oriental heading toward the Mediterranean Sea",      "100": "The Mediterranean coast of Tunisia and Libya",      "120": "Moving over the Mediterranean Sea toward Italy",      "140": "Over southern Italy approaching the Balkan Peninsula with Turkey in the distance",      "165": "Over the Balkan Peninsula moving toward the Black Sea",      "180": "Over the Balkan Peninsula approaching the Black Sea",      "210": "Traveling over the Black Sea toward Ukraine",      "230": "Traveling over Ukraine toward Russia"    },    "type": "space",    "timeOfDay": "night"  },  {    "id": "C7AD3D0A-7EDF-412C-A237-B3C9D27381A1",    "accessibilityLabel": "Alaskan Jellies",    "src": {      "H2641080p": "https://sylvan.apple.com/Aerials/2x/Videos/g201_AK_A003_C014_SDR_20191113_SDR_4K_HEVC.mov"    },    "name": "Alaskan Jellies 1",    "pointsOfInterest": {      "0": "Drifting over Moon Jellyfish near the coast of Alaska United States"    },    "type": "underwater"  },  {    "id": "C6DC4E54-1130-44F8-AF6F-A551D8E8A181",    "accessibilityLabel": "Alaskan Jellies",    "src": {      "H2641080p": "https://sylvan.apple.com/Aerials/2x/Videos/AK_A004_C012_SDR_20191217_SDR_4K_HEVC.mov"    },    "name": "Alaskan Jellies 2",    "pointsOfInterest": {      "0": "Drifting under Moon Jellyfish near the coast of Alaska United States"    },    "type": "underwater"  },  {    "id": "03EC0F5E-CCA8-4E0A-9FEC-5BD1CE151182",    "accessibilityLabel": "Antarctica",    "src": {      "H2641080p": "https://sylvan.apple.com/Aerials/2x/Videos/comp_GMT110_112NC_364D_1054_AURORA_ANTARTICA__COMP_FINAL_v34_PS_SDR_20181107_SDR_4K_HEVC.mov"    },    "name": "Antartica",    "pointsOfInterest": {      "0": "Aurora Australis over Antarctica"    },    "type": "space",    "timeOfDay": "night"  }]')
					//}
		}, 18000);
}



})();