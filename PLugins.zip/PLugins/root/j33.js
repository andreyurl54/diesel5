(async function() {
	'use strict';
Lampa.Platform.tv();

/* Задаём начальные значения списка серверов */
Lampa.Storage.set('LocalServ_1', 'NotFound')	//при запуске обнуляем статус сервера_1
Lampa.Storage.set('LocalServ_2', 'NotFound')	//при запуске обнуляем статус сервера_2
Lampa.Storage.set('LocalServ_3', 'NotFound')	//при запуске обнуляем статус сервера_3

/* Прячем пустые значения серверов: NotFound */
setInterval(function() { 
	var element2Remove = $('.selectbox-item.selector > div:contains("NotFound")');
	if(element2Remove.length > 0) element2Remove.parent('div').hide();
}, 100); //End Interval

/* Опрашиваем 127.0.0.1 */
fetch('127.0.0.1:8090/echo')												//Проверяем LocalHost
	.then(response => {
		Lampa.Storage.set('LocalServ_1', '127.0.0.1') 			//если кандидат ответил на запрос
		})		
	.catch(err => Lampa.Storage.set('LocalServ_1', 'NotFound'))	//если не ответил

/* Нащупываем диапазон IP */
fetch('192.168.1.1:8090/echo')												//Проверяем ответ роутера
	.then(response => {
		Lampa.Storage.set('LocalServ_IP', '192.168.1.') 			//если кандидат ответил на запрос
		})		
	.catch(err => {})	//если не ответил

/* Узнаём диапазон роутера */
var LocalServ_IP = Lampa.Storage.get('LocalServ_IP')

async function checkPort(ip, port, timeout) {
  return new Promise((resolve, reject) => {
    const startTime = new Date();
    const timer = setTimeout(() => {
      const endTime = new Date();
      //reject("Timeout reached (time elapsed: " + (endTime - startTime) + "ms)");
    }, timeout);
    const client = new XMLHttpRequest();
    client.open("HEAD", "http://" + ip + ":" + port + "/echo");
    client.onload = () => {
      clearTimeout(timer);
      resolve("Port " + port + " открыт на " + ip + " - доступен для подключения!");
		/* Если второе место пустое, заполняем */
		if (Lampa.Storage.get('LocalServ_2') == 'NotFound') {
		  Lampa.Storage.set('LocalServ_2', ip)
		}
		/* Если второе место уже заполнено и третье пустое, заполняем третье */
		if ((Lampa.Storage.get('LocalServ_2') !== 'NotFound')&(Lampa.Storage.get('LocalServ_3') == 'NotFound')) {
		  Lampa.Storage.set('LocalServ_3', ip)
		}
    };
    client.onerror = () => {
      clearTimeout(timer);
      reject(""); // reject("Port " + port + " закрыт на " + ip);
    };
    client.send();
  });
}

async function checkLocalPorts(from, to) {
  console.log('Server', 'Сканирование от ' + from + ' до ' + to + ' началось...');
  const startTime1 = new Date();
  for (let i = from; i <= to; i++) {
    const ip = LocalServ_IP + i;
    try {
      const startTime = new Date();
	  const result = await checkPort(ip, 8090, 50);
	  console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime1
  console.log('Server', 'Сканирование от ' + from + ' до ' + to + ' закончилось... за ' + totaltime + ' ms');
}

async function checkLocalPorts2(from2, to2) {
  console.log('Server', 'Сканирование от ' + from2 + ' до ' + to2 + ' началось...');
  const startTime2 = new Date();
  for (let i = from2; i <= to2; i++) {
    const ip = LocalServ_IP + i;
    try {
      const result = await checkPort(ip, 8090, 50);
      console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime2
  console.log('Server', 'Сканирование от ' + from2 + ' до ' + to2 + ' закончилось... за ' + totaltime + ' ms');
}

async function checkLocalPorts3(from3, to3) {
  console.log('Server', 'Сканирование от ' + from3 + ' до ' + to3 + ' началось...');
  const startTime3 = new Date();
  for (let i = from3; i <= to3; i++) {
    const ip = LocalServ_IP + i;
    try {
      const result = await checkPort(ip, 8090, 50);
      console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime3
  console.log('Server', 'Сканирование от ' + from3 + ' до ' + to3 + ' закончилось... за ' + totaltime + ' ms');
}

async function checkLocalPorts4(from4, to4) {
  console.log('Server', 'Сканирование от ' + from4 + ' до ' + to4 + ' началось...');
  const startTime4 = new Date();
  for (let i = from4; i <= to4; i++) {
    const ip = LocalServ_IP + i;
    try {
      const result = await checkPort(ip, 8090, 50);
      console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime4
  console.log('Server', 'Сканирование от ' + from4 + ' до ' + to4 + ' закончилось... за ' + totaltime + ' ms');
}

async function checkLocalPorts5(from5, to5) {
  console.log('Server', 'Сканирование от ' + from5 + ' до ' + to5 + ' началось...');
  const startTime5 = new Date();
  for (let i = from5; i <= to5; i++) {
    const ip = LocalServ_IP + i;
    try {
      const result = await checkPort(ip, 8090, 50);
      console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime5
  console.log('Server', 'Сканирование от ' + from5 + ' до ' + to5 + ' закончилось... за ' + totaltime + ' ms');
}

async function checkLocalPorts6(from6, to6) {
  console.log('Server', 'Сканирование от ' + from6 + ' до ' + to6 + ' началось...');
  const startTime6 = new Date();
  for (let i = from6; i <= to6; i++) {
    const ip = LocalServ_IP + i;
    try {
      const result = await checkPort(ip, 8090, 50);
      console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime6
  console.log('Server', 'Сканирование от ' + from6 + ' до ' + to6 + ' закончилось... за ' + totaltime + ' ms');
}

async function checkLocalPorts7(from7, to7) {
  console.log('Server', 'Сканирование от ' + from7 + ' до ' + to7 + ' началось...');
  const startTime7 = new Date();
  for (let i = from7; i <= to7; i++) {
    const ip = LocalServ_IP + i;
    try {
      const result = await checkPort(ip, 8090, 50);
      console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime7
  console.log('Server', 'Сканирование от ' + from7 + ' до ' + to7 + ' закончилось... за ' + totaltime + ' ms');
}

async function checkLocalPorts8(from8, to8) {
  console.log('Server', 'Сканирование от ' + from8 + ' до ' + to8 + ' началось...');
  const startTime8 = new Date();
  for (let i = from8; i <= to8; i++) {
    const ip = LocalServ_IP + i;
    try {
      const result = await checkPort(ip, 8090, 50);
      console.log('Server', result);
    } catch (error) {
      //console.log('Server', error);
    }
  }
  const endTime = new Date();
  const totaltime = endTime - startTime8
  console.log('Server', 'Сканирование от ' + from8 + ' до ' + to8 + ' закончилось... за ' + totaltime + ' ms');
}


setTimeout(function() {
	checkLocalPorts(2, 33);
},500)
setTimeout(function() {
	checkLocalPorts2(32, 63);
},1000)
setTimeout(function() {
	checkLocalPorts3(64, 97);
},1500)
setTimeout(function() {
	checkLocalPorts4(97, 129);
},2000)
setTimeout(function() {
	checkLocalPorts5(130, 161);
},2500)
setTimeout(function() {
	checkLocalPorts6(162, 193);
},3000)
setTimeout(function() {
	checkLocalPorts7(194, 225);
},3500)
setTimeout(function() {
	checkLocalPorts8(226, 254);
},4000)

/* Формируем меню опроса серверов */
setTimeout(function() { //выставляем таймаут для получения правильного значения в меню выбора локального сервера
	Lampa.SettingsApi.addParam({
					component: 'server',
					param: {
						name: 'localtorrserv',
						type: 'select',
						values: {
						   0: 'Не выбран',
						   1: Lampa.Storage.get('LocalServ_1') + ':8090',
						   2: Lampa.Storage.get('LocalServ_2') + ':8090', //берём значение из Storage т.к. видимость переменных ограничена
						   3: Lampa.Storage.get('LocalServ_3') + ':8090'
						},
						default: 0
					},
					field: {
						name: 'Локальный TorrServer',
						description: 'Нажмите для выбора сервера из списка найденных'
					},
					onChange: function (value) {
						if (value == '0') Lampa.Storage.set('torrserver_url_two', '');
						if (value == '1') Lampa.Storage.set('torrserver_url_two', Lampa.Storage.get('LocalServ_1') + ':8090'); //127.0.0.1
						if (value == '2') Lampa.Storage.set('torrserver_url_two', Lampa.Storage.get('LocalServ_2') + ':8090'); //alias for LocalHost
						if (value == '3') Lampa.Storage.set('torrserver_url_two', Lampa.Storage.get('LocalServ_3') + ':8090'); //ПК или Android
						Lampa.Storage.set('torrserver_use_link', 'two');
						//Lampa.Storage.set('torrserver_use_link', (value == '0') ? 'one' : 'two');
						Lampa.Settings.update();
					},
					onRender: function (item) {
						setTimeout(function() {
							if($('div[data-name="localtorrserv"]').length > 1) item.hide();
							//if(Lampa.Platform.is('android')) Lampa.Storage.set('internal_torrclient', true);
							$('.settings-param__name', item).css('color','f3d900');
							$('div[data-name="localtorrserv"]').insertAfter('div[data-name="torrserver_use_link"]');
						}, 0);
					}
	});
}, 5000) // end TimeOut



 })(); 
/*


Для ускорения работы данного алгоритма можно использовать многопоточность.

Если браузер поддерживает Web Workers, то можно создать несколько рабочих потоков и распределить проверку порта между ними. Каждый поток будет проверять порт на нескольких адресах одновременно, что позволит ускорить выполнение задачи.

Пример реализации многопоточности для данного алгоритма:

1. Создание рабочего потока и определение функции для проверки порта.

worker.js:

```javascript
self.addEventListener('message', function(e) {
  var ipAddresses = e.data;
  var openPorts = [];
  
  for (var i = 0; i < ipAddresses.length; i++) {
    var ipAddress = ipAddresses[i];
    var url = 'http://' + ipAddress + ':8090';
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, false);
    xhr.timeout = 1000;
    try {
      xhr.send();
      if (xhr.status == 200) {
        openPorts.push(ipAddress);
      }
    } catch (e) {
      console.log(ipAddress + ': ошибка соединения');
    }
  }

  self.postMessage(openPorts);
});
```

2. Основной скрипт для запуска рабочих потоков и формирования списка IP-адресов.

```javascript
console.log('Проверка доступности порта 8090 на всех адресах локальной сети...');

var threads = 8; // количество потоков
var ipAddresses = []; // список IP-адресов

for (var i = 2; i <= 254; i++) {
  ipAddresses.push('192.168.1.' + i);
}

var chunkSize = Math.ceil(ipAddresses.length / threads);

var promises = [];

var start = 0;
var end = chunkSize;

for (var i = 0; i < threads; i++) {
  var chunk = ipAddresses.slice(start, end);

  var worker = new Worker('worker.js');
  worker.postMessage(chunk);

  var promise = new Promise(function(resolve, reject) {
    worker.addEventListener('message', function(e) {
      resolve(e.data);
    });
  });

  promises.push(promise);

  start += chunkSize;
  end += chunkSize;
}

Promise.all(promises).then(function(results) {
  var openPorts = Array.prototype.concat.apply([], results);
  console.log('Порт 8090 открыт на следующих адресах:');
  console.log(openPorts.join('\n'));
}, function(reason) {
  console.log('Ошибка: ' + reason);
});
```

3. Запуск основного скрипта в браузере.

Данный подход позволит ускорить работу алгоритма в несколько раз и значительно снизит нагрузку на процессор при проверке порта на множестве адресов.

*/

/*

Для проверки доступности порта 8090 на всех адресах локальной сети от 192.168.1.2 до 192.168.1.254, можно написать следующий алгоритм на JavaScript:

1. Создание функции для проверки доступности порта на указанном IP-адресе.

```javascript
function checkPort(ipAddress) {
  var url = 'http://' + ipAddress + ':8090'; // формирование URL адреса соединения
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.timeout = 1000; // установка таймаута для запроса (1 секунда)
  xhr.send();

  xhr.onload = function() {
    if (xhr.status == 200) {
      console.log(ipAddress + ': порт 8090 открыт');
    }
  };

  xhr.ontimeout = function() {
    console.log(ipAddress + ': порт 8090 недоступен');
  };

  xhr.onerror = function() {
    console.log(ipAddress + ': ошибка соединения');
  };
}
```

2. Создание цикла, который будет перебирать все IP-адреса локальной сети от 192.168.1.2 до 192.168.1.254 и вызывать функцию проверки доступности порта на каждом из них.

```javascript
for (var i = 2; i <= 254; i++) {
  var ipAddress = '192.168.1.' + i;
  checkPort(ipAddress);
}
```

3. Запуск скрипта и вывод результатов в консоль браузера.

```javascript
console.log('Проверка доступности порта 8090 на всех адресах локальной сети...');
for (var i = 2; i <= 254; i++) {
  var ipAddress = '192.168.1.' + i;
  checkPort(ipAddress);
}
```

Готовый скрипт будет выглядеть так:

```javascript
function checkPort(ipAddress) {
  var url = 'http://' + ipAddress + ':8090';
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.timeout = 1000;
  xhr.send();

  xhr.onload = function() {
    if (xhr.status == 200) {
      console.log(ipAddress + ': порт 8090 открыт');
    }
  };

  xhr.ontimeout = function() {
    console.log(ipAddress + ': порт 8090 недоступен');
  };

  xhr.onerror = function() {
    console.log(ipAddress + ': ошибка соединения');
  };
}

console.log('Проверка доступности порта 8090 на всех адресах локальной сети...');
for (var i = 2; i <= 254; i++) {
  var ipAddress = '192.168.1.' + i;
  checkPort(ipAddress);
}
*/ 