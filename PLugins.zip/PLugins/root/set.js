(function () {
    'use strict';

//Settings

    Lampa.Storage.set('parser_use', 'true');
    Lampa.Storage.set('parser_torrent_type', 'jackett');
    Lampa.Storage.set('jackett_url', 'jac.lampa32.ru');
    Lampa.Storage.set('jackett_key', '1');
    Lampa.Storage.set('parse_lang', 'df_lg');
    Lampa.Storage.set('parse_in_search', 'false');
    Lampa.Storage.set('torrserver_url', 'http://85.192.40.71:8090');
    Lampa.Storage.set('jackett_interview', 'healthy');

//Plugins

Lampa.Platform.tv();
function include(url) {
  var script = document.createElement('script');
  script.src = url;
  document.getElementsByTagName('head')[0].appendChild(script);}
include("http://lampa32.ru/tmdbproxy.js?v=" + Math.random());
include("http://full.lampa32.ru/rating.js?v=" + Math.random());
include("http://full.lampa32.ru/online.js?v=" + Math.random());


//TV

Lampa.Template.add('kuliks_style', '<style>@media screen and (max-width: 2560px) { .chaneles_n .card--collection {width: 14.2%!important;} .scroll__content {padding:1.5em 0!important;} .chaneles_tv .info {height:9em!important;} .chaneles_tv .info__title-original {font-size:1.2em;} } @media screen and (max-width: 385px) {.chaneles_n .card--collection {width: 33.3%!important;}} @media screen and (max-width: 580px) {.info__right {display:contents;}.chaneles_n .card--collection {width:25%!important;}} #app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div.activity.layer--width.activity--active > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div.card.selector.card--collection.card--loaded.focus > div.card__view > img{box-shadow: 0 0 0 0.4em #035985!important;}</style>');
$('body').append(Lampa.Template.get('kuliks_style', {}, true));

    	Lampa.Listener.follow('app',(e)=>{
        if(e.type == 'ready'){
			setTimeout(function(){
				$("[data-action=tvtv_r]").eq(0).remove();
			},10); 
        }
    });
	
	
	function chaneles_n(object) {
		var network = new Lampa.Reguest();
		var scroll = new Lampa.Scroll({
			mask: true,
			over: true,
			step: 250
		});
		var items = [];
		var html = $('<div></div>');
		var body = $('<div class="chaneles_n category-full"></div>');
		var info;
		var last;
		var catalogs = [{
        title: 'РћСЃРЅРѕРІРЅС‹Рµ',
        url: 'http://cdn.kulik.uz/chanls.php?lst=osn'
      },
	  {
        title: 'РљРёРЅРѕ',
        url: 'http://cdn.kulik.uz/chanls.php?lst=kino'
      },
	  {
        title: 'РРЅС‚РµСЂРµСЃРЅРѕРµ',
        url: 'http://cdn.kulik.uz/chanls.php?lst=inter'
      },
	  {
        title: 'Р”РµС‚СЃРєРёРµ',
        url: 'http://cdn.kulik.uz/chanls.php?lst=kids'
      },
	  {
        title: 'РњСѓР·С‹РєР°',
        url: 'http://cdn.kulik.uz/chanls.php?lst=music'
      },
	  {
        title: 'РљРёРЅРѕР—Р°Р»С‹',
        url: 'http://cdn.kulik.uz/chanls.php?lst=cinemas'
      },
      {
        title: 'РЎРїРѕСЂС‚',
        url: 'http://cdn.kulik.uz/chanls.php?lst=spots'
      },
      {
        title: 'Р РµРіРёРѕРЅР°Р»СЊРЅС‹Рµ',
        url: 'http://cdn.kulik.uz/chanls.php?lst=region'
      },
      {
        title: 'РЈРєСЂР°РёРЅР°',
        url: 'http://cdn.kulik.uz/chanls.php?lst=ua'
      },
      {
        title: 'Р‘РµР»Р°СЂСѓСЃСЊ',
        url: 'http://cdn.kulik.uz/chanls.php?lst=bel'
      },
      {
        title: 'РЈР·Р±РµРєСЃРєРёРµ',
        url: 'http://cdn.kulik.uz/chanls.php?lst=uzbe'
 //     },
 //     {
  //      title: 'Р’СЃРµ РєР°РЅР°Р»С‹',
 //       url: 'http://cdn.kulik.uz/tv/channels.json'
  //    },
     // {
    //    title: 'РќРѕС‡РЅР°СЏ Р»Р°РјРїР°',
   //     url: 'http://nightlampa.cf/night.json'
      }];
	this.create = function() {
			var _this = this;
			this.activity.loader(true);
			network.silent(object.url, this.build.bind(this), function() {
				var empty = new Lampa.Empty();
				html.append(empty.render());
				_this.start = empty.start;
				_this.activity.loader(false);
				_this.activity.toggle();
			});
			return this.render();
		};
		this.append = function (data) {
			var _this3 = this;
			data.forEach(function (element) {
				var card = Lampa.Template.get('card', {
					title: element.name,
					release_year: element.time ? element.time + (element.epg ? ' / ' + element.epg : '') : ''
				});
				card.addClass('list-tv card--collection');
				card.find('.card__img').css({
					'cursor': 'pointer',
					'background-color': '#353535a6'
				});
				var img = card.find('.card__img')[0];
				img.onload = function () {
					card.addClass('card--loaded');
				};
				img.onerror = function (e) {
					img.src = './img/img_broken.svg';
				};
				img.src = element.picture;
				card.on('hover:focus', function () {
					last = card[0];
					scroll.update(card, true);
					info.find('.info__title').text(element.name);
					info.find('.info__title-original').text(element.category);
				});
				card.on('hover:enter', function () {
					var video = {
						title: element.name,
						url: element.video
					};
					Lampa.Player.play(video);
					var playlist = [];
					var i = 1;
					data.forEach(function (elem) {
						playlist.push({
							title: i + ' - ' + elem.name,
							url: elem.video
						});
						i++;
					});
					Lampa.Player.playlist(playlist);
					
				if (Lampa.Player.opened()) {
	Lampa.Keypad.listener.destroy();
	Lampa.Keypad.listener.follow('keydown', function (e) {
      var codes = e.code;
      if (Lampa.Player.opened()) {
        if (codes === 428 || codes === 34) {
          Lampa.PlayerPlaylist.prev();
        } 
        if (codes === 427 || codes === 33) {
          Lampa.PlayerPlaylist.next();
        } 
      } 
    });}	
					
			});
				body.append(card);
				items.push(card);
			});
		};
		this.build = function(data) {
			var _this2 = this;
			Lampa.Background.change('http://cdn.kulik.uz/fon2.jpg');
			Lampa.Template.add('button_category', "<div style=\"float:left;margin-left:-100%;\" class=\"full-start__button selector view--category\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-card-list\" viewBox=\"0 0 16 16\"><path d=\"M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z\"/><path d=\"M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z\"/></svg>&nbsp;<span>РљР°С‚РµРіРѕСЂРёРё</span>\n </div>");
			
			Lampa.Template.add('button_hdon', "<div style=\"position:absolute;\" class=\"full-start__button selector view--hdon\"><svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" fill=\"currentColor\" class=\"bi bi-piggy-bank\" viewBox=\"0 0 16 16\"><path d=\"M5 6.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0zm1.138-1.496A6.613 6.613 0 0 1 7.964 4.5c.666 0 1.303.097 1.893.273a.5.5 0 0 0 .286-.958A7.602 7.602 0 0 0 7.964 3.5c-.734 0-1.441.103-2.102.292a.5.5 0 1 0 .276.962z\"/><path fill-rule=\"evenodd\" d=\"M7.964 1.527c-2.977 0-5.571 1.704-6.32 4.125h-.55A1 1 0 0 0 .11 6.824l.254 1.46a1.5 1.5 0 0 0 1.478 1.243h.263c.3.513.688.978 1.145 1.382l-.729 2.477a.5.5 0 0 0 .48.641h2a.5.5 0 0 0 .471-.332l.482-1.351c.635.173 1.31.267 2.011.267.707 0 1.388-.095 2.028-.272l.543 1.372a.5.5 0 0 0 .465.316h2a.5.5 0 0 0 .478-.645l-.761-2.506C13.81 9.895 14.5 8.559 14.5 7.069c0-.145-.007-.29-.02-.431.261-.11.508-.266.705-.444.315.306.815.306.815-.417 0 .223-.5.223-.461-.026a.95.95 0 0 0 .09-.255.7.7 0 0 0-.202-.645.58.58 0 0 0-.707-.098.735.735 0 0 0-.375.562c-.024.243.082.48.32.654a2.112 2.112 0 0 1-.259.153c-.534-2.664-3.284-4.595-6.442-4.595zM2.516 6.26c.455-2.066 2.667-3.733 5.448-3.733 3.146 0 5.536 2.114 5.536 4.542 0 1.254-.624 2.41-1.67 3.248a.5.5 0 0 0-.165.535l.66 2.175h-.985l-.59-1.487a.5.5 0 0 0-.629-.288c-.661.23-1.39.359-2.157.359a6.558 6.558 0 0 1-2.157-.359.5.5 0 0 0-.635.304l-.525 1.471h-.979l.633-2.15a.5.5 0 0 0-.17-.534 4.649 4.649 0 0 1-1.284-1.541.5.5 0 0 0-.446-.275h-.56a.5.5 0 0 1-.492-.414l-.254-1.46h.933a.5.5 0 0 0 .488-.393zm12.621-.857a.565.565 0 0 1-.098.21.704.704 0 0 1-.044-.025c-.146-.09-.157-.175-.152-.223a.236.236 0 0 1 .117-.173c.049-.027.08-.021.113.012a.202.202 0 0 1 .064.199z\"/></svg>&nbsp;<span>РџРѕРґРґРµСЂР¶Р°С‚СЊ!!</span>\n  </div>");
			
			Lampa.Template.add('info_chanelesi', '<div class="chaneles_tv info layer--width"><div class="info__left"><div class="info__title"></div><div class="chaneles_tv info__title-original"></div><div class="info__create"></div></div><div class="info__right">  <div id="stantion_filtr"></div></div></div>');
			var btn = Lampa.Template.get('button_category');
			
			var btn2 = Lampa.Template.get('button_hdon');
			
			info = Lampa.Template.get('info_chanelesi');
		    info.find('#stantion_filtr').append(btn);
		    info.find('#stantion_filtr').append(btn2);
			info.find('.view--category').on('hover:enter hover:click', function () {
				_this2.selectGroup();
			});
			
			
			info.find('.view--hdon').on('hover:enter hover:click', function () {
				_this2.selectGroup2();
			});
			
			
			scroll.render().addClass('layer--wheight').data('mheight', info);
			html.append(info.append());
			html.append(scroll.render());
			this.append(data);
			scroll.append(body);
			this.activity.loader(false);
			this.activity.toggle();
		};
		this.selectGroup = function () {
		  Lampa.Select.show({
				title: 'РљР°С‚РµРіРѕСЂРёРё',
				items: catalogs,
				onSelect: function onSelect(a) {
					Lampa.Activity.push({
						url: a.url,
						title: a.title,
						component: 'chaneles_n',
						page: 1
					});
				},
				onBack: function onBack() {
					Lampa.Controller.toggle('content');
				}
			});
		};
		
		
		this.selectGroup2 = function () {
		  var modal = $('<div class="broadcast__text">РќСЂР°РІРёС‚СЃСЏ РЅР°С€ РїР»Р°РіРёРЅ Рё С…РѕС‡РµС€СЊ РїРѕРґРґРµСЂР¶Р°С‚СЊ?</div><div class="broadcast__text" style="text-align:left;">РџСЂРёРІРµС‚С‹ РЈРІР°Р¶Р°РµРјС‹Рµ РєР°РЅР°Р»Рѕ-Р·СЂРёС‚РµР»Рё! РЎРїР°СЃРёР±Рѕ С‡С‚Рѕ РІСЃРµ РµС‰С‘ РІС‹Р±РёСЂР°РµС‚Рµ РјРѕР№ РїР»Р°РіРёРЅ РґР»СЏ РїСЂРѕСЃРјРѕС‚СЂР° РєР°РЅР°Р»РѕРІ.<br><br>РљР°Рє РЅР°РІРµСЂРЅРѕРµ РІС‹ Р·РЅР°РµС‚Рµ РїР»Р°РіРёРЅ Рё РєР°РЅР°Р»С‹ Р¶РёРІСѓС‚ Рё СЂР°Р±РѕС‚Р°СЋС‚ РЅР° РїРѕР»РЅРѕРј СЌРЅС‚СѓР·РёР°Р·РјРµ Р±РµР· РєР°РєРѕРіРѕ Р»РёР±Рѕ РґРѕС…РѕРґР° СЃ СЌС‚РѕРіРѕ. РџРѕСЌС‚РѕРјСѓ РµСЃР»Рё Сѓ Р’Р°СЃ РµСЃС‚СЊ РєР°РєРѕРµ Р»РёР±Рѕ Р¶РµР»Р°РЅРёРµ Рё РІРѕР·РјРѕР¶РЅРѕСЃС‚СЊ РїРѕРјРѕС‡СЊ РїСЂРѕРµРєС‚Сѓ, Р’С‹ РјРѕР¶РµС‚Рµ Р·Р° РґРѕРЅР°С‚РёС‚СЊ РЅР° РµРіРѕ РґРѕР»СЊРЅРµР№С€РµРµ СЃСѓС‰РµСЃС‚РІРѕРІР°РЅРёРµ Рё СѓР»СѓС‡С€РµРЅРёРµ. Р”Р»СЏ СЌС‚РѕРіРѕ Р±С‹Р» СЃРѕР·РґР°РЅ СЃРїРµС†РёР°Р»СЊРЅРѕ Telegram Р‘РѕС‚ <span style="color:aquamarine;">@RenDonutBot</span> С‡РµСЂРµР· РєРѕС‚РѕСЂРѕРіРѕ Р’С‹ РјРѕР¶РµС‚Рµ РєР°Рє: <span style="font-size: 12.6px;">РЎРІСЏР·Р°С‚СЊСЃСЏ СЃРѕ РјРЅРѕР№ (РµСЃР»Рё Сѓ Р’Р°СЃ РµСЃС‚СЊ Р»РёР±Рѕ Р±СѓРґСѓС‚ РІРѕРїСЂРѕСЃС‹/РїРѕР¶РµР»Р°РЅРёСЏ) Рё РЎРґРµР»Р°С‚СЊ РїРѕР¶РµСЂС‚РІРѕРІР°РЅРёРµ<br><br>РџРѕСЃР»Рµ РїРѕР¶РµСЂС‚РІРѕРІР°РЅРёСЏ РІР°Рј С‚Р°Рє Р¶Рµ Р±СѓРґРµС‚ РґРѕСЃС‚СѓРїРµРЅ РєР°РЅР°Р» РІ РєРѕС‚РѕСЂРѕРј Р±СѓРґСѓС‚ РІСЃРµ РЅРѕРІРѕСЃС‚Рё РїРѕ РЅР°С€РµРјСѓ РїР»Р°РіРёРЅСѓ (РґРѕР±Р°РІР»РµРЅРёСЏ/РёР·РјРµРЅРµРЅРёСЏ РєР°РЅР°Р»РѕРІ) Рё С‚.Рґ.<br>Рђ С‚Р°Рє Р¶Рµ Сѓ РІР°СЃ Р±СѓРґРµС‚ РІРѕР·РјРѕР¶РЅРѕСЃС‚СЊ Р·Р°РєР°Р·Р°С‚СЊ РґРѕР±Р°РІР»РµРЅРёРµ РєР°РЅР°Р»Р°.</span><br><br> РўР°Рє Р¶Рµ РѕР±С‰РёРµ РІРѕРїСЂРѕСЃС‹ РїРѕ РєР°РЅР°Р»РѕРј Рё РґСЂСѓРіРёС… РїР»Р°РіРёРЅРѕРІ СЃРІСЏР·Р°РЅРЅС‹Рµ СЃ РЅРёРјРё РІС‹ РјРѕР¶РµС‚Рµ Р·Р°РґР°С‚СЊ РІ РіСЂСѓРїРїРµ <span style="color:aquamarine;">@lampa_channels</span><div style="height: 25px;">РЎРїР°СЃРёР±Рѕ Р§С‚Рѕ РѕСЃС‚Р°С‘С‚РµСЃСЊ СЃ РЅР°РјРё! <svg xmlns="http://www.w3.org/2000/svg" width="16px" height="16px" fill="currentColor" class="bi bi-balloon-heart" viewBox="0 0 16 16"> <path fill-rule="evenodd" d="m8 2.42-.717-.737c-1.13-1.161-3.243-.777-4.01.72-.35.685-.451 1.707.236 3.062C4.16 6.753 5.52 8.32 8 10.042c2.479-1.723 3.839-3.29 4.491-4.577.687-1.355.587-2.377.236-3.061-.767-1.498-2.88-1.882-4.01-.721L8 2.42Zm-.49 8.5c-10.78-7.44-3-13.155.359-10.063.045.041.089.084.132.129.043-.045.087-.088.132-.129 3.36-3.092 11.137 2.624.357 10.063l.235.468a.25.25 0 1 1-.448.224l-.008-.017c.008.11.02.202.037.29.054.27.161.488.419 1.003.288.578.235 1.15.076 1.629-.157.469-.422.867-.588 1.115l-.004.007a.25.25 0 1 1-.416-.278c.168-.252.4-.6.533-1.003.133-.396.163-.824-.049-1.246l-.013-.028c-.24-.48-.38-.758-.448-1.102a3.177 3.177 0 0 1-.052-.45l-.04.08a.25.25 0 1 1-.447-.224l.235-.468ZM6.013 2.06c-.649-.18-1.483.083-1.85.798-.131.258-.245.689-.08 1.335.063.244.414.198.487-.043.21-.697.627-1.447 1.359-1.692.217-.073.304-.337.084-.398Z"></path></svg></div></div>');
			var enabled = Lampa.Controller.enabled().name;
			Lampa.Modal.open({
				title: '',
				html: modal,
				size: 'medium',
				mask: true,
				onBack: function onBack() {
					Lampa.Modal.close();
					Lampa.Controller.toggle(enabled);
				},
				onSelect: function onSelect() {
					
				}
			});		
		};
		
		
		
		
		
		
		this.start = function () {
			var _this = this;
			Lampa.Controller.add('content', {
				toggle: function toggle() {
					Lampa.Controller.collectionSet(scroll.render());
					Lampa.Controller.collectionFocus(last || false, scroll.render());
				},
				left: function left() {
					if (Navigator.canmove('left')) Navigator.move('left');
					else Lampa.Controller.toggle('menu');
				},
				right: function right() {
					if (Navigator.canmove('right')) Navigator.move('right');
					else _this.selectGroup();
				},
				up: function up() {
					if (Navigator.canmove('up')) {
						Navigator.move('up');
					} else {
					 	if (!info.find('.view--category').hasClass('focus')) {
							if (!info.find('.view--category').hasClass('focus')) {
								Lampa.Controller.collectionSet(info);
					  		Navigator.move('right')
							}
						} else Lampa.Controller.toggle('head');
					}
				},
				down: function down() {
					if (Navigator.canmove('down')) Navigator.move('down');
					else if (info.find('.view--category').hasClass('focus')) {
						 Lampa.Controller.toggle('content');
					} 
				},
				back: function back() {
					Lampa.Activity.backward();
				}
			});
			Lampa.Controller.toggle('content');
		};
		this.pause = function() {};
		this.stop = function() {};
		this.render = function() {
			return html;
		};
		this.destroy = function() {
			network.clear();
			scroll.destroy();
			if (info) info.remove();
			html.remove();
			body.remove();
			network = null;
			items = null;
			html = null;
			body = null;
			info = null;
		};
	}

	function startchaneles_n() {
		window.plugin_chaneles_n_ready = true;
		Lampa.Component.add('chaneles_n', chaneles_n);
		Lampa.Listener.follow('app', function(r) {
			if (r.type == 'ready') {
				var ico = '<img src="http://cdn.kulik.uz/pics/retro-tv.png"/>';
				var menu_items = $('<li class="menu__item selector focus" data-action="chanelesi_r"><div class="menu__ico">' + ico + '</div><div class="menu__text">РљР°РЅР°Р»С‹</div></li>');
				menu_items.on('hover:enter', function() {
					Lampa.Activity.push({
						url: 'http://cdn.kulik.uz/chanls.php?lst=osn',
						title: 'РћСЃРЅРѕРІРЅС‹Рµ',
						component: 'chaneles_n',
						page: 1
					});
				});
				$('.menu .menu__list').eq(0).append(menu_items);
			}
		});
	}
	if (!window.plugin_chaneles_n_ready) startchaneles_n();

//Radio

    function item(data) {
      var item = Lampa.Template.get('radio_item', {
        name: data.title
      });
      var img = item.find('img')[0];

      img.onerror = function () {
        img.src = './img/img_broken.svg';
      };

      img.src = data.icon_gray;

      this.render = function () {
        return item;
      };

      this.destroy = function () {
        img.onerror = function () {};

        img.onload = function () {};

        img.src = '';
        item.remove();
      };
    }

    function create(data) {
      var content = Lampa.Template.get('items_line', {
        title: data.title
      });
      var body = content.find('.items-line__body');
      var scroll = new Lampa.Scroll({
        horizontal: true,
        step: 300
      });
      var player = window.radio_player;
      var items = [];
      var active = 0;
      var last;

      this.create = function () {
        scroll.render().find('.scroll__body').addClass('items-cards');
        content.find('.items-line__title').text(data.title);
        data.results.forEach(this.append.bind(this));
        body.append(scroll.render());
      };

      this.append = function (element) {
        var item$1 = new item(element);
        item$1.render().on('hover:focus', function () {
          last = item$1.render()[0];
          active = items.indexOf(item$1);
          scroll.update(items[active].render(), true);
        }).on('hover:enter', function () {
          player.play(element);
        });
        scroll.append(item$1.render());
        items.push(item$1);
      };

      this.toggle = function () {
        var _this = this;

        Lampa.Controller.add('radio_line', {
          toggle: function toggle() {
            Lampa.Controller.collectionSet(scroll.render());
            Lampa.Controller.collectionFocus(last || false, scroll.render());
          },
          right: function right() {
            Navigator.move('right');
            Lampa.Controller.enable('radio_line');
          },
          left: function left() {
            if (Navigator.canmove('left')) Navigator.move('left');else if (_this.onLeft) _this.onLeft();else Lampa.Controller.toggle('menu');
          },
          down: this.onDown,
          up: this.onUp,
          gone: function gone() {},
          back: this.onBack
        });
        Lampa.Controller.toggle('radio_line');
      };

      this.render = function () {
        return content;
      };

      this.destroy = function () {
        Lampa.Arrays.destroy(items);
        scroll.destroy();
        content.remove();
        items = null;
      };
    }

    function component() {
      var network = new Lampa.Reguest();
      var scroll = new Lampa.Scroll({
        mask: true,
        over: true
      });
      var items = [];
      var html = $('<div></div>');
      var active = 0;

      this.create = function () {
        var _this = this;

        this.activity.loader(true);
        var prox = Lampa.Platform.is('webos') || Lampa.Platform.is('tizen') || Lampa.Storage.field('proxy_other') === false ? '' : 'http://full.lampa32.ru/proxy/';
        network["native"](prox + 'http://www.radiorecord.ru/api/stations/', this.build.bind(this), function () {
          var empty = new Lampa.Empty();
          html.append(empty.render());
          _this.start = empty.start;

          _this.activity.loader(false);

          _this.activity.toggle();
        });
        Lampa.Background.immediately('');
        return this.render();
      };

      this.build = function (data) {
        var _this2 = this;

        scroll.minus();
        html.append(scroll.render());
        data.result.genre.forEach(function (element) {
          var results = data.result.stations.filter(function (station) {
            return station.genre.filter(function (genre) {
              return genre.id == element.id;
            }).length;
          });

          _this2.append({
            title: element.name,
            results: results
          });
        });
        this.activity.loader(false);
        this.activity.toggle();
      };

      this.append = function (element) {
        var item = new create(element);
        item.create();
        item.onDown = this.down.bind(this);
        item.onUp = this.up.bind(this);
        item.onBack = this.back.bind(this);
        scroll.append(item.render());
        items.push(item);
      };

      this.back = function () {
        Lampa.Activity.backward();
      };

      this.down = function () {
        active++;
        active = Math.min(active, items.length - 1);
        items[active].toggle();
        scroll.update(items[active].render());
      };

      this.up = function () {
        active--;

        if (active < 0) {
          active = 0;
          Lampa.Controller.toggle('head');
        } else {
          items[active].toggle();
        }

        scroll.update(items[active].render());
      };

      this.start = function () {
        Lampa.Controller.add('content', {
          toggle: function toggle() {
            if (items.length) {
              items[active].toggle();
            }
          },
          back: this.back
        });
        Lampa.Controller.toggle('content');
      };

      this.pause = function () {};

      this.stop = function () {};

      this.render = function () {
        return html;
      };

      this.destroy = function () {
        network.clear();
        Lampa.Arrays.destroy(items);
        scroll.destroy();
        html.remove();
        items = null;
        network = null;
      };
    }

    function player() {
      var html = Lampa.Template.get('radio_player', {});
      var audio = new Audio();
      var url = '';
      var played = false;
      var hls;
      audio.addEventListener("play", function (event) {
        played = true;
        html.toggleClass('loading', false);
      });

      function prepare() {
        if (audio.canPlayType('application/vnd.apple.mpegurl') || url.indexOf('.aacp') > 0) load();else if (Hls.isSupported()) {
          try {
            hls = new Hls();
            hls.attachMedia(audio);
            hls.loadSource(url);
            hls.on(Hls.Events.ERROR, function (event, data) {
              if (data.details === Hls.ErrorDetails.MANIFEST_PARSING_ERROR) {
                if (data.reason === "no EXTM3U delimiter") {
                  Lampa.Noty.show('РћС€РёР±РєР° РІ Р·Р°РіСЂСѓР·РєРµ РїРѕС‚РѕРєР°');
                }
              }
            });
            hls.on(Hls.Events.MANIFEST_LOADED, function () {
              start();
            });
          } catch (e) {
            Lampa.Noty.show('РћС€РёР±РєР° РІ Р·Р°РіСЂСѓР·РєРµ РїРѕС‚РѕРєР°');
          }
        } else load();
      }

      function load() {
        audio.src = url;
        audio.load();
        start();
      }

      function start() {
        var playPromise;

        try {
          playPromise = audio.play();
        } catch (e) {}

        if (playPromise !== undefined) {
          playPromise.then(function () {
            console.log('Radio', 'start plaining');
          })["catch"](function (e) {
            console.log('Radio', 'play promise error:', e.message);
          });
        }
      }

      function play() {
        html.toggleClass('loading', true);
        html.toggleClass('stop', false);
        prepare();
      }

      function stop() {
        played = false;
        html.toggleClass('stop', true);
        html.toggleClass('loading', false);

        if (hls) {
          hls.destroy();
          hls = false;
        }

        audio.src = '';
      }

      html.on('hover:enter', function () {
        if (played) stop();else if (url) play();
      });

      this.create = function () {
        $('.head__actions .open--search').before(html);
      };

      this.play = function (data) {
        stop();
        url = data.stream_320 ? data.stream_320 : data.stream_128 ? data.stream_128 : data.stream_hls.replace('playlist.m3u8', '96/playlist.m3u8');
        html.find('.radio-player__name').text(data.title);
        html.toggleClass('hide', false);
        play();
      };
    }

    function startPlugin() {
      window.radio = true;
      Lampa.Component.add('radio', component);
      Lampa.Template.add('radio_item', "<div class=\"selector radio-item\">\n        <div class=\"radio-item__imgbox\">\n            <img class=\"radio-item__img\" />\n        </div>\n\n        <div class=\"radio-item__name\">{name}</div>\n    </div>");
      Lampa.Template.add('radio_player', "<div class=\"selector radio-player stop hide\">\n        <div class=\"radio-player__name\">Radio Record</div>\n\n        <div class=\"radio-player__button\">\n            <i></i>\n            <i></i>\n            <i></i>\n            <i></i>\n        </div>\n    </div>");
      Lampa.Template.add('radio_style', "<style>\n    .radio-item {\n        width: 8em;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-item__imgbox {\n        background-color: #3E3E3E;\n        padding-bottom: 83%;\n        position: relative;\n        -webkit-border-radius: 0.3em;\n           -moz-border-radius: 0.3em;\n                border-radius: 0.3em;\n      }\n      .radio-item__img {\n        position: absolute;\n        top: 0;\n        left: 0;\n        width: 100%;\n        height: 100%;\n      }\n      .radio-item__name {\n        font-size: 1.1em;\n        margin-top: 0.8em;\n      }\n      .radio-item.focus .radio-item__imgbox:after {\n        border: solid 0.4em #fff;\n        content: \"\";\n        display: block;\n        position: absolute;\n        left: 0;\n        top: 0;\n        right: 0;\n        bottom: 0;\n        -webkit-border-radius: 0.3em;\n           -moz-border-radius: 0.3em;\n                border-radius: 0.3em;\n      }\n      .radio-item + .radio-item {\n        margin-left: 1em;\n      }\n      \n      @-webkit-keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      \n      @-moz-keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      \n      @-o-keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      \n      @keyframes sound {\n        0% {\n          height: 0.1em;\n        }\n        100% {\n          height: 1em;\n        }\n      }\n      @-webkit-keyframes sound-loading {\n        0% {\n          -webkit-transform: rotate(0deg);\n                  transform: rotate(0deg);\n        }\n        100% {\n          -webkit-transform: rotate(360deg);\n                  transform: rotate(360deg);\n        }\n      }\n      @-moz-keyframes sound-loading {\n        0% {\n          -moz-transform: rotate(0deg);\n               transform: rotate(0deg);\n        }\n        100% {\n          -moz-transform: rotate(360deg);\n               transform: rotate(360deg);\n        }\n      }\n      @-o-keyframes sound-loading {\n        0% {\n          -o-transform: rotate(0deg);\n             transform: rotate(0deg);\n        }\n        100% {\n          -o-transform: rotate(360deg);\n             transform: rotate(360deg);\n        }\n      }\n      @keyframes sound-loading {\n        0% {\n          -webkit-transform: rotate(0deg);\n             -moz-transform: rotate(0deg);\n               -o-transform: rotate(0deg);\n                  transform: rotate(0deg);\n        }\n        100% {\n          -webkit-transform: rotate(360deg);\n             -moz-transform: rotate(360deg);\n               -o-transform: rotate(360deg);\n                  transform: rotate(360deg);\n        }\n      }\n      .radio-player {\n        display: -webkit-box;\n        display: -webkit-flex;\n        display: -moz-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-align: center;\n        -webkit-align-items: center;\n           -moz-box-align: center;\n            -ms-flex-align: center;\n                align-items: center;\n        -webkit-border-radius: 0.3em;\n           -moz-border-radius: 0.3em;\n                border-radius: 0.3em;\n        padding: 0.2em 0.8em;\n        background-color: #3e3e3e;\n      }\n      .radio-player__name {\n        margin-right: 1em;\n        white-space: nowrap;\n        overflow: hidden;\n        -o-text-overflow: ellipsis;\n           text-overflow: ellipsis;\n        max-width: 8em;\n      }\n      @media screen and (max-width: 385px) {\n        .radio-player__name {\n          display: none;\n        }\n      }\n      .radio-player__button {\n        position: relative;\n        width: 1.5em;\n        height: 1.5em;\n        display: -webkit-box;\n        display: -webkit-flex;\n        display: -moz-box;\n        display: -ms-flexbox;\n        display: flex;\n        -webkit-box-align: center;\n        -webkit-align-items: center;\n           -moz-box-align: center;\n            -ms-flex-align: center;\n                align-items: center;\n        -webkit-box-pack: center;\n        -webkit-justify-content: center;\n           -moz-box-pack: center;\n            -ms-flex-pack: center;\n                justify-content: center;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-player__button i {\n        display: block;\n        width: 0.2em;\n        background-color: #fff;\n        margin: 0 0.1em;\n        -webkit-animation: sound 0ms -800ms linear infinite alternate;\n           -moz-animation: sound 0ms -800ms linear infinite alternate;\n             -o-animation: sound 0ms -800ms linear infinite alternate;\n                animation: sound 0ms -800ms linear infinite alternate;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-player__button i:nth-child(1) {\n        -webkit-animation-duration: 474ms;\n           -moz-animation-duration: 474ms;\n             -o-animation-duration: 474ms;\n                animation-duration: 474ms;\n      }\n      .radio-player__button i:nth-child(2) {\n        -webkit-animation-duration: 433ms;\n           -moz-animation-duration: 433ms;\n             -o-animation-duration: 433ms;\n                animation-duration: 433ms;\n      }\n      .radio-player__button i:nth-child(3) {\n        -webkit-animation-duration: 407ms;\n           -moz-animation-duration: 407ms;\n             -o-animation-duration: 407ms;\n                animation-duration: 407ms;\n      }\n      .radio-player__button i:nth-child(4) {\n        -webkit-animation-duration: 458ms;\n           -moz-animation-duration: 458ms;\n             -o-animation-duration: 458ms;\n                animation-duration: 458ms;\n      }\n      .radio-player.stop .radio-player__button {\n        -webkit-border-radius: 100%;\n           -moz-border-radius: 100%;\n                border-radius: 100%;\n        border: 0.2em solid #fff;\n      }\n      .radio-player.stop .radio-player__button i {\n        display: none;\n      }\n      .radio-player.stop .radio-player__button:after {\n        content: \"\";\n        width: 0.5em;\n        height: 0.5em;\n        background-color: #fff;\n      }\n      .radio-player.loading .radio-player__button:before {\n        content: \"\";\n        display: block;\n        border-top: 0.2em solid #fff;\n        border-left: 0.2em solid transparent;\n        border-right: 0.2em solid transparent;\n        border-bottom: 0.2em solid transparent;\n        -webkit-animation: sound-loading 1s linear infinite;\n           -moz-animation: sound-loading 1s linear infinite;\n             -o-animation: sound-loading 1s linear infinite;\n                animation: sound-loading 1s linear infinite;\n        width: 0.9em;\n        height: 0.9em;\n        -webkit-border-radius: 100%;\n           -moz-border-radius: 100%;\n                border-radius: 100%;\n        -webkit-flex-shrink: 0;\n            -ms-flex-negative: 0;\n                flex-shrink: 0;\n      }\n      .radio-player.loading .radio-player__button i {\n        display: none;\n      }\n      .radio-player.focus {\n        background-color: #fff;\n        color: #000;\n      }\n      .radio-player.focus .radio-player__button {\n        border-color: #000;\n      }\n      .radio-player.focus .radio-player__button i, .radio-player.focus .radio-player__button:after {\n        background-color: #000;\n      }\n      .radio-player.focus .radio-player__button:before {\n        border-top-color: #000;\n      }\n    </style>");
      window.radio_player = new player();
      Lampa.Listener.follow('app', function (e) {
        if (e.type == 'ready') {
          var button = $("<li class=\"menu__item selector\" data-action=\"radio\">\n                <div class=\"menu__ico\">\n                    <svg width=\"38\" height=\"31\" viewBox=\"0 0 38 31\" fill=\"none\" xmlns=\"http://www.w3.org/2000/svg\">\n                    <rect x=\"17.613\" width=\"3\" height=\"16.3327\" rx=\"1.5\" transform=\"rotate(63.4707 17.613 0)\" fill=\"white\"/>\n                    <circle cx=\"13\" cy=\"19\" r=\"6\" fill=\"white\"/>\n                    <path fill-rule=\"evenodd\" clip-rule=\"evenodd\" d=\"M0 11C0 8.79086 1.79083 7 4 7H34C36.2091 7 38 8.79086 38 11V27C38 29.2091 36.2092 31 34 31H4C1.79083 31 0 29.2091 0 27V11ZM21 19C21 23.4183 17.4183 27 13 27C8.58173 27 5 23.4183 5 19C5 14.5817 8.58173 11 13 11C17.4183 11 21 14.5817 21 19ZM30.5 18C31.8807 18 33 16.8807 33 15.5C33 14.1193 31.8807 13 30.5 13C29.1193 13 28 14.1193 28 15.5C28 16.8807 29.1193 18 30.5 18Z\" fill=\"white\"/>\n                    </svg>\n                </div>\n                <div class=\"menu__text\">\u0420\u0430\u0434\u0438\u043E</div>\n            </li>");
          button.on('hover:enter', function () {
            Lampa.Activity.push({
              url: '',
              title: 'Р Р°РґРёРѕ',
              component: 'radio',
              page: 1
            });
          });
          $('.menu .menu__list').eq(0).append(button);
          $('body').append(Lampa.Template.get('radio_style', {}, true));
          window.radio_player.create();
        }
      });
    }

    if (!window.radio) startPlugin();

		Lampa.Listener.follow('app',(e)=>{
        if(e.type == 'ready'){
			setTimeout(function(){
				$("[data-action=radio]").eq(0).remove();
			},10); 
        }
    });

Lampa.Template.add('remove_lang_ua', '<style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(2){opacity: 0%!important;display: none;}</style>');
$('body').append(Lampa.Template.get('remove_lang_ua', {}, true));


})();