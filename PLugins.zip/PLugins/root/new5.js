'use strict';
/** @type {function(!Object): ?} */
var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function(exclude) {
  return typeof exclude;
} : function(obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};
(function() {
  /**
   * @param {!Object} data
   * @return {?}
   */
  function warn(data) {
    return !(!data.length || !data[0].tv || !data[0].plugin || data[0].plugin !== event.component);
  }
  /**
   * @param {number} target
   * @param {boolean} action
   * @return {?}
   */
  function init(target, action) {
    if (!Lampa.Player.opened()) {
      return false;
    }
    var list = Lampa.PlayerPlaylist.get();
    if (!warn(list)) {
      return false;
    }
    if (!$("body>.js-ch-" + event.component).length) {
      $("body").append(handle).append(frame);
    }
    var max = list.length;
    var origValue = value;
    value = value + target;
    /** @type {number} */
    var index = parseInt(value);
    if (index && index <= max) {
      if (!!_takingTooLongTimeout) {
        clearTimeout(_takingTooLongTimeout);
      }
      /** @type {boolean} */
      stopRemoveChElement = true;
      mElmOrSub.text(list[index - 1].title);
      if (action || parseInt(value + "0") > max) {
        frame.finish().hide().fadeOut(0);
      } else {
        /** @type {!Array} */
        var drilldownLevelLabels = [];
        /** @type {number} */
        var last = 9;
        /** @type {number} */
        var length = parseInt(value + "0");
        /** @type {number} */
        var i = length;
        for (; i <= max && i <= length + Math.min(last, 9); i++) {
          drilldownLevelLabels.push(a.text(list[i - 1].title).html());
        }
        jQFooter.html(drilldownLevelLabels.join("<br>"));
        frame.finish().show().fadeIn(0);
      }
      if (index < 10 || action) {
        handle.finish().show().fadeIn(0);
      }
      /** @type {boolean} */
      stopRemoveChElement = false;
      /**
       * @return {undefined}
       */
      var disableColorPicker = function show() {
        /** @type {number} */
        var j = index - 1;
        if (Lampa.PlayerPlaylist.position() !== j) {
          Lampa.PlayerPlaylist.listener.send("select", {
            playlist : list,
            position : j,
            item : list[j]
          });
        }
        handle.delay(1000).fadeOut(500, function() {
          if (!stopRemoveChElement) {
            handle.remove();
          }
        });
        frame.delay(1000).fadeOut(500, function() {
          if (!stopRemoveChElement) {
            frame.remove();
          }
        });
        /** @type {string} */
        value = "";
      };
      if (action === true) {
        /** @type {number} */
        _takingTooLongTimeout = setTimeout(disableColorPicker, 1000);
        /** @type {string} */
        value = "";
      } else {
        if (parseInt(value + "0") > max) {
          disableColorPicker();
        } else {
          /** @type {number} */
          _takingTooLongTimeout = setTimeout(disableColorPicker, 3000);
        }
      }
    } else {
      value = origValue;
    }
    return true;
  }
  /**
   * @param {string} j
   * @param {?} type
   * @param {number} index
   * @return {?}
   */
  function guessPreview(j, type, index) {
    /** @type {number} */
    var controlsCount = new Date * 1;
    if (!!index && index > 0) {
      /** @type {!Array} */
      indexes[j] = [controlsCount + index, type];
      return;
    }
    if (!!indexes[j] && indexes[j][0] > controlsCount) {
      return indexes[j][1];
    }
    delete indexes[j];
    return type;
  }
  /**
   * @return {?}
   */
  function now() {
    return Math.floor(((new Date).getTime() + timeOffset) / 1000);
  }
  /**
   * @param {number} utc
   * @return {?}
   */
  function date(utc) {
    /** @type {!Date} */
    var dTempDate = new Date;
    /** @type {number} */
    var whiteRating = parseInt(Lampa.Storage.get("time_offset", "n0").replace("n", ""));
    utc = utc || dTempDate.getTime();
    /** @type {!Date} */
    dTempDate = new Date(utc + whiteRating * 1000 * 60 * 60);
    return ("0" + dTempDate.getHours()).substr(-2) + ":" + ("0" + dTempDate.getMinutes()).substr(-2);
  }
  /**
   * @param {number} expires
   * @return {?}
   */
  function save(expires) {
    /** @type {!Date} */
    var t2 = new Date;
    /** @type {number} */
    var whiteRating = parseInt(Lampa.Storage.get("time_offset", "n0").replace("n", ""));
    expires = expires || t2.getTime();
    /** @type {!Date} */
    t2 = new Date(expires + whiteRating * 1000 * 60 * 60);
    return t2.toLocaleDateString();
  }
  /**
   * @param {string} media
   * @return {?}
   */
  function load(media) {
    var children = now();
    return children + ":" + item.md5((media || "") + children + item.uid());
  }
  /**
   * @param {string} str
   * @param {!Object} obj
   * @return {?}
   */
  function format(str, obj) {
    var p;
    for (p in obj) {
      str = str.replace(new RegExp(p.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"), obj[p]);
    }
    return str;
  }
  /**
   * @param {number} dicts
   * @param {string} opt
   * @param {?} pos
   * @param {number} value
   * @return {?}
   */
  function generator(dicts, opt, pos, value) {
    opt = opt || "";
    /** @type {number} */
    value = parseInt(value || "0");
    /** @type {number} */
    var sum2 = 0;
    /** @type {number} */
    sum2 = sum2 + value * 60;
    if (!pos) {
      /** @type {number} */
      sum2 = sum2 + (parseInt(Lampa.Storage.get("time_offset", "n0").replace("n", "")) * 60 - (new Date).getTimezoneOffset());
    }
    /** @type {!Date} */
    var d = new Date((dicts + sum2) * 6e4);
    var maps = {
      yyyy : d.getUTCFullYear(),
      MM : ("0" + (d.getUTCMonth() + 1)).substr(-2),
      dd : ("0" + d.getUTCDate()).substr(-2),
      HH : ("0" + d.getUTCHours()).substr(-2),
      mm : ("0" + d.getUTCMinutes()).substr(-2),
      ss : ("0" + d.getUTCSeconds()).substr(-2),
      UTF : dicts * 6e4
    };
    return format(opt, maps);
  }
  /**
   * @param {string} result
   * @param {number} input
   * @return {?}
   */
  function callback(result, input) {
    /** @type {!Array} */
    var data = [];
    /** @type {string} */
    var html = "";
    var options = {
      start : now,
      offset : 0
    };
    if (input && input.length) {
      options = {
        start : input[0] * 60,
        utc : input[0] * 60,
        end : (input[0] + input[1]) * 60,
        utcend : (input[0] + input[1]) * 60,
        offset : now() - input[0] * 60,
        duration : input[1] * 60,
        now : now,
        lutc : now,
        d : function changeListener(event) {
          return format(event[6] || "", {
            M : input[1],
            S : input[1] * 60,
            h : Math.floor(input[1] / 60),
            m : ("0" + input[1] % 60).substr(-2),
            s : "00"
          });
        },
        b : function getValue(callbackId) {
          return generator(input[0], callbackId[6], callbackId[4], callbackId[5]);
        },
        e : function run(footage) {
          return generator(input[0] + input[1], footage[6], footage[4], footage[5]);
        },
        n : function run(footage) {
          return generator(now() / 60, footage[6], footage[4], footage[5]);
        }
      };
    }
    for (; !!(data = result.match(/\${(\((([a-zA-Z\d]+?)(u)?)([+-]\d+)?\))?([^${}]+)}/));) {
      if (!!data[2] && typeof options[data[2]] === "function") {
        html = options[data[2]](data);
      } else {
        if (!!data[3] && typeof options[data[3]] === "function") {
          html = options[data[3]](data);
        } else {
          if (data[6] in options) {
            html = typeof options[data[6]] === "function" ? options[data[6]]() : options[data[6]];
          } else {
            if (!!data[2] && typeof item[data[2]] === "function") {
              html = item[data[2]](data[6]);
            } else {
              if (data[6] in item) {
                html = typeof item[data[6]] === "function" ? item[data[6]]() : item[data[6]];
              } else {
                html = data[1];
              }
            }
          }
        }
      }
      result = result.replace(data[0], encodeURIComponent(html));
    }
    return result;
  }
  /**
   * @param {string} key
   * @param {string} name
   * @param {string} text
   * @return {?}
   */
  function parse(key, name, text) {
    name = (name || "").toLowerCase();
    text = text || "";
    if (!name) {
      if (!!text) {
        if (text.search(/^https?:\/\//i) === 0) {
          /** @type {string} */
          name = "default";
        } else {
          if (text.search(/^[?&/][^/]/) === 0) {
            /** @type {string} */
            name = "append";
          } else {
            /** @type {string} */
            name = "default";
          }
        }
      } else {
        if (key.indexOf("${") < 0) {
          /** @type {string} */
          name = "shift";
        } else {
          /** @type {string} */
          name = "default";
        }
      }
      console.log(event.name, 'Autodetect catchup-type "' + name + '"');
    }
    /** @type {string} */
    var value = "";
    switch(name) {
      case "append":
        if (text) {
          value = (text.search(/^https?:\/\//i) === 0 ? "" : key) + text;
          break;
        }
      case "timeshift":
      case "shift":
        value = text || key;
        /** @type {string} */
        value = value + ((value.indexOf("?") >= 0 ? "&" : "?") + "utc=${start}&lutc=${timestamp}");
        return value;
      case "flussonic":
      case "flussonic-hls":
      case "flussonic-ts":
      case "fs":
        return key.replace(/\/video\.(m3u8|ts)/, "/video-${start}-${duration}.$1").replace(/\/(index|playlist)\.(m3u8|ts)/, "/archive-${start}-${duration}.$2").replace(/\/mpegts/, "/timeshift_abs-${start}.ts");
      case "xc":
        value = key.replace(/^(https?:\/\/[^/]+)(\/live)?(\/[^/]+\/[^/]+\/)([^/.]+)\.m3u8?$/, "$1/timeshift$3${(d)M}/${(b)yyyy-MM-dd:HH-mm}/$4.m3u8").replace(/^(https?:\/\/[^/]+)(\/live)?(\/[^/]+\/[^/]+\/)([^/.]+)(\.ts|)$/, "$1/timeshift$3${(d)M}/${(b)yyyy-MM-dd:HH-mm}/$4.ts");
        break;
      case "default":
        value = text || key;
        break;
      case "disabled":
        return false;
      default:
        console.log(event.name, 'Err: no support catchup-type="' + name + '"');
        return false;
    }
    if (value.indexOf("${") < 0) {
      return parse(value, "shift");
    }
    return value;
  }
  /**
   * @param {!Function} mixin
   * @param {!Object} options
   * @return {?}
   */
  function next(mixin, options) {
    /** @type {number} */
    var count = 1;
    /** @type {number} */
    var timeout = 1;
    var fn;
    var callback;
    /**
     * @return {undefined}
     */
    var noop = function indexOf() {
    };
    if ((typeof options === "undefined" ? "undefined" : _typeof(options)) === "object") {
      timeout = options.timeout || timeout;
      callback = options.onBulk || noop;
      fn = options.onEnd || noop;
      count = options.bulk || count;
    } else {
      if (typeof options === "number") {
        /** @type {!Object} */
        count = options;
        if (typeof arguments[2] === "number") {
          timeout = arguments[2];
        }
      } else {
        if (typeof options === "function") {
          /** @type {!Object} */
          callback = options;
          if (typeof arguments[2] === "number") {
            count = arguments[2];
          }
          if (typeof arguments[3] === "number") {
            timeout = arguments[3];
          }
        }
      }
    }
    if (!count || count < 1) {
      /** @type {number} */
      count = 1;
    }
    if (typeof fn !== "function") {
      /** @type {function(): undefined} */
      fn = noop;
    }
    if (typeof callback !== "function") {
      /** @type {function(): undefined} */
      callback = noop;
    }
    var component = this;
    /** @type {!Array} */
    var obj = [];
    var initializeCheckTimer;
    /** @type {number} */
    var result = 0;
    /**
     * @return {undefined}
     */
    var reduceAll = function _next() {
      if (!!obj.length && !initializeCheckTimer) {
        /** @type {number} */
        initializeCheckTimer = setInterval(function() {
          /** @type {number} */
          var i = 0;
          for (; obj.length && ++i <= count;) {
            mixin.apply(component, obj.shift());
          }
          /** @type {number} */
          i = obj.length ? i : i - 1;
          result = result + i;
          callback.apply(component, [i, result, obj.length]);
          if (!obj.length) {
            clearInterval(initializeCheckTimer);
            /** @type {null} */
            initializeCheckTimer = null;
            fn.apply(component, [i, result, obj.length]);
          }
        }, timeout || 0);
      }
    };
    return function() {
      obj.push(arguments);
      reduceAll();
    };
  }
  /**
   * @param {string} methodName
   * @param {number} value
   * @return {?}
   */
  function invoke(methodName, value) {
    /** @type {string} */
    var key = ["epg", methodName].join("\t");
    var info = sessionStorage.getItem(key);
    if (info) {
      /** @type {*} */
      info = JSON.parse(info);
      if (value) {
        if (info.length && (value < info[0][0] || value > info[info.length - 1][0] + info[info.length - 1][1])) {
          return false;
        }
        for (; info.length && value >= info[0][0] + info[0][1];) {
          info.shift();
        }
      }
    }
    return info;
  }
  /**
   * @param {string} selector
   * @param {?} data
   * @return {undefined}
   */
  function add(selector, data) {
    /** @type {string} */
    var bithost = ["epg", selector].join("\t");
    sessionStorage.setItem(bithost, JSON.stringify(data));
  }
  /**
   * @param {string} cmd
   * @param {!Function} done
   * @param {!Function} callback
   * @param {string} name
   * @return {undefined}
   */
  function exec(cmd, done, callback, name) {
    var _self = this;
    /** @type {string} */
    var key = ["cache", cmd, name ? item.md5(JSON.stringify(name)) : ""].join("\t");
    var json = sessionStorage.getItem(key);
    if (json) {
      /** @type {*} */
      json = JSON.parse(json);
      if (json[0]) {
        if (typeof done === "function") {
          done.apply(_self, [json[1]]);
        }
      } else {
        if (typeof callback === "function") {
          callback.apply(_self, [json[1]]);
        }
      }
    } else {
      var args = new Lampa.Reguest;
      args.silent(cmd, function(data) {
        sessionStorage.setItem(key, JSON.stringify([true, data]));
        if (typeof done === "function") {
          done.apply(_self, [data]);
        }
      }, function(url) {
        sessionStorage.setItem(key, JSON.stringify([false, url]));
        if (typeof callback === "function") {
          callback.apply(_self, [url]);
        }
      }, name);
    }
  }
  /**
   * @param {!Object} scope
   * @return {undefined}
   */
  function create(scope) {
    /**
     * @param {string} name
     * @return {?}
     */
    function exec(name) {
      /** @type {number} */
      var value = Math.floor(now() / 60);
      /** @type {number} */
      var i = Math.floor(value / 60);
      var data;
      var temp;
      if (!!hash[name] && i >= hash[name][0] && i <= hash[name][1]) {
        data = hash[name][2];
        if (!data || !data.length || data.length >= 3) {
          return;
        }
        temp = data[data.length - 1];
        value = temp[0] + temp[1];
        /** @type {number} */
        var varend = Math.floor(value / 60);
        if (varend - i > 6 || varend <= hash[name][1]) {
          return;
        }
        /** @type {number} */
        i = varend;
      }
      if (!!hash[name]) {
        data = hash[name][2];
        if ((typeof data === "undefined" ? "undefined" : _typeof(data)) !== "object") {
          return;
        }
        if (data.length) {
          temp = data[data.length - 1];
          value = temp[0] + temp[1];
          /** @type {number} */
          var position = Math.max(i, Math.floor(value / 60));
          if (i < position && data.length >= 3) {
            return;
          }
          /** @type {number} */
          i = position;
        }
        /** @type {number} */
        hash[name][1] = i;
      } else {
        /** @type {!Array} */
        hash[name] = [i, i, false];
      }
      /**
       * @param {!Array} indices
       * @return {undefined}
       */
      var cb = function subdivideSpheroid(indices) {
        if (hash[name][2] === false) {
          /** @type {!Array} */
          hash[name][2] = [];
        }
        /** @type {number} */
        var i = 0;
        for (; i < indices.length; i++) {
          if (value < indices[i][0] + indices[i][1]) {
            hash[name][2].push.apply(hash[name][2], indices.slice(i));
            break;
          }
        }
        add(name, hash[name][2]);
        parse(name);
      };
      /**
       * @return {undefined}
       */
      var dir = function create_list_of_search_results() {
        if (hash[name][2] === false) {
          /** @type {!Array} */
          hash[name][2] = [];
        }
        add(name, hash[name][2]);
        parse(name);
      };
      if (hash[name][2] === false) {
        var result = invoke(name, value);
        if (!!result) {
          return cb(result);
        }
      }
      self.silent("//epg.rootu.top/api/epg/" + name + "/hour/" + i, cb, dir);
    }
    /**
     * @param {string} name
     * @return {undefined}
     */
    function parse(name) {
      var a = (hash[name] || [0, 0, []])[2];
      if (a === false) {
        return;
      }
      var self = fields.find("[data-epg-id=" + name + "] .card__age");
      if (!self.length) {
        return;
      }
      /** @type {number} */
      var time = Math.floor(now() / 60);
      /** @type {boolean} */
      var enableCardEpg = false;
      /** @type {number} */
      var c = 0;
      var d;
      var p;
      var value;
      var attrValue;
      for (; a.length && time >= a[0][0] + a[0][1];) {
        a.shift();
      }
      if (a.length) {
        d = a[0];
        if (time >= d[0] && time < d[0] + d[1]) {
          c++;
          /** @type {boolean} */
          enableCardEpg = true;
          /** @type {number} */
          p = Math.round((now() - d[0] * 60) * 100 / (d[1] * 60 || 60));
          value = d[0] + "_" + self.length;
          attrValue = self.data("cId") || "";
          if (attrValue !== value) {
            self.data("cId", value);
            self.data("progress", p);
            self.find(".js-epgTitle").text(d[2]);
            self.find(".js-epgProgress").css("width", p + "%");
            self.show();
          } else {
            if (self.data("progress") !== p) {
              self.data("progress", p);
              self.find(".js-epgProgress").css("width", p + "%");
            }
          }
        }
      }
      if (symbol === name) {
        var self = $("#" + event.component + "_epg");
        var vm = self.find(".js-epgNow");
        /** @type {string} */
        value = name + "_" + a.length + (a.length ? "_" + a[0][0] : "");
        attrValue = self.data("cId") || "";
        if (attrValue !== value) {
          self.data("cId", value);
          var searchContactPanel = self.find(".js-epgAfter");
          if (c) {
            var result = date(d[0] * 60000);
            var mtime = date((d[0] + d[1]) * 60000);
            vm.data("progress", p);
            vm.find(".js-epgProgress").css("width", p + "%");
            vm.find(".js-epgTime").text(result);
            vm.find(".js-epgTitle").text(d[2]);
            /** @type {string} */
            var desc = d[3] ? "<p>" + a.text(d[3]).html() + "</p>" : "";
            vm.find(".js-epgDesc").html(desc.replace(/\n/g, "</p><p>"));
            vm.show();
            info.find(".info__create").html(result + "-" + mtime + " &bull; " + a.text(d[2]).html());
          } else {
            info.find(".info__create").html("");
            vm.hide();
          }
          if (a.length > c) {
            var list = searchContactPanel.find(".js-epgList");
            list.empty();
            /** @type {number} */
            var complexSize = Math.min(a.length, 8);
            for (; c < complexSize; c++) {
              d = a[c];
              var item = cmd_arg_element.clone();
              item.find(".js-epgTime").text(date(d[0] * 60000));
              item.find(".js-epgTitle").text(d[2]);
              list.append(item);
            }
            searchContactPanel.show();
          } else {
            searchContactPanel.hide();
          }
        } else {
          if (c && vm.data("progress") !== p) {
            vm.data("progress", p);
            vm.find(".js-epgProgress").css("width", p + "%");
          }
        }
      }
      if (!enableCardEpg) {
        self.hide();
      }
      if (a.length < 3) {
        exec(name);
      }
    }
    if (scope.id !== val) {
      map = {};
      fallback = {};
      val = scope.id;
    }
    hash = {};
    /** @type {string} */
    var symbol = "";
    var ret = set("favorite" + scope.id, "[]");
    var self = new Lampa.Reguest;
    var form = new Lampa.Scroll({
      mask : true,
      over : true,
      step : 250
    });
    var $module = $("<div></div>");
    var fields = $('<div class="' + event.component + ' category-full"></div>');
    var info;
    var c;
    if (initializeCheckTimer) {
      clearInterval(initializeCheckTimer);
    }
    /** @type {number} */
    initializeCheckTimer = setInterval(function() {
      var prop;
      for (prop in hash) {
        parse(prop);
      }
    }, 1000);
    /**
     * @return {?}
     */
    this.create = function() {
      var self = this;
      this.activity.loader(true);
      /**
       * @return {undefined}
       */
      var dir = function render() {
        var cur = new Lampa.Empty;
        $module.append(cur.render());
        self.start = cur.start;
        self.activity.loader(false);
        self.activity.toggle();
      };
      if (Object.keys(map).length) {
        self.build(!map[scope.currentGroup] ? rules[scope.id].groups.length > 1 && map[rules[scope.id].groups[1].key] ? map[rules[scope.id].groups[1].key]["channels"] : [] : map[scope.currentGroup]["channels"]);
      } else {
        if (!rules[scope.id] || !scope.url) {
          dir();
          return;
        } else {
          /** @type {number} */
          var load = 2;
          var objects = {};
          var data;
          /**
           * @param {string} inData
           * @return {undefined}
           */
          var cb = function setData(inData) {
            /** @type {string} */
            data = inData;
            if (!--load) {
              writeDataToElement();
            }
          };
          if (!timeOffsetSet) {
            load++;
            (function() {
              /** @type {number} */
              var minY = (new Date).getTime();
              self.silent("//epg.rootu.top/api/time", function(y) {
                /** @type {number} */
                var maxY = (new Date).getTime();
                /** @type {number} */
                timeOffset = y < minY || y > maxY ? y - maxY : 0;
                /** @type {boolean} */
                timeOffsetSet = true;
                cb(data);
              }, function() {
                /** @type {boolean} */
                timeOffsetSet = true;
                cb(data);
              });
            })();
          }
          /**
           * @param {string} option
           * @return {?}
           */
          var sendXhrResponse = function url(option) {
            return option.toLowerCase().replace(/\s+\((\+\d+)\)/g, " $1").replace(/^\u0442\u0435\u043b\u0435\u043a\u0430\u043d\u0430\u043b\s+/, "").replace(/[!\s.,()\u24e2\u24d6\u2013-]+/g, " ").trim().replace(/\s(\u043a\u0430\u043d\u0430\u043b|\u0442\u0432)(\s.+|\s*)$/, "$2").replace(/\s(50|orig|original)$/, "").replace(/\s(\d+)/g, "$1");
          };
          var parents = {
            "\u0451" : "e",
            "\u0443" : "y",
            "\u043a" : "k",
            "\u0435" : "e",
            "\u043d" : "h",
            "\u0448" : "w",
            "\u0437" : "3",
            "\u0445" : "x",
            "\u044b" : "bl",
            "\u0432" : "b",
            "\u0430" : "a",
            "\u0440" : "p",
            "\u043e" : "o",
            "\u0447" : "4",
            "\u0441" : "c",
            "\u043c" : "m",
            "\u0442" : "t",
            "\u044c" : "b",
            "\u0431" : "6"
          };
          /**
           * @param {string} to
           * @return {?}
           */
          var String = function _getColorizedPrefix(to) {
            return to.split("").map(function(p) {
              return parents[p] || p;
            }).join("");
          };
          /**
           * @param {string} result
           * @param {boolean} defer
           * @return {?}
           */
          var filterArrayValues = function handle(result, defer) {
            var val = sendXhrResponse(result);
            var i;
            var key;
            if (val === "" || !objects[val[0]] && !defer) {
              return 0;
            }
            i = val[0];
            if (!!objects[i]) {
              if (!!objects[i][val]) {
                return objects[i][val];
              }
              val = String(val);
              if (!!objects[i][val]) {
                return objects[i][val];
              }
              for (key in objects[i]) {
                if (val === String(key)) {
                  return objects[i][key];
                }
              }
            }
            if (val[0] !== i && !!objects[val[0]]) {
              i = val[0];
              if (!!objects[i][val]) {
                return objects[i][val];
              }
              for (key in objects[i]) {
                if (val === String(key)) {
                  return objects[i][key];
                }
              }
            } else {
              var j;
              for (j in parents) {
                if (parents[j] === i && !!objects[j]) {
                  for (key in objects[j]) {
                    if (val === String(key)) {
                      return objects[j][key];
                    }
                  }
                }
              }
            }
            return 0;
          };
          self.silent("//epg.rootu.top/api/channels", function(results) {
            objects = results;
            cb(data);
          }, function() {
            cb(data);
          });
          /**
           * @return {undefined}
           */
          var writeDataToElement = function init() {
            if (typeof data != "string" || data.substr(0, 7).toUpperCase() !== "#EXTM3U") {
              dir();
              return;
            }
            map = {
              "" : {
                title : get("favorites"),
                channels : []
              }
            };
            /** @type {!Array} */
            rules[scope.id].groups = [{
              title : get("favorites"),
              key : ""
            }];
            /** @type {!Array<string>} */
            var theseCookies = data.split(/\r?\n/);
            /** @type {number} */
            var k = 0;
            /** @type {number} */
            var i = 1;
            /** @type {number} */
            var j = 0;
            var format;
            var charsetMatch;
            /** @type {string} */
            var message = titleSome;
            if (!!(format = theseCookies[0].match(/([^\s=]+)=((["'])(.*?)\3|\S+)/g))) {
              /** @type {number} */
              var formatPointer = 0;
              for (; formatPointer < format.length; formatPointer++) {
                if (!!(charsetMatch = format[formatPointer].match(/([^\s=]+)=((["'])(.*?)\3|\S+)/))) {
                  /** @type {string} */
                  fallback[charsetMatch[1].toLowerCase()] = charsetMatch[4] || charsetMatch[2];
                }
              }
            }
            for (; i < theseCookies.length;) {
              /** @type {number} */
              j = k + 1;
              var data = {
                ChNum : j,
                Title : "Ch " + j,
                isYouTube : false,
                Url : "",
                Group : "",
                Options : {}
              };
              for (; k < j && i < theseCookies.length; i++) {
                if (!!(format = theseCookies[i].match(/^#EXTGRP:\s*(.+?)\s*$/i)) && format[1].trim() !== "") {
                  /** @type {string} */
                  message = format[1].trim();
                } else {
                  if (!!(format = theseCookies[i].match(/^#EXTINF:\s*-?\d+(\s+\S.*?\s*)?,(.+)$/i))) {
                    /** @type {string} */
                    data.Title = format[2].trim();
                    if (!!format[1] && !!(format = format[1].match(/([^\s=]+)=((["'])(.*?)\3|\S+)/g))) {
                      /** @type {number} */
                      var formatPointer = 0;
                      for (; formatPointer < format.length; formatPointer++) {
                        if (!!(charsetMatch = format[formatPointer].match(/([^\s=]+)=((["'])(.*?)\3|\S+)/))) {
                          /** @type {string} */
                          data[charsetMatch[1].toLowerCase()] = charsetMatch[4] || charsetMatch[2];
                        }
                      }
                    }
                  } else {
                    if (!!(format = theseCookies[i].match(/^#EXTVLCOPT:\s*([^\s=]+)=(.+)$/i))) {
                      /** @type {string} */
                      data.Options[format[1].trim().toLowerCase()] = format[2].trim();
                    } else {
                      if (!!(format = theseCookies[i].match(/^(https?):\/\/(.+)$/i))) {
                        /** @type {string} */
                        data.Url = format[0].trim();
                        /** @type {boolean} */
                        data.isYouTube = !!format[2].match(/^(www\.)?youtube\.com/);
                        data.Group = data["group-title"] || message;
                        k++;
                      }
                    }
                  }
                }
              }
              if (!!data.Url && !data.isYouTube) {
                if (!map[data.Group]) {
                  map[data.Group] = {
                    title : data.Group,
                    channels : []
                  };
                  rules[scope.id].groups.push({
                    title : data.Group,
                    key : data.Group
                  });
                }
                data["epgId"] = filterArrayValues(data["Title"], true);
                data["Title"] = data["Title"].replace("\u24e2", "").replace("\u24d6", "").replace(/\s+/g, " ").trim();
                if (data["epgId"]) {
                  /** @type {string} */
                  data["tvg-logo"] = "//epg.it999.ru/img2/" + data["epgId"] + ".png";
                }
                if (!data["tvg-logo"] && data["Title"] !== "Ch " + j) {
                  /** @type {string} */
                  data["tvg-logo"] = "//epg.rootu.top/picon/" + encodeURIComponent(data["Title"]) + ".png";
                }
                map[data.Group].channels.push(data);
                var name = ret.indexOf(getValue(data.Title));
                if (name !== -1) {
                  map[""].channels[name] = data;
                }
              }
            }
            /** @type {number} */
            i = 0;
            for (; i < rules[scope.id].groups.length; i++) {
              var e = rules[scope.id].groups[i];
              e.title += " [" + map[e.key].channels.length + "]";
            }
            /** @type {number} */
            i = 0;
            for (; i < ret.length; i++) {
              if (!map[""].channels[i]) {
                map[""].channels[i] = {
                  ChNum : -1,
                  Title : "#" + ret[i],
                  isYouTube : false,
                  Url : "//epg.rootu.top/empty/_.m3u8",
                  Group : "",
                  Options : {},
                  "tvg-logo" : "//epg.rootu.top/empty/_.gif"
                };
              }
            }
            self.build(!map[scope.currentGroup] ? rules[scope.id].groups.length > 1 && !!map[rules[scope.id].groups[1].key] ? map[rules[scope.id].groups[1].key]["channels"] : [] : map[scope.currentGroup]["channels"]);
          };
          var result = callback(scope.url);
          self.native(result, cb, function() {
            self.silent("//epg.rootu.top/cors.php?url=" + encodeURIComponent(result) + "&uid=" + item.uid() + "&sig=" + load(result), cb, dir, false, {
              dataType : "text"
            });
          }, false, {
            dataType : "text"
          });
        }
      }
      return this.render();
    };
    /**
     * @param {!Object} value
     * @return {undefined}
     */
    this.append = function(value) {
      /** @type {!Array} */
      var hours = [];
      /** @type {number} */
      var silverlightCount = 0;
      var context = this;
      /** @type {boolean} */
      var lazyLoadImg = "loading" in HTMLImageElement.prototype;
      var cb = next(function(data) {
        /** @type {number} */
        var end = silverlightCount++;
        var item = Lampa.Template.get("card", {
          title : data.Title,
          release_year : ""
        });
        item.addClass("card--collection");
        var me = item.find(".card__img")[0];
        if (lazyLoadImg) {
          /** @type {string} */
          me.loading = end < 18 ? "eager" : "lazy";
        }
        /**
         * @return {undefined}
         */
        me.onload = function() {
          item.addClass("card--loaded");
        };
        /**
         * @param {?} event
         * @return {undefined}
         */
        me.onerror = function(event) {
          /** @type {string} */
          me.src = "./img/img_broken.svg";
          /** @type {string} */
          data["tvg-logo"] = "";
        };
        me.src = data["tvg-logo"] || "./img/img_broken.svg";
        var $node_runner_indicator = $('<div class="card__icon icon--book hide"></div>');
        item.find(".card__icons-inner").append($node_runner_indicator);
        if (parseInt(data["catchup-days"] || data["tvg-rec"] || "0") > 0) {
          item.find(".card__icons-inner").append('<div class="card__icon icon--timeshift"></div>');
        }
        item.find(".card__age").html('<div class="card__epg-progress js-epgProgress"></div><div class="card__epg-title js-epgTitle"></div>');
        if (scope.currentGroup !== "" && ret.indexOf(getValue(data.Title)) !== -1) {
          $node_runner_indicator.toggleClass("hide", false);
        }
        /** @type {number} */
        var max = parseInt(data["catchup-days"] || data["tvg-rec"] || data["timeshift"] || fallback["catchup-days"] || fallback["tvg-rec"] || fallback["timeshift"] || "0");
        item.on("hover:focus hover:hover touchstart", function(parentEvent) {
          c = item[0];
          if (parentEvent.type && parentEvent.type !== "touchstart") {
            form.update(item, !true);
          }
          info.find(".info__title-original").text(data.Title);
          var $sharepreview = $("#" + event.component + "_epg");
          $sharepreview.find(".js-epgChannel").text(data.Title);
          if (!data["epgId"]) {
            info.find(".info__create").empty();
            /** @type {string} */
            symbol = "";
            $sharepreview.find(".js-epgNow").hide();
            $sharepreview.find(".js-epgAfter").hide();
          } else {
            symbol = data["epgId"];
            parse(data["epgId"]);
          }
        }).on("hover:enter", function() {
          var params = {
            title : data.Title,
            url : callback(data.Url),
            plugin : event.component,
            tv : true
          };
          /** @type {!Array} */
          var req = [];
          /** @type {!Array} */
          var list = [];
          /** @type {number} */
          var start = 0;
          value.forEach(function(data) {
            var id = start < end ? value.length - end + start : start - end;
            var requestOrUrl = start === end ? params.url : callback(data.Url);
            list[id] = {
              title : data.Title,
              url : requestOrUrl,
              tv : true
            };
            req.push({
              title : ++start + ". " + data.Title,
              url : requestOrUrl,
              plugin : event.component,
              tv : true
            });
          });
          /** @type {!Array} */
          params["playlist"] = list;
          Lampa.Player.play(params);
          Lampa.Player.playlist(req);
        }).on("hover:long", function() {
          var i = ret.indexOf(getValue(data.Title));
          /** @type {boolean} */
          var returnSingular = scope.currentGroup === "";
          /** @type {!Array} */
          var values = [];
          if (max > 0) {
            if (!!data["epgId"] && !!hash[data["epgId"]] && hash[data["epgId"]][2].length) {
              values.push({
                title : "\u0421\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0441\u043d\u0430\u0447\u0430\u043b\u0430",
                restartProgram : true
              });
            }
            values.push({
              title : "\u0410\u0440\u0445\u0438\u0432",
              archive : true
            });
          }
          values.push({
            title : i === -1 ? get("favorites_add") : get("favorites_del"),
            favToggle : true
          });
          if (returnSingular && ret.length) {
            if (i !== 0) {
              values.push({
                title : get("favorites_move_top"),
                favMove : true,
                i : 0
              });
              values.push({
                title : get("favorites_move_up"),
                favMove : true,
                i : i - 1
              });
            }
            if (i + 1 !== ret.length) {
              values.push({
                title : get("favorites_move_down"),
                favMove : true,
                i : i + 1
              });
              values.push({
                title : get("favorites_move_end"),
                favMove : true,
                i : ret.length - 1
              });
            }
            values.push({
              title : get("favorites_clear"),
              favClear : true
            });
          }
          values.push({
            title : set("epg", "false") ? get("epg_off") : get("epg_on"),
            epgToggle : true
          });
          Lampa.Select.show({
            title : Lampa.Lang.translate("title_action"),
            items : values,
            onSelect : function init(params) {
              if (!!params.archive) {
                var ts = now();
                /** @type {number} */
                var m = Math.floor(ts / 60);
                /** @type {number} */
                var lastCutIndex = Math.floor(ts / 86400);
                /** @type {number} */
                var n = max + 1;
                /** @type {number} */
                var remain = n;
                /** @type {number} */
                var numNewParticles = m - max * 1440;
                /** @type {!Array} */
                var tables = [];
                /** @type {!Array} */
                var playlist = [];
                /** @type {number} */
                var x = 0;
                /**
                 * @return {undefined}
                 */
                var noop = function render() {
                  if (--remain) {
                    return;
                  }
                  /** @type {number} */
                  var i = tables.length - 1;
                  for (; i >= 0; i--) {
                    if (tables[i].length === 0) {
                      /** @type {number} */
                      var newentry_ = (lastCutIndex - i) * 1440;
                      /** @type {number} */
                      var entryName = 0;
                      for (; entryName < 1440; entryName = entryName + 30) {
                        tables[i].push([newentry_ + entryName, 30, save((newentry_ + entryName) * 6e4), ""]);
                      }
                    }
                    /** @type {number} */
                    var key = 0;
                    for (; key < tables[i].length; key++) {
                      var xs = tables[i][key];
                      if (xs[0] === x || xs[0] > m || xs[0] + xs[1] < numNewParticles) {
                        continue;
                      }
                      x = xs[0];
                      var result = parse(data.Url, data["catchup"] || data["catchup-type"] || fallback["catchup"] || fallback["catchup-type"], data["catchup-source"] || fallback["catchup-source"]);
                      playlist.push({
                        title : date(xs[0] * 6e4) + " - " + xs[2],
                        url : callback(result, xs),
                        catchupUrl : result,
                        epg : xs
                      });
                    }
                  }
                  /** @type {!Array} */
                  tables = [];
                  Lampa.Select.show({
                    title : "\u0410\u0440\u0445\u0438\u0432",
                    items : playlist.slice().reverse(),
                    onSelect : function init(topSite) {
                      console.log(event.name, "catchupUrl: " + topSite.catchupUrl, xs.slice(0, 2));
                      var last_viewed_item = {
                        title : topSite.title,
                        url : topSite.url,
                        playlist : playlist
                      };
                      Lampa.Player.play(last_viewed_item);
                      Lampa.Player.playlist(playlist);
                    },
                    onBack : function onResize() {
                      Lampa.Controller.toggle("content");
                    }
                  });
                };
                for (; n--;) {
                  /** @type {!Array} */
                  tables[n] = [];
                  (function() {
                    var i = n;
                    exec("//epg.rootu.top/api/epg/" + data["epgId"] + "/day/" + (lastCutIndex - i), function(res) {
                      tables[i] = res;
                      noop();
                    }, noop);
                  })();
                }
              } else {
                if (!!params.restartProgram) {
                  var key = hash[data["epgId"]][2][0];
                  var script = data["catchup"] || data["catchup-type"] || fallback["catchup"] || fallback["catchup-type"] || "";
                  var result = parse(data.Url, script, data["catchup-source"] || fallback["catchup-source"]);
                  /** @type {boolean} */
                  var flussonic = script.search(/^flussonic/i) === 0;
                  if (flussonic) {
                    result = result.replace("${(d)S}", "now");
                  }
                  console.log(event.name, "catchupUrl: " + result, key.slice(0, 2));
                  var params = {
                    title : data.Title,
                    url : callback(result, key),
                    plugin : event.component,
                    catchupUrl : result,
                    epg : key
                  };
                  if (flussonic) {
                    params["timeline"] = {
                      time : 11,
                      percent : 0,
                      duration : key[1] * 60
                    };
                  }
                  Lampa.Player.play(params);
                } else {
                  if (!!params.epgToggle) {
                    /** @type {boolean} */
                    key = !set("epg", false);
                    remove("epg", key);
                    var curTable = item.parents(".scroll");
                    if (key) {
                      curTable.css({
                        float : "left",
                        width : "70%"
                      });
                      curTable.parent().append(linkCont);
                    } else {
                      curTable.css({
                        float : "none",
                        width : "100%"
                      });
                      $("#" + event.component + "_epg").remove();
                    }
                    Lampa.Controller.toggle("content");
                  } else {
                    var e = rules[scope.id].groups[0];
                    if (!!params.favToggle) {
                      if (i === -1) {
                        i = ret.length;
                        ret[i] = getValue(data.Title);
                        /** @type {!Object} */
                        map[e.key].channels[i] = data;
                      } else {
                        ret.splice(i, 1);
                        map[e.key].channels.splice(i, 1);
                      }
                    } else {
                      if (!!params.favClear) {
                        /** @type {!Array} */
                        ret = [];
                        /** @type {!Array} */
                        map[e.key].channels = [];
                      } else {
                        if (!!params.favMove) {
                          ret.splice(i, 1);
                          ret.splice(params.i, 0, getValue(data.Title));
                          map[e.key].channels.splice(i, 1);
                          map[e.key].channels.splice(params.i, 0, data);
                        }
                      }
                    }
                    remove("favorite" + scope.id, ret);
                    /** @type {string} */
                    e.title = map[e.key].title + " [" + map[e.key].channels.length + "]";
                    if (returnSingular) {
                      Lampa.Activity.replace(Lampa.Arrays.clone(rules[scope.id].activity));
                    } else {
                      $node_runner_indicator.toggleClass("hide", ret.indexOf(getValue(data.Title)) === -1);
                      Lampa.Controller.toggle("content");
                    }
                  }
                }
              }
            },
            onBack : function onResize() {
              Lampa.Controller.toggle("content");
            }
          });
        });
        fields.append(item);
        if (!!data["epgId"]) {
          item.attr("data-epg-id", data["epgId"]);
          parse(data["epgId"]);
        }
      }, {
        bulk : 18,
        onEnd : function detach(oldChrome, newChrome, detachRange) {
          context.activity.loader(false);
          context.activity.toggle();
        }
      });
      value.forEach(function(nodes) {
        cb(nodes);
        if (!!nodes["epgId"] && hours.indexOf(nodes["epgId"]) === -1) {
          hours.push(nodes["epgId"]);
        }
      });
      /** @type {string} */
      var val = hours.sort(function(b, a) {
        return b - a;
      }).join("-");
      var base16 = item.md5(val);
    };
    /**
     * @param {!Object} value
     * @return {undefined}
     */
    this.build = function(value) {
      var $scope = this;
      Lampa.Background.change();
      Lampa.Template.add(event.component + "_button_category", "<style>@media screen and (max-width: 2560px) {." + event.component + " .card--collection {width: 16.6%!important;}}@media screen and (max-width: 800px) {." + event.component + " .card--collection {width: 24.6%!important;}}@media screen and (max-width: 500px) {." + event.component + ' .card--collection {width: 33.3%!important;}}</style><div class="full-start__button selector view--category"><svg style="enable-background:new 0 0 512 512;" version="1.1" viewBox="0 0 24 24" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><g id="info"/><g id="icons"><g id="menu"><path d="M20,10H4c-1.1,0-2,0.9-2,2c0,1.1,0.9,2,2,2h16c1.1,0,2-0.9,2-2C22,10.9,21.1,10,20,10z" fill="currentColor"/><path d="M4,8h12c1.1,0,2-0.9,2-2c0-1.1-0.9-2-2-2H4C2.9,4,2,4.9,2,6C2,7.1,2.9,8,4,8z" fill="currentColor"/><path d="M16,16H4c-1.1,0-2,0.9-2,2c0,1.1,0.9,2,2,2h12c1.1,0,2-0.9,2-2C18,16.9,17.1,16,16,16z" fill="currentColor"/></g></g></svg><span>' + 
      get("categories") + "</span>\n\t</div>");
      Lampa.Template.add(event.component + "_info_radio", '<div class="info layer--width"><div class="info__left"><div class="info__title"></div><div class="info__title-original"></div><div class="info__create"></div></div><div class="info__right" style="display: flex !important;">  <div id="stantion_filtr"></div></div></div>');
      var ipb_session_id = Lampa.Template.get(event.component + "_button_category");
      info = Lampa.Template.get(event.component + "_info_radio");
      info.find("#stantion_filtr").append(ipb_session_id);
      info.find(".view--category").on("hover:enter hover:click", function() {
        $scope.selectGroup();
      });
      info.find(".info__title").text(!map[scope.currentGroup] ? "" : map[scope.currentGroup].title);
      info.find(".info__title-original").text("");
      $module.append(info.append());
      if (value.length) {
        form.render().addClass("layer--wheight").data("mheight", info);
        $module.append(form.render());
        this.append(value);
        if (set("epg", false)) {
          form.render().css({
            float : "left",
            width : "70%"
          });
          form.render().parent().append(linkCont);
        }
        form.append(fields);
        remove("last_catalog" + scope.id, scope.currentGroup);
        rules[scope.id].activity.currentGroup = scope.currentGroup;
      } else {
        var mipAd = new Lampa.Empty;
        $module.append(mipAd.render());
        this.activity.loader(false);
        Lampa.Controller.collectionSet(info);
        Navigator.move("right");
      }
    };
    /**
     * @return {undefined}
     */
    this.selectGroup = function() {
      var data = Lampa.Arrays.clone(rules[scope.id].activity);
      Lampa.Select.show({
        title : get("categories"),
        items : Lampa.Arrays.clone(rules[scope.id].groups),
        onSelect : function onResize(item) {
          if (scope.currentGroup !== item.key) {
            data.currentGroup = item.key;
            Lampa.Activity.replace(data);
          } else {
            Lampa.Controller.toggle("content");
          }
        },
        onBack : function onResize() {
          Lampa.Controller.toggle("content");
        }
      });
    };
    /**
     * @return {undefined}
     */
    this.start = function() {
      if (Lampa.Activity.active().activity !== this.activity) {
        return;
      }
      var $scope = this;
      Lampa.Controller.add("content", {
        toggle : function onResize() {
          Lampa.Controller.collectionSet(form.render());
          Lampa.Controller.collectionFocus(c || false, form.render());
        },
        left : function start() {
          if (Navigator.canmove("left")) {
            Navigator.move("left");
          } else {
            Lampa.Controller.toggle("menu");
          }
        },
        right : function moveBalls() {
          if (Navigator.canmove("right")) {
            Navigator.move("right");
          } else {
            $scope.selectGroup();
          }
        },
        up : function up() {
          if (Navigator.canmove("up")) {
            Navigator.move("up");
          } else {
            if (!info.find(".view--category").hasClass("focus")) {
              Lampa.Controller.collectionSet(info);
              Navigator.move("right");
            } else {
              Lampa.Controller.toggle("head");
            }
          }
        },
        down : function start() {
          if (Navigator.canmove("down")) {
            Navigator.move("down");
          } else {
            if (info.find(".view--category").hasClass("focus")) {
              Lampa.Controller.toggle("content");
            }
          }
        },
        back : function callbackWrapper() {
          Lampa.Activity.backward();
        }
      });
      Lampa.Controller.toggle("content");
    };
    /**
     * @return {undefined}
     */
    this.pause = function() {
    };
    /**
     * @return {undefined}
     */
    this.stop = function() {
    };
    /**
     * @return {?}
     */
    this.render = function() {
      return $module;
    };
    /**
     * @return {undefined}
     */
    this.destroy = function() {
      self.clear();
      form.destroy();
      if (info) {
        info.remove();
      }
      if (initializeCheckTimer) {
        clearInterval(initializeCheckTimer);
      }
      $module.remove();
      fields.remove();
      /** @type {null} */
      ret = null;
      /** @type {null} */
      self = null;
      /** @type {null} */
      $module = null;
      /** @type {null} */
      fields = null;
      /** @type {null} */
      info = null;
    };
  }
  /**
   * @param {string} type
   * @param {?} module
   * @return {undefined}
   */
  function require(type, module) {
    methods[event.component + "_" + type] = module;
  }
  /**
   * @param {string} key
   * @return {?}
   */
  function get(key) {
    return Lampa.Lang.translate(event.component + "_" + key);
  }
  /**
   * @param {string} p2
   * @return {?}
   */
  function getValue(p2) {
    return p2.toLowerCase().replace(/[\s!-\/:-@\[-`{-~]+/g, "");
  }
  /**
   * @param {string} value
   * @param {string} title
   * @return {?}
   */
  function set(value, title) {
    return Lampa.Storage.get(event.component + "_" + value, title);
  }
  /**
   * @param {string} userid
   * @param {string} data
   * @param {?} instruction
   * @return {?}
   */
  function remove(userid, data, instruction) {
    return Lampa.Storage.set(event.component + "_" + userid, data, instruction);
  }
  /**
   * @param {string} f
   * @return {?}
   */
  function test(f) {
    return Lampa.Storage.field(event.component + "_" + f);
  }
  /**
   * @param {string} type
   * @param {!Object} config
   * @return {undefined}
   */
  function render(type, config) {
    var options = {
      component : event.component,
      param : {
        name : event.component + "_" + config.name,
        type : type,
        values : !config.values ? "" : config.values,
        placeholder : !config.placeholder ? "" : config.placeholder,
        default : typeof config.default === "undefined" ? "" : config.default
      },
      field : {
        name : !config.title ? !config.name ? "" : config.name : config.title
      }
    };
    if (!!config.name) {
      /** @type {string} */
      options.param.name = event.component + "_" + config.name;
    }
    if (!!config.description) {
      options.field.description = config.description;
    }
    if (!!config.onChange) {
      options.onChange = config.onChange;
    }
    if (!!config.onRender) {
      options.onRender = config.onRender;
    }
    Lampa.SettingsApi.addParam(options);
  }
  /**
   * @param {number} i
   * @return {?}
   */
  function open(i) {
    render("title", {
      title : get("settings_playlist_num_group") + (i + 1)
    });
    /** @type {string} */
    var undefined = "list " + (i + 1);
    var params = {
      id : i,
      url : "",
      title : event.name,
      groups : [],
      currentGroup : set("last_catalog" + i, get("default_playlist_cat")),
      component : event.component,
      page : 1
    };
    render("input", {
      title : get("settings_list_name"),
      name : "list_name_" + i,
      default : i ? "\u0412\u0430\u0448 \u0434\u043e\u043f\u043e\u043b\u043d\u0438\u0442\u0435\u043b\u044c\u043d\u044b\u0439 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442" : event.name,
      placeholder : i ? undefined : "",
      description : get("settings_list_name_desc"),
      onChange : function render(options) {
        var url = !options ? i ? undefined : event.name : options;
        $(".js-" + event.component + "-menu" + i + "-title").text(url);
        /** @type {string} */
        params.title = url + (url === event.name ? "" : " - " + event.name);
      }
    });
    render("input", {
      title : get("settings_list_url"),
      name : "list_url_" + i,
      default : i ? "" : get("default_playlist"),
      placeholder : i ? "http://example.com/list.m3u8" : "",
      description : i ? !set("list_url_" + i) ? get("settings_list_url_desc1") : "" : get("settings_list_url_desc0"),
      onChange : function onChange(url) {
        if (url === params.url) {
          return;
        }
        if (params.id === val) {
          map = {};
          /** @type {number} */
          val = -1;
        }
        if (/^https?:\/\/./i.test(url)) {
          /** @type {string} */
          params.url = url;
          $(".js-" + event.component + "-menu" + i).show();
        } else {
          /** @type {string} */
          params.url = "";
          $(".js-" + event.component + "-menu" + i).hide();
        }
      }
    });
    var error = test("list_name_" + i);
    var result = test("list_url_" + i);
    var name = error || undefined;
    /** @type {string} */
    params.title = name + (name === event.name ? "" : " - " + event.name);
    var menuEl = $('<li class="menu__item selector js-' + event.component + "-menu" + i + '">' + '<div class="menu__ico">' + event.icon + "</div>" + '<div class="menu__text js-' + event.component + "-menu" + i + '-title">' + a.text(name).html() + "</div>" + "</li>").hide().on("hover:enter", function() {
      if (Lampa.Activity.active().component === event.component) {
        Lampa.Activity.replace(Lampa.Arrays.clone(params));
      } else {
        Lampa.Activity.push(Lampa.Arrays.clone(params));
      }
    });
    if (/^https?:\/\/./i.test(result)) {
      params.url = result;
      menuEl.show();
    }
    rules.push({
      activity : params,
      menuEl : menuEl,
      groups : []
    });
    return !params.url ? i + 1 : i;
  }
  /**
   * @return {undefined}
   */
  function destroy() {
    if (!!window["plugin_" + event.component + "_ready"]) {
      return;
    }
    /** @type {boolean} */
    window["plugin_" + event.component + "_ready"] = true;
    var top_vals_el = $(".menu .menu__list").eq(0);
    /** @type {number} */
    var i = 0;
    for (; i < rules.length; i++) {
      top_vals_el.append(rules[i].menuEl);
    }
  }
  var event = {
    component : "diesel_iptv",
    icon : '<svg height="244" viewBox="0 0 260 244" xmlns="http://www.w3.org/2000/svg" style="fill-rule:evenodd;" fill="currentColor"><path d="M259.5 47.5v114c-1.709 14.556-9.375 24.723-23 30.5a2934.377 2934.377 0 0 1-107 1.5c-35.704.15-71.37-.35-107-1.5-13.625-5.777-21.291-15.944-23-30.5v-115c1.943-15.785 10.61-25.951 26-30.5a10815.71 10815.71 0 0 1 208 0c15.857 4.68 24.523 15.18 26 31.5zm-230-13a4963.403 4963.403 0 0 0 199 0c5.628 1.128 9.128 4.462 10.5 10 .667 40 .667 80 0 120-1.285 5.618-4.785 8.785-10.5 9.5-66 .667-132 .667-198 0-5.715-.715-9.215-3.882-10.5-9.5-.667-40-.667-80 0-120 1.35-5.18 4.517-8.514 9.5-10z"/><path d="M70.5 71.5c17.07-.457 34.07.043 51 1.5 5.44 5.442 5.107 10.442-1 15-5.991.5-11.991.666-18 .5.167 14.337 0 28.671-.5 43-3.013 5.035-7.18 6.202-12.5 3.5a11.529 11.529 0 0 1-3.5-4.5 882.407 882.407 0 0 1-.5-42c-5.676.166-11.343 0-17-.5-4.569-2.541-6.069-6.375-4.5-11.5 1.805-2.326 3.972-3.992 6.5-5zM137.5 73.5c4.409-.882 7.909.452 10.5 4a321.009 321.009 0 0 0 16 30 322.123 322.123 0 0 0 16-30c2.602-3.712 6.102-4.879 10.5-3.5 5.148 3.334 6.314 7.834 3.5 13.5a1306.032 1306.032 0 0 0-22 43c-5.381 6.652-10.715 6.652-16 0a1424.647 1424.647 0 0 0-23-45c-1.691-5.369-.191-9.369 4.5-12zM57.5 207.5h144c7.788 2.242 10.288 7.242 7.5 15a11.532 11.532 0 0 1-4.5 3.5c-50 .667-100 .667-150 0-6.163-3.463-7.496-8.297-4-14.5 2.025-2.064 4.358-3.398 7-4z"/></svg>',
    name : "\u0414\u0438\u0437\u0435\u043b\u044c \u0422\u0412"
  };
  /** @type {!Array} */
  var rules = [];
  /** @type {number} */
  var val = -1;
  /** @type {string} */
  var titleSome = "Other";
  var map = {};
  var fallback = {};
  var hash = {};
  var initializeCheckTimer;
  /** @type {string} */
  var result = "";
  /** @type {string} */
  var value = "";
  /** @type {null} */
  var _takingTooLongTimeout = null;
  /** @type {boolean} */
  var stopRemoveChElement = false;
  var handle = $(('<div class="player-info info--visible js-ch-PLUGIN" style="top: 9em;right: auto;z-index: 1000;">\n' + '\t<div class="player-info__body">\n' + '\t\t<div class="player-info__line">\n' + '\t\t\t<div class="player-info__name">&nbsp;</div>\n' + "\t\t</div>\n" + "\t</div>\n" + "</div>").replace(/PLUGIN/g, event.component)).hide().fadeOut(0);
  var frame = $(('<div class="player-info info--visible js-ch-PLUGIN" style="top: 14em;right: auto;z-index: 1000;">\n' + '\t<div class="player-info__body">\n' + '\t\t<div class="tv-helper"></div>\n' + "\t</div>\n" + "</div>").replace(/PLUGIN/g, event.component)).hide().fadeOut(0);
  var linkCont = $(('<div id="PLUGIN_epg">\n' + '<h2 class="js-epgChannel"></h2>\n' + '<div class="PLUGIN-details__program-body js-epgNow">\n' + '   <div class="PLUGIN-details__program-title">\u0412 \u044d\u0444\u0438\u0440\u0435</div>\n' + '   <div class="PLUGIN-details__program-list">' + '<div class="PLUGIN-program selector">\n' + '   <div class="PLUGIN-program__time js-epgTime">XX:XX</div>\n' + '   <div class="PLUGIN-program__body">\n' + '\t   <div class="PLUGIN-program__title js-epgTitle"> </div>\n' + 
  '\t   <div class="PLUGIN-program__progressbar"><div class="PLUGIN-program__progress js-epgProgress" style="width: 50%"></div></div>\n' + "   </div>\n" + "</div>" + "   </div>\n" + '   <div class="PLUGIN-program__desc js-epgDesc"></div>' + "</div>" + '<div class="PLUGIN-details__program-body js-epgAfter">\n' + '   <div class="PLUGIN-details__program-title">\u0414\u0430\u043b\u0435\u0435</div>\n' + '   <div class="PLUGIN-details__program-list js-epgList">' + "   </div>\n" + "</div>" + "</div>").replace(/PLUGIN/g, 
  event.component));
  var cmd_arg_element = $(('<div class="PLUGIN-program selector">\n' + '   <div class="PLUGIN-program__time js-epgTime">XX:XX</div>\n' + '   <div class="PLUGIN-program__body">\n' + '\t   <div class="PLUGIN-program__title js-epgTitle"> </div>\n' + "   </div>\n" + "</div>").replace(/PLUGIN/g, event.component));
  var jQFooter = frame.find(".tv-helper");
  var mElmOrSub = handle.find(".player-info__name");
  var a = $("<div/>");
  var indexes = {};
  /** @type {number} */
  var timeOffset = 0;
  /** @type {boolean} */
  var timeOffsetSet = false;
  var item = {
    uid : function lexicalOrder() {
      return result;
    },
    timestamp : now,
    token : function load() {
      return load(Lampa.Storage.field("account_email").toLowerCase());
    }
  };
  !function(root) {
    /**
     * @param {number} a
     * @param {number} b
     * @return {?}
     */
    function $(a, b) {
      /** @type {number} */
      var r = (65535 & a) + (65535 & b);
      return (a >> 16) + (b >> 16) + (r >> 16) << 16 | 65535 & r;
    }
    /**
     * @param {number} x
     * @param {number} n
     * @return {?}
     */
    function render(x, n) {
      return x << n | x >>> 32 - n;
    }
    /**
     * @param {number} elem
     * @param {number} options
     * @param {number} data
     * @param {number} e
     * @param {number} name
     * @param {number} id
     * @return {?}
     */
    function startTimer(elem, options, data, e, name, id) {
      return $(render($($(options, elem), $(e, id)), name), data);
    }
    /**
     * @param {number} t
     * @param {number} b
     * @param {number} a
     * @param {number} e
     * @param {undefined} name
     * @param {number} fn
     * @param {number} data
     * @return {?}
     */
    function g(t, b, a, e, name, fn, data) {
      return startTimer(b & a | ~b & e, t, b, name, fn, data);
    }
    /**
     * @param {number} ctx
     * @param {number} n
     * @param {number} t
     * @param {number} a
     * @param {undefined} s
     * @param {number} fn
     * @param {number} ms
     * @return {?}
     */
    function format(ctx, n, t, a, s, fn, ms) {
      return startTimer(n & a | t & ~a, ctx, n, s, fn, ms);
    }
    /**
     * @param {number} ctx
     * @param {number} x
     * @param {number} t
     * @param {number} f
     * @param {undefined} fn
     * @param {number} msg
     * @param {number} ms
     * @return {?}
     */
    function setTimeout(ctx, x, t, f, fn, msg, ms) {
      return startTimer(x ^ t ^ f, ctx, x, fn, msg, ms);
    }
    /**
     * @param {number} ctx
     * @param {number} c
     * @param {number} d
     * @param {number} a
     * @param {undefined} fn
     * @param {number} name
     * @param {number} arg1
     * @return {?}
     */
    function f(ctx, c, d, a, fn, name, arg1) {
      return startTimer(d ^ (c | ~a), ctx, c, fn, name, arg1);
    }
    /**
     * @param {!Object} b
     * @param {number} a
     * @return {?}
     */
    function i(b, a) {
      b[a >> 5] |= 128 << a % 32;
      /** @type {number} */
      b[14 + (a + 64 >>> 9 << 4)] = a;
      var j;
      var e;
      var d;
      var next;
      var t;
      /** @type {number} */
      var p = 1732584193;
      /** @type {number} */
      var c = -271733879;
      /** @type {number} */
      var n = -1732584194;
      /** @type {number} */
      var i = 271733878;
      /** @type {number} */
      j = 0;
      for (; j < b.length; j = j + 16) {
        e = p;
        d = c;
        next = n;
        t = i;
        c = f(c = f(c = f(c = f(c = setTimeout(c = setTimeout(c = setTimeout(c = setTimeout(c = format(c = format(c = format(c = format(c = g(c = g(c = g(c = g(c, n = g(n, i = g(i, p = g(p, c, n, i, b[j], 7, -680876936), c, n, b[j + 1], 12, -389564586), p, c, b[j + 2], 17, 606105819), i, p, b[j + 3], 22, -1044525330), n = g(n, i = g(i, p = g(p, c, n, i, b[j + 4], 7, -176418897), c, n, b[j + 5], 12, 1200080426), p, c, b[j + 6], 17, -1473231341), i, p, b[j + 7], 22, -45705983), n = g(n, i = g(i, p = 
        g(p, c, n, i, b[j + 8], 7, 1770035416), c, n, b[j + 9], 12, -1958414417), p, c, b[j + 10], 17, -42063), i, p, b[j + 11], 22, -1990404162), n = g(n, i = g(i, p = g(p, c, n, i, b[j + 12], 7, 1804603682), c, n, b[j + 13], 12, -40341101), p, c, b[j + 14], 17, -1502002290), i, p, b[j + 15], 22, 1236535329), n = format(n, i = format(i, p = format(p, c, n, i, b[j + 1], 5, -165796510), c, n, b[j + 6], 9, -1069501632), p, c, b[j + 11], 14, 643717713), i, p, b[j], 20, -373897302), n = format(n, i = 
        format(i, p = format(p, c, n, i, b[j + 5], 5, -701558691), c, n, b[j + 10], 9, 38016083), p, c, b[j + 15], 14, -660478335), i, p, b[j + 4], 20, -405537848), n = format(n, i = format(i, p = format(p, c, n, i, b[j + 9], 5, 568446438), c, n, b[j + 14], 9, -1019803690), p, c, b[j + 3], 14, -187363961), i, p, b[j + 8], 20, 1163531501), n = format(n, i = format(i, p = format(p, c, n, i, b[j + 13], 5, -1444681467), c, n, b[j + 2], 9, -51403784), p, c, b[j + 7], 14, 1735328473), i, p, b[j + 12], 
        20, -1926607734), n = setTimeout(n, i = setTimeout(i, p = setTimeout(p, c, n, i, b[j + 5], 4, -378558), c, n, b[j + 8], 11, -2022574463), p, c, b[j + 11], 16, 1839030562), i, p, b[j + 14], 23, -35309556), n = setTimeout(n, i = setTimeout(i, p = setTimeout(p, c, n, i, b[j + 1], 4, -1530992060), c, n, b[j + 4], 11, 1272893353), p, c, b[j + 7], 16, -155497632), i, p, b[j + 10], 23, -1094730640), n = setTimeout(n, i = setTimeout(i, p = setTimeout(p, c, n, i, b[j + 13], 4, 681279174), c, n, b[j], 
        11, -358537222), p, c, b[j + 3], 16, -722521979), i, p, b[j + 6], 23, 76029189), n = setTimeout(n, i = setTimeout(i, p = setTimeout(p, c, n, i, b[j + 9], 4, -640364487), c, n, b[j + 12], 11, -421815835), p, c, b[j + 15], 16, 530742520), i, p, b[j + 2], 23, -995338651), n = f(n, i = f(i, p = f(p, c, n, i, b[j], 6, -198630844), c, n, b[j + 7], 10, 1126891415), p, c, b[j + 14], 15, -1416354905), i, p, b[j + 5], 21, -57434055), n = f(n, i = f(i, p = f(p, c, n, i, b[j + 12], 6, 1700485571), c, 
        n, b[j + 3], 10, -1894986606), p, c, b[j + 10], 15, -1051523), i, p, b[j + 1], 21, -2054922799), n = f(n, i = f(i, p = f(p, c, n, i, b[j + 8], 6, 1873313359), c, n, b[j + 15], 10, -30611744), p, c, b[j + 6], 15, -1560198380), i, p, b[j + 13], 21, 1309151649), n = f(n, i = f(i, p = f(p, c, n, i, b[j + 4], 6, -145523070), c, n, b[j + 11], 10, -1120210379), p, c, b[j + 2], 15, 718787259), i, p, b[j + 9], 21, -343485551);
        p = $(p, e);
        c = $(c, d);
        n = $(n, next);
        i = $(i, t);
      }
      return [p, c, n, i];
    }
    /**
     * @param {!Object} input
     * @return {?}
     */
    function s(input) {
      var i;
      /** @type {string} */
      var b = "";
      /** @type {number} */
      var inputsSize = 32 * input.length;
      /** @type {number} */
      i = 0;
      for (; i < inputsSize; i = i + 8) {
        /** @type {string} */
        b = b + String.fromCharCode(input[i >> 5] >>> i % 32 & 255);
      }
      return b;
    }
    /**
     * @param {string} s
     * @return {?}
     */
    function replace(s) {
      var i;
      /** @type {!Array} */
      var array = [];
      array[(s.length >> 2) - 1] = void 0;
      /** @type {number} */
      i = 0;
      for (; i < array.length; i = i + 1) {
        /** @type {number} */
        array[i] = 0;
      }
      /** @type {number} */
      var cell_amount = 8 * s.length;
      /** @type {number} */
      i = 0;
      for (; i < cell_amount; i = i + 8) {
        array[i >> 5] |= (255 & s.charCodeAt(i / 8)) << i % 32;
      }
      return array;
    }
    /**
     * @param {string} c
     * @return {?}
     */
    function c(c) {
      return s(i(replace(c), 8 * c.length));
    }
    /**
     * @param {string} n
     * @param {string} message
     * @return {?}
     */
    function callback(n, message) {
      var index;
      var e;
      var str = replace(n);
      /** @type {!Array} */
      var args = [];
      /** @type {!Array} */
      var attribs = [];
      args[15] = attribs[15] = void 0;
      if (str.length > 16) {
        str = i(str, 8 * n.length);
      }
      /** @type {number} */
      index = 0;
      for (; index < 16; index = index + 1) {
        /** @type {number} */
        args[index] = 909522486 ^ str[index];
        /** @type {number} */
        attribs[index] = 1549556828 ^ str[index];
      }
      return e = i(args.concat(replace(message)), 512 + 8 * message.length), s(i(attribs.concat(e), 640));
    }
    /**
     * @param {string} s
     * @return {?}
     */
    function expect(s) {
      var a;
      var i;
      /** @type {string} */
      var chain = "";
      /** @type {number} */
      i = 0;
      for (; i < s.length; i = i + 1) {
        a = s.charCodeAt(i);
        /** @type {string} */
        chain = chain + ("0123456789abcdef".charAt(a >>> 4 & 15) + "0123456789abcdef".charAt(15 & a));
      }
      return chain;
    }
    /**
     * @param {string} value
     * @return {?}
     */
    function concat(value) {
      return unescape(encodeURIComponent(value));
    }
    /**
     * @param {string} o
     * @return {?}
     */
    function resolve(o) {
      return c(concat(o));
    }
    /**
     * @param {string} prop
     * @return {?}
     */
    function insert(prop) {
      return expect(resolve(prop));
    }
    /**
     * @param {string} left
     * @param {string} key
     * @return {?}
     */
    function build(left, key) {
      return callback(concat(left), concat(key));
    }
    /**
     * @param {string} start
     * @param {string} data
     * @return {?}
     */
    function cb(start, data) {
      return expect(build(start, data));
    }
    /**
     * @param {string} state
     * @param {string} args
     * @param {?} name
     * @return {?}
     */
    function exports(state, args, name) {
      return args ? name ? build(args, state) : cb(args, state) : name ? resolve(state) : insert(state);
    }
    if ("function" == typeof define && define.amd) {
      define(function() {
        return exports;
      });
    } else {
      if ("object" == (typeof module === "undefined" ? "undefined" : _typeof(module)) && module.exports) {
        /** @type {function(string, string, ?): ?} */
        module.exports = exports;
      } else {
        /** @type {function(string, string, ?): ?} */
        root.md5 = exports;
      }
    }
  }(item);
  Lampa.Keypad.listener.destroy();
  Lampa.Keypad.listener.follow("keydown", function(event) {
    var arg = event.code;
    if (Lampa.Player.opened() && !$("body.selectbox--open").length) {
      var message = Lampa.PlayerPlaylist.get();
      if (!warn(message)) {
        return;
      }
      /** @type {boolean} */
      var idea = false;
      var type = guessPreview("curCh") || Lampa.PlayerPlaylist.position() + 1;
      if (arg === 428 || arg === 34 || (arg === 37 || arg === 4) && !$(".player.tv .panel--visible .focus").length) {
        type = type === 1 ? message.length : type - 1;
        guessPreview("curCh", type, 1000);
        idea = init(type, true);
      } else {
        if (arg === 427 || arg === 33 || (arg === 39 || arg === 5) && !$(".player.tv .panel--visible .focus").length) {
          type = type === message.length ? 1 : type + 1;
          guessPreview("curCh", type, 1000);
          idea = init(type, true);
        } else {
          if (arg >= 48 && arg <= 57) {
            idea = init(arg - 48);
          } else {
            if (arg >= 96 && arg <= 105) {
              idea = init(arg - 96);
            }
          }
        }
      }
      if (idea) {
        event.event.preventDefault();
        event.event.stopPropagation();
      }
    }
  });
  Lampa.Template.add(event.component + "_style", "<style>#PLUGIN_epg{margin-right:1em}.PLUGIN-program__desc{font-size:0.9em;margin:0.5em;text-align:justify;max-height:15em;overflow:hidden;}.PLUGIN.category-full{padding-bottom:10em}.PLUGIN .card__img{cursor:pointer;background-color:#353535a6}.PLUGIN .card__title{text-overflow:ellipsis;white-space:nowrap;overflow:hidden}.PLUGIN .card__age{padding:0;border:1px #3e3e3e solid;margin-top:0.3em;border-radius:0.3em;position:relative;display: none}.PLUGIN .card__age .card__epg-progress{position:absolute;background-color:#3a3a3a;top:0;left:0;width:0%;max-width:100%;height:100%}.PLUGIN .card__age .card__epg-title{position:relative;padding:0.4em 0.2em;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;}.PLUGIN.category-full .card__icons {top:0.3em;right:0.3em;justify-content:right;}#PLUGIN{float:right;padding: 1.2em 0;width: 30%;}.PLUGIN-details__group{font-size:1.3em;margin-bottom:.9em;opacity:.5}.PLUGIN-details__title{font-size:4em;font-weight:700}.PLUGIN-details__program{padding-top:4em}.PLUGIN-details__program-title{font-size:1.2em;padding-left:4.9em;margin-top:1em;margin-bottom:1em;opacity:.5}.PLUGIN-details__program-list>div+div{margin-top:1em}.PLUGIN-details__program>div+div{margin-top:2em}.PLUGIN-program{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;font-size:1.2em;font-weight:300}.PLUGIN-program__time{-webkit-flex-shrink:0;-ms-flex-negative:0;flex-shrink:0;width:5em;position:relative}.PLUGIN-program.focus .PLUGIN-program__time::after{content:'';position:absolute;top:.5em;right:.9em;width:.4em;background-color:#fff;height:.4em;-webkit-border-radius:100%;-moz-border-radius:100%;border-radius:100%;margin-top:-0.1em;font-size:1.2em}.PLUGIN-program__progressbar{width:13em;height:0.3em;border:0.05em solid #fff;border-radius:0.05em;margin:0.5em 0.5em 0 0}.PLUGIN-program__progress{height:0.25em;border:0.05em solid #fff;background-color:#fff;max-width: 100%}.PLUGIN .card__icon.icon--timeshift{background-image:url(//epg.rootu.top/img/icon/timeshift.svg);}</style>".replace(/PLUGIN/g, 
  event.component));
  $("body").append(Lampa.Template.get(event.component + "_style", {}, true));
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "DIESEL_AccessVariant",
      type : "select",
      values : {
        EMAIL : "e-mail",
        DEMO : "\u0442\u0435\u0441\u0442 \u043d\u0430 \u0441\u0443\u0442\u043a\u0438",
        TOKEN : "\u041f\u043e \u0442\u043e\u043a\u0435\u043d\u0443"
      },
      default : "EMAIL"
    },
    field : {
      name : "\u0421\u0445\u0435\u043c\u0430 \u0434\u043e\u0441\u0442\u0443\u043f\u0430",
      description : "\u0421\u043f\u043e\u0441\u043e\u0431 \u043f\u043e\u043b\u0443\u0447\u0435\u043d\u0438\u044f \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0430"
    },
    onChange : function generate(patternGraph) {
      if (Lampa.Storage.field("DIESEL_AccessVariant") == "EMAIL") {
      }
      if (Lampa.Storage.field("DIESEL_AccessVariant") == "DEMO") {
      }
      if (Lampa.Storage.field("DIESEL_AccessVariant") == "TOKEN") {
      }
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "TVmenu",
      type : "select",
      values : {
        RU_1 : "\u0420\u043e\u0441\u0441\u0438\u044f_RU",
        RU_1_MTS : "\u0420\u043e\u0441\u0441\u0438\u044f_RU_MpegTS",
        RU_KFC : "\u0420\u043e\u0441\u0441\u0438\u044f_KFC",
        RU_KFC_MTS : "\u0420\u043e\u0441\u0441\u0438\u044f_KFC_MpegTS",
        RU_BN : "\u0420\u043e\u0441\u0441\u0438\u044f_BN",
        RU_BN_MTS : "\u0420\u043e\u0441\u0441\u0438\u044f_BN_MpegTS",
        DE_DE : "\u0413\u0435\u0440\u043c\u0430\u043d\u0438\u044f",
        DE_DE_MTS : "\u0413\u0435\u0440\u043c\u0430\u043d\u0438\u044f_MpegTS",
        KZ_KZ : "\u041a\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043d",
        KZ_KZ_MTS : "\u041a\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043d_MpegTS",
        UA_GN : "\u0423\u043a\u0440\u0430\u0438\u043d\u0430",
        UA_GN_MTS : "\u0423\u043a\u0440\u0430\u0438\u043d\u0430_MpegTS"
      },
      default : "RU_1"
    },
    field : {
      name : "\u0418\u0441\u0442\u043e\u0447\u043d\u0438\u043a",
      description : "\u0412\u044b\u0431\u0440\u0430\u043d\u043d\u044b\u0439 \u0441\u0435\u0440\u0432\u0435\u0440 \u0442\u0440\u0430\u043d\u0441\u043b\u044f\u0446\u0438\u0438"
    },
    onChange : function onChange(xhr) {
      Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      Lampa.Settings.update();
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "diesel_restore",
      type : "static",
      default : ""
    },
    field : {
      name : "\u0421\u0431\u0440\u043e\u0441\u0438\u0442\u044c \u043d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043f\u043b\u0430\u0433\u0438\u043d\u0430",
      description : "\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0434\u043b\u044f \u0441\u0431\u0440\u043e\u0441\u0430 \u0438 \u043f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u043a\u0438"
    },
    onRender : function fetchScriptInternal(options) {
      options.show();
      options.on("hover:enter", function() {
        Lampa.Noty.show("\u041d\u0430\u0441\u0442\u0440\u043e\u0439\u043a\u0438 \u043f\u043b\u0430\u0433\u0438\u043d\u0430 \u0441\u0431\u0440\u043e\u0448\u0435\u043d\u044b!");
        setTimeout(function() {
          location.reload();
        }, 4000);
      });
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "HidenCategories",
      type : "trigger",
      default : false
    },
    field : {
      name : "\u0421\u043a\u0440\u044b\u0442\u044c \u0437\u0430\u0440\u0443\u0431\u0435\u0436\u043d\u044b\u0435 \u043a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438",
      description : "\u041a\u0430\u043d\u0430\u043b\u044b \u0413\u0435\u0440\u043c\u0430\u043d\u0438\u0438, \u0418\u0437\u0440\u0430\u0438\u043b\u044f \u0438 \u0442.\u043f."
    },
    onChange : function ready(fn) {
      if (Lampa.Storage.field("HidenCategories") == true) {
        setInterval(function() {
          var $post_list = $('.selectbox-item.selector > div:contains("Germany")');
          var $stickyResizeElement = $('.selectbox-item.selector > div:contains("Israel")');
          var $gbox = $('.selectbox-item.selector > div:contains("Turkey")');
          var asker = $('.selectbox-item.selector > div:contains("\u041a\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043d")');
          var gridCtl = $('.selectbox-item.selector > div:contains("Baltic")');
          if ($post_list.length > 0) {
            $post_list.parent("div").hide();
          }
          if ($stickyResizeElement.length > 0) {
            $stickyResizeElement.parent("div").hide();
          }
          if ($gbox.length > 0) {
            $gbox.parent("div").hide();
          }
          if (asker.length > 0) {
            asker.parent("div").hide();
          }
          if (gridCtl.length > 0) {
            gridCtl.parent("div").hide();
          }
        }, 1000);
      }
      if (Lampa.Storage.field("HidenCategories") == false) {
        Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      }
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "HidenErotic",
      type : "trigger",
      default : false
    },
    field : {
      name : "\u0421\u043a\u0440\u044b\u0442\u044c \u042d\u0440\u043e\u0442\u0438\u043a\u0443",
      description : "\u0421\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u043a\u0430\u043d\u0430\u043b\u044b 18+"
    },
    onChange : function ready(fn) {
      if (Lampa.Storage.field("HidenErotic") == true) {
        setInterval(function() {
          var $post_list = $('.selectbox-item.selector > div:contains("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435")');
          if ($post_list.length > 0) {
            $post_list.parent("div").hide();
          }
        }, 1000);
      }
      if (Lampa.Storage.field("HidenErotic") == false) {
        Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      }
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "Diesel_Auto_Start",
      type : "trigger",
      default : false
    },
    field : {
      name : "\u0410\u0432\u0442\u043e\u0437\u0430\u043f\u0443\u0441\u043a \u043f\u0440\u0438 \u0441\u0442\u0430\u0440\u0442\u0435",
      description : "\u041e\u0442\u043a\u0440\u044b\u0432\u0430\u0435\u0442 \u0440\u0430\u0437\u0434\u0435\u043b \u0422\u0412 \u043f\u0440\u0438 \u0437\u0430\u043f\u0443\u0441\u043a\u0435 Lampa"
    },
    onChange : function onChange(xhr) {
      Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      Lampa.Settings.update();
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "DIESEL_UserAgent",
      type : "select",
      values : {
        STANDART : "\u0421\u0442\u0430\u043d\u0434\u0430\u0440\u0442",
        Wink : "Wink",
        CUSTOM : "\u0421\u0432\u043e\u0439"
      },
      default : "STANDART"
    },
    field : {
      name : "userAgent",
      description : "\u041d\u0435\u043e\u0431\u0445\u043e\u0434\u0438\u043c \u0434\u043b\u044f \u043d\u0435\u043a\u043e\u0442\u043e\u0440\u044b\u0445 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u043e\u0432, \u043d\u0435 \u0440\u0430\u0431\u043e\u0442\u0430\u0435\u0442 \u043d\u0430 Android \u0438 \u043d\u0435\u043a\u043e\u0442\u043e\u0440\u044b\u0445 \u0443\u0441\u0442\u0440\u043e\u0439\u0441\u0442\u0432\u0430\u0445"
    },
    onChange : function init(navigatorType) {
      if (Lampa.Storage.field("DIESEL_UserAgent") == "CUSTOM") {
        Lampa.Input.edit({
          value : "",
          free : true,
          nosave : true
        }, function(ideaExample) {
          Lampa.Storage.set("DIESEL_CustomAgent", ideaExample);
          Lampa.Settings.update();
        });
      }
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "ICONS_in_row",
      type : "select",
      values : {
        ICONS_6 : "6 \u0438\u043a\u043e\u043d\u043e\u043a",
        ICONS_7 : "7 \u0438\u043a\u043e\u043d\u043e\u043a",
        ICONS_8 : "8 \u0438\u043a\u043e\u043d\u043e\u043a"
      },
      default : "ICONS_7"
    },
    field : {
      name : "\u0417\u043d\u0430\u0447\u043a\u0438 \u043a\u0430\u043d\u0430\u043b\u043e\u0432",
      description : "\u0421\u043a\u043e\u043b\u044c\u043a\u043e \u0437\u043d\u0430\u0447\u043a\u043e\u0432 \u0432 \u043e\u0434\u043d\u043e\u0439 \u0441\u0442\u0440\u043e\u043a\u0435"
    },
    onChange : function onChange(xhr) {
      Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      Lampa.Settings.update();
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "FRAME_AROUND_pic",
      type : "select",
      values : {
        COLOUR_yellow : "\u0416\u0451\u043b\u0442\u044b\u0439",
        COLOUR_blue : "\u0421\u0438\u043d\u0438\u0439",
        COLOUR_white : "\u0411\u0435\u043b\u044b\u0439",
        COLOUR_green : "\u0417\u0435\u043b\u0451\u043d\u044b\u0439"
      },
      default : "COLOUR_yellow"
    },
    field : {
      name : "\u0426\u0432\u0435\u0442 \u0440\u0430\u043c\u043a\u0438 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e \u043a\u0430\u043d\u0430\u043b\u0430",
      description : "\u0412\u044b\u0431\u0435\u0440\u0438\u0442\u0435 \u0446\u0432\u0435\u0442 \u0432\u044b\u0434\u0435\u043b\u0435\u043d\u0438\u044f"
    },
    onChange : function onChange(xhr) {
      Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      Lampa.Settings.update();
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "PICon",
      type : "select",
      values : {
        QUAD : "\u041a\u0432\u0430\u0434\u0440\u0430\u0442\u043d\u044b\u0439",
        CLASSIC : "\u041f\u0440\u044f\u043c\u043e\u0443\u0433\u043e\u043b\u044c\u043d\u044b\u0439"
      },
      default : "CLASSIC"
    },
    field : {
      name : "\u0412\u0438\u0434 \u0438\u043a\u043e\u043d\u043a\u0438 \u043a\u0430\u043d\u0430\u043b\u0430",
      description : "\u0424\u043e\u0440\u043c\u0430 \u0438\u043a\u043e\u043d\u043a\u0438"
    },
    onChange : function save(fromHtml) {
      Lampa.Storage.set("custom_icons", "14.2");
      Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      Lampa.Settings.update();
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "PLAYLIST_copy",
      type : "static",
      default : ""
    },
    field : {
      name : "\u0421\u0441\u044b\u043b\u043a\u0430 \u043d\u0430 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442",
      description : "\u041d\u0430\u0436\u043c\u0438\u0442\u0435 \u0434\u043b\u044f \u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d\u0438\u044f \u0441\u0441\u044b\u043b\u043a\u0438"
    },
    onRender : function initialize(obj) {
      obj.show();
      obj.on("hover:enter", function() {
        Lampa.Utils.copyTextToClipboard(filename, function() {
          Lampa.Noty.show("OK");
        }, function() {
          Lampa.Noty.show("Not OK");
        });
        Lampa.Noty.show("\u0423\u0441\u043f\u0435\u0448\u043d\u043e \u0441\u043a\u043e\u043f\u0438\u0440\u043e\u0432\u0430\u043d");
      });
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "DIESEL_debug",
      type : "trigger",
      default : false
    },
    field : {
      name : "\u0420\u0435\u0436\u0438\u043c \u043e\u0442\u043b\u0430\u0434\u043a\u0438",
      description : "\u0414\u0438\u0430\u0433\u043d\u043e\u0441\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0439 \u0440\u0435\u0436\u0438\u043c \u0440\u0430\u0431\u043e\u0442\u044b \u043f\u043b\u0430\u0433\u0438\u043d\u0430"
    },
    onChange : function tasksAjaxCall(projectId) {
      Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
    }
  });
  Lampa.SettingsApi.addParam({
    component : "diesel_iptv",
    param : {
      name : "DIESEL_GEO_BLOCK",
      type : "trigger",
      default : false
    },
    field : {
      name : "\u041e\u0431\u0445\u043e\u0434 \u0433\u0435\u043e\u0431\u043b\u043e\u043a\u0430 \u043f\u0440\u043e\u0432\u0430\u0439\u0434\u0435\u0440\u0430",
      description : ""
    },
    onChange : function onChange(xhr) {
      Lampa.Noty.show("\u041f\u0435\u0440\u0435\u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u0435 Lampa \u0434\u043b\u044f \u043f\u0440\u0438\u043c\u0435\u043d\u0435\u043d\u0438\u044f \u043d\u0430\u0441\u0442\u0440\u043e\u0435\u043a!");
      Lampa.Settings.update();
    }
  });
  if (Lampa.Storage.field("TVmenu") == "RU_1") {
    Lampa.Storage.set("diesel_source", "playlist.RU_1.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "RU_1_MTS") {
    Lampa.Storage.set("diesel_source", "playlist.RU_1_MTS.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "RU_KFC") {
    Lampa.Storage.set("diesel_source", "playlist.RU_KFC.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "RU_KFC_MTS") {
    Lampa.Storage.set("diesel_source", "playlist.RU_KFC_MTS.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "RU_BN") {
    Lampa.Storage.set("diesel_source", "playlist.RU_BN.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "RU_BN_MTS") {
    Lampa.Storage.set("diesel_source", "playlist.RU_BN_MTS.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "DE_DE") {
    Lampa.Storage.set("diesel_source", "playlist.DE_DE.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "DE_DE_MTS") {
    Lampa.Storage.set("diesel_source", "playlist.DE_DE_MTS.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "KZ_KZ") {
    Lampa.Storage.set("diesel_source", "playlist.KZ_KZ.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "KZ_KZ_MTS") {
    Lampa.Storage.set("diesel_source", "playlist.KZ_KZ_MTS.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "UA_GN") {
    Lampa.Storage.set("diesel_source", "playlist.UA_GN.m3u8");
  }
  if (Lampa.Storage.field("TVmenu") == "UA_GN_MTS") {
    Lampa.Storage.set("diesel_source", "playlist.UA_GN_MTS.m3u8");
  }
  if (Lampa.Storage.field("HidenCategories") == true) {
    setInterval(function() {
      var $post_list = $('.selectbox-item.selector > div:contains("Germany")');
      var $stickyResizeElement = $('.selectbox-item.selector > div:contains("Israel")');
      var $gbox = $('.selectbox-item.selector > div:contains("Turkey")');
      var asker = $('.selectbox-item.selector > div:contains("\u041a\u0430\u0437\u0430\u0445\u0441\u0442\u0430\u043d")');
      var gridCtl = $('.selectbox-item.selector > div:contains("Baltic")');
      if ($post_list.length > 0) {
        $post_list.parent("div").hide();
      }
      if ($stickyResizeElement.length > 0) {
        $stickyResizeElement.parent("div").hide();
      }
      if ($gbox.length > 0) {
        $gbox.parent("div").hide();
      }
      if (asker.length > 0) {
        asker.parent("div").hide();
      }
      if (gridCtl.length > 0) {
        gridCtl.parent("div").hide();
      }
    }, 1000);
  }
  if (Lampa.Storage.field("HidenErotic") == true) {
    setInterval(function() {
      var $post_list = $('.selectbox-item.selector > div:contains("\u042d\u0440\u043e\u0442\u0438\u0447\u0435\u0441\u043a\u0438\u0435")');
      if ($post_list.length > 0) {
        $post_list.parent("div").hide();
      }
    }, 1000);
  }
  if (Lampa.Storage.field("ICONS_in_row") == "ICONS_6") {
    Lampa.Storage.set("custom_icons", "16.6");
  }
  if (Lampa.Storage.field("ICONS_in_row") == "ICONS_7") {
    Lampa.Storage.set("custom_icons", "14.2");
  }
  if (Lampa.Storage.field("ICONS_in_row") == "ICONS_8") {
    Lampa.Storage.set("custom_icons", "12.5");
  }
  if (Lampa.Storage.field("FRAME_AROUND_pic") == "COLOUR_yellow") {
    Lampa.Storage.set("custom_colour", "fff10d");
  }
  if (Lampa.Storage.field("FRAME_AROUND_pic") == "COLOUR_blue") {
    Lampa.Storage.set("custom_colour", "0078ff");
  }
  if (Lampa.Storage.field("FRAME_AROUND_pic") == "COLOUR_white") {
    Lampa.Storage.set("custom_colour", "ffffff");
  }
  if (Lampa.Storage.field("PICon") == "QUAD") {
    Lampa.Storage.set("custom_shape", "100");
  }
  if (Lampa.Storage.field("PICon") == "CLASSIC") {
    Lampa.Storage.set("custom_shape", "60");
  }
  var custom_icons = Lampa.Storage.field("custom_icons");
  var custom_colour = Lampa.Storage.field("custom_colour");
  var custom_shape = Lampa.Storage.field("custom_shape");
  var _ddoc = Lampa.Storage.field("account_email").toLowerCase();
  var suffix = Lampa.Storage.field("diesel_source");
  if (Lampa.Storage.field("DIESEL_AccessVariant") == "EMAIL") {
    /** @type {string} */
    var filename = "http://lampatv.site/users/" + _ddoc + "/" + suffix;
  }
  if (Lampa.Storage.field("DIESEL_AccessVariant")) {
    /** @type {string} */
    filename = "http://lampatv.site/users/" + _ddoc + "/" + suffix;
  }
  if (Lampa.Storage.field("DIESEL_AccessVariant") == "DEMO") {
    /** @type {string} */
    filename = "http://lampatv.site/users/test/" + _ddoc + "/" + suffix;
  }
  if (Lampa.Storage.field("DIESEL_AccessVariant") == "TOKEN") {
    /** @type {string} */
    filename = "http://lampatv.site/tokens/" + Lampa.Storage.field("diesel_iptv_uid") + "/" + suffix;
  }
  Lampa.Template.add("tv_style", "<style>div.card.selector.card--collection.card--loaded.focus > div.card__view > img{box-shadow: 0 0 0 0.5em #" + custom_colour + "!important;}</style>");
  $("body").append(Lampa.Template.get("tv_style", {}, true));
  Lampa.Template.add("shape_style", "<style>#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div > div.card__view{padding-bottom: " + custom_shape + "%!important;}</style>");
  $("body").append(Lampa.Template.get("shape_style", {}, true));
  Lampa.Template.add("nomenuiptv1", '<style>div[data-name="diesel_iptv_list_url_0"]{opacity: 0%!important;display: none;}</style>');
  $("body").append(Lampa.Template.get("nomenuiptv1", {}, true));
  Lampa.Template.add("PlayerError", "<style>body > div.player > div.player-info.info--visible > div > div.player-info__error{opacity: 0%!important;display: none;}</style>");
  $("body").append(Lampa.Template.get("PlayerError", {}, true));
  if (Lampa.Storage.field("DIESEL_debug") == false) {
    Lampa.Template.add("nomenuiptv", '<style>div[data-name="1901885695"]{opacity: 0%!important;display: none;}</style>');
    $("body").append(Lampa.Template.get("nomenuiptv", {}, true));
  }
  if (Lampa.Storage.field("DIESEL_debug") == true) {
    console.log("DEBUG", filename);
  }
  Lampa.Storage.listener.follow("change", function(engineDiscovery) {
    if (Lampa.Storage.field("Diesel_Auto_Start") == true) {
      if (engineDiscovery.name == "start_page") {
        var _ddoc = Lampa.Storage.field("account_email").toLowerCase();
        var baseName = Lampa.Storage.field("diesel_source");
        /** @type {string} */
        var middlePathName = "http://lampatv.site/users/" + _ddoc + "/" + baseName;
        Lampa.Storage.set("activity", '{"id":0,"url":"' + middlePathName + '","title":"\u0414\u0438\u0437\u0435\u043b\u044c \u0422\u0412","groups":[],"currentGroup":"Russia","component":"diesel_iptv","page":1}');
        localStorage.setItem("start_page", "last");
      }
    }
  });
  Lampa.Template.add("tv_short", "<style>#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div > div.activity__body > div > div.info.layer--width{height: 12%!important;}</style>");
  $("body").append(Lampa.Template.get("tv_short", {}, true));
  Lampa.Template.add("tv_short1", "<style>#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div > div.activity__body > div > div.info.layer--width > div.info__left > div.info__title-original{display: none!important;}</style>");
  $("body").append(Lampa.Template.get("tv_short1", {}, true));
  if (!Lampa.Lang) {
    var source = {};
    Lampa.Lang = {
      add : function includeDep(name) {
        /** @type {string} */
        source = name;
      },
      translate : function show_add_field(key) {
        return source[key] ? source[key].ru : key;
      }
    };
  }
  var methods = {};
  require("default_playlist", {
    ru : "" + filename + "",
    uk : "" + filename + "",
    be : "" + filename + "",
    en : "" + filename + "",
    zh : "" + filename + ""
  });
  require("default_playlist_cat", {
    ru : "Russia",
    uk : "Ukraine",
    be : "Belarus",
    en : "VOD Movies (EN)",
    zh : "China"
  });
  require("settings_playlist_num_group", {
    ru : "\u041f\u043b\u0435\u0439\u043b\u0438\u0441\u0442 ",
    uk : "\u041f\u043b\u0435\u0439\u043b\u0438\u0441\u0442 ",
    be : "\u041f\u043b\u044d\u0439\u043b\u0456\u0441\u0442 ",
    en : "Playlist ",
    zh : "\u64ad\u653e\u5217\u8868 "
  });
  require("settings_list_name", {
    ru : "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435",
    uk : "\u041d\u0430\u0437\u0432\u0430",
    be : "\u041d\u0430\u0437\u0432\u0430",
    en : "Name",
    zh : "\u540d\u79f0"
  });
  require("settings_list_name_desc", {
    ru : "\u041d\u0430\u0437\u0432\u0430\u043d\u0438\u0435 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0430 \u0432 \u0413\u043b\u0430\u0432\u043d\u043e\u043c (\u043b\u0435\u0432\u043e\u043c) \u043c\u0435\u043d\u044e",
    uk : "\u041d\u0430\u0437\u0432\u0430 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0430 \u0443 \u0413\u043e\u043b\u043e\u0432\u043d\u043e\u043c\u0443 (\u043b\u0456\u0432\u043e\u043c\u0443) \u043c\u0435\u043d\u044e",
    be : "\u041d\u0430\u0437\u0432\u0430 \u043f\u043b\u044d\u0439\u043b\u0456\u0441\u0442\u0430 \u045e \u0413\u0430\u043b\u043e\u045e\u043d\u044b\u043c (\u043b\u0435\u0432\u044b\u043c) \u043c\u0435\u043d\u044e",
    en : "Playlist name in the Main (left) menu",
    zh : "\u5de6\u4fa7\u83dc\u5355\u4e2d\u7684\u64ad\u653e\u5217\u8868\u540d\u79f0"
  });
  require("settings_list_url", {
    ru : "URL-\u0430\u0434\u0440\u0435\u0441",
    uk : "URL-\u0430\u0434\u0440\u0435\u0441\u0430",
    be : "URL-\u0430\u0434\u0440\u0430\u0441",
    en : "URL",
    zh : "\u7f51\u5740"
  });
  require("settings_list_url_desc0", {
    ru : "\u041f\u043e \u0443\u043c\u043e\u043b\u0447\u0430\u043d\u0438\u044e \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0435\u0442\u0441\u044f \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442 \u0438\u0437 \u043f\u0440\u043e\u0435\u043a\u0442\u0430 <i>\u0414\u0438\u0437\u0435\u043b\u044c \u0422\u0412</i><br>\u0412\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u0437\u0430\u043c\u0435\u043d\u0438\u0442\u044c \u0435\u0433\u043e \u043d\u0430 \u0441\u0432\u043e\u0439.",
    uk : "\u0417\u0430 \u0437\u0430\u043c\u043e\u0432\u0447\u0443\u0432\u0430\u043d\u043d\u044f\u043c \u0432\u0438\u043a\u043e\u0440\u0438\u0441\u0442\u043e\u0432\u0443\u0454\u0442\u044c\u0441\u044f \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442 \u0456\u0437 \u043f\u0440\u043e\u0435\u043a\u0442\u0443 <i>\u0414\u0438\u0437\u0435\u043b\u044c \u0422\u0411</i><br>\u0412\u0438 \u043c\u043e\u0436\u0435\u0442\u0435 \u0437\u0430\u043c\u0456\u043d\u0438\u0442\u0438 \u0439\u043e\u0433\u043e \u043d\u0430 \u0441\u0432\u0456\u0439.",
    be : "\u041f\u0430 \u0437\u043c\u0430\u045e\u0447\u0430\u043d\u043d\u0456 \u0432\u044b\u043a\u0430\u0440\u044b\u0441\u0442\u043e\u045e\u0432\u0430\u0435\u0446\u0446\u0430 \u043f\u043b\u044d\u0439\u043b\u0456\u0441\u0442 \u0437 \u043f\u0440\u0430\u0435\u043a\u0442\u0430 <i>\u0414\u044b\u0437\u0435\u043b\u044c \u0422\u0411</i><br> \u0412\u044b \u043c\u043e\u0436\u0430\u0446\u0435 \u0437\u0430\u043c\u044f\u043d\u0456\u0446\u044c \u044f\u0433\u043e \u043d\u0430 \u0441\u0432\u043e\u0439.",
    en : "The default playlist is from the project <i>https://github.com/Free-TV/IPTV</i><br>You can replace it with your own.",
    zh : "\u9ed8\u8ba4\u64ad\u653e\u5217\u8868\u6765\u81ea\u9879\u76ee <i>https://github.com/Free-TV/IPTV</i><br>\u60a8\u53ef\u4ee5\u5c06\u5176\u66ff\u6362\u4e3a\u60a8\u81ea\u5df1\u7684\u3002"
  });
  require("settings_list_url_desc1", {
    ru : "\u0412\u044b \u043c\u043e\u0436\u0435\u0442\u0435 \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0435\u0449\u0435 \u043e\u0434\u0438\u043d \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442 \u0437\u0434\u0435\u0441\u044c. \u0421\u0441\u044b\u043b\u043a\u0438 \u043d\u0430 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u044b \u043e\u0431\u044b\u0447\u043d\u043e \u0437\u0430\u043a\u0430\u043d\u0447\u0438\u0432\u0430\u044e\u0442\u0441\u044f \u043d\u0430 <i>.m3u</i> \u0438\u043b\u0438 <i>.m3u8</i>",
    uk : "\u0412\u0438 \u043c\u043e\u0436\u0435\u0442\u0435 \u0434\u043e\u0434\u0430\u0442\u0438 \u0449\u0435 \u043e\u0434\u0438\u043d \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442 \u0441\u0443\u0434\u0443. \u041f\u043e\u0441\u0438\u043b\u0430\u043d\u043d\u044f \u043d\u0430 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u0438 \u0437\u0430\u0437\u0432\u0438\u0447\u0430\u0439 \u0437\u0430\u043a\u0456\u043d\u0447\u0443\u044e\u0442\u044c\u0441\u044f \u043d\u0430 <i>.m3u</i> \u0430\u0431\u043e <i>.m3u8</i>",
    be : "\u0412\u044b \u043c\u043e\u0436\u0430\u0446\u0435 \u0434\u0430\u0434\u0430\u0446\u044c \u044f\u0448\u0447\u044d \u0430\u0434\u0437\u0456\u043d \u043f\u043b\u044d\u0439\u043b\u0456\u0441\u0442 \u0441\u0443\u0434\u0430. \u0421\u043f\u0430\u0441\u044b\u043b\u043a\u0456 \u043d\u0430 \u043f\u043b\u044d\u0439\u043b\u0456\u0441\u0442\u044b \u0437\u0432\u044b\u0447\u0430\u0439\u043d\u0430 \u0437\u0430\u043a\u0430\u043d\u0447\u0432\u0430\u044e\u0446\u0446\u0430 \u043d\u0430 <i>.m3u</i> \u0430\u0431\u043e <i>.m3u8</i>",
    en : "You can add another trial playlist. Playlist links usually end with <i>.m3u</i> or <i>.m3u8</i>",
    zh : "\u60a8\u53ef\u4ee5\u6dfb\u52a0\u53e6\u4e00\u4e2a\u64ad\u653e\u5217\u8868\u3002 \u64ad\u653e\u5217\u8868\u94fe\u63a5\u901a\u5e38\u4ee5 <i>.m3u</i> \u6216 <i>.m3u8</i> \u7ed3\u5c3e"
  });
  require("categories", {
    ru : "\u041a\u0430\u0442\u0435\u0433\u043e\u0440\u0438\u0438",
    uk : "\u041a\u0430\u0442\u0435\u0433\u043e\u0440\u0456\u044f",
    be : "\u041a\u0430\u0442\u044d\u0433\u043e\u0440\u044b\u044f",
    en : "Categories",
    zh : "\u5206\u7c7b"
  });
  require("uid", {
    ru : "\u0422\u043e\u043a\u0435\u043d",
    uk : "\u0422\u043e\u043a\u0435\u043d",
    be : "\u0422\u043e\u043a\u0435\u043d",
    en : "Token",
    zh : "UID"
  });
  require("unique_id", {
    ru : "\u0443\u043d\u0438\u043a\u0430\u043b\u044c\u043d\u044b\u0439 \u0438\u0434\u0435\u043d\u0442\u0438\u0444\u0438\u043a\u0430\u0442\u043e\u0440 (\u043d\u0443\u0436\u0435\u043d \u0434\u043b\u044f \u043d\u0435\u043a\u043e\u0442\u043e\u0440\u044b\u0445 \u0441\u0441\u044b\u043b\u043e\u043a \u043d\u0430 \u043f\u043b\u0435\u0439\u043b\u0438\u0441\u0442\u044b)",
    uk : "\u0443\u043d\u0456\u043a\u0430\u043b\u044c\u043d\u0438\u0439 \u0456\u0434\u0435\u043d\u0442\u0438\u0444\u0456\u043a\u0430\u0442\u043e\u0440 (\u043d\u0435\u043e\u0431\u0445\u0456\u0434\u043d\u0438\u0439 \u0434\u043b\u044f \u0434\u0435\u044f\u043a\u0438\u0445 \u043f\u043e\u0441\u0438\u043b\u0430\u043d\u044c \u043d\u0430 \u0441\u043f\u0438\u0441\u043a\u0438 \u0432\u0456\u0434\u0442\u0432\u043e\u0440\u0435\u043d\u043d\u044f)",
    be : "\u0443\u043d\u0456\u043a\u0430\u043b\u044c\u043d\u044b \u0456\u0434\u044d\u043d\u0442\u044b\u0444\u0456\u043a\u0430\u0442\u0430\u0440 (\u043d\u0435\u0430\u0431\u0445\u043e\u0434\u043d\u044b \u0434\u043b\u044f \u043d\u0435\u043a\u0430\u0442\u043e\u0440\u044b\u0445 \u0441\u043f\u0430\u0441\u044b\u043b\u0430\u043a \u043d\u0430 \u0441\u043f\u0456\u0441 \u043f\u0440\u0430\u0439\u0433\u0440\u0430\u0432\u0430\u043d\u043d\u044f)",
    en : "unique identifier (needed for some playlist links)",
    zh : "\u552f\u4e00 ID\uff08\u67d0\u4e9b\u64ad\u653e\u5217\u8868\u94fe\u63a5\u9700\u8981\uff09"
  });
  require("favorites", {
    ru : "\u0418\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435",
    uk : "\u0412\u0438\u0431\u0440\u0430\u043d\u0435",
    be : "\u0412\u044b\u0431\u0440\u0430\u043d\u0430\u0435",
    en : "Favorites",
    zh : "\u6536\u85cf\u5939"
  });
  require("favorites_add", {
    ru : "\u0414\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435",
    uk : "\u0414\u043e\u0434\u0430\u0442\u0438 \u0432 \u043e\u0431\u0440\u0430\u043d\u0435",
    be : "\u0414\u0430\u0434\u0430\u0446\u044c \u0443 \u0430\u0431\u0440\u0430\u043d\u0430\u0435",
    en : "Add to favorites",
    zh : "\u6dfb\u52a0\u5230\u6536\u85cf\u5939"
  });
  require("favorites_del", {
    ru : "\u0423\u0434\u0430\u043b\u0438\u0442\u044c \u0438\u0437 \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0433\u043e",
    uk : "\u0412\u0438\u0434\u0430\u043b\u0438\u0442\u0438 \u0437 \u0432\u0438\u0431\u0440\u0430\u043d\u043e\u0433\u043e",
    be : "\u0412\u044b\u0434\u0430\u043b\u0456\u0446\u044c \u0437 \u0430\u0431\u0440\u0430\u043d\u0430\u0433\u0430",
    en : "Remove from favorites",
    zh : "\u4ece\u6536\u85cf\u5939\u4e2d\u5220\u9664"
  });
  require("favorites_clear", {
    ru : "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0438\u0437\u0431\u0440\u0430\u043d\u043d\u043e\u0435",
    uk : "\u041e\u0447\u0438\u0441\u0442\u0438\u0442\u0438 \u0432\u0438\u0431\u0440\u0430\u043d\u0435",
    be : "\u0410\u0447\u044b\u0441\u0446\u0456\u0446\u044c \u0432\u044b\u0431\u0440\u0430\u043d\u0430\u0435",
    en : "Clear favorites",
    zh : "\u6e05\u9664\u6536\u85cf\u5939"
  });
  require("favorites_move_top", {
    ru : "\u0412 \u043d\u0430\u0447\u0430\u043b\u043e \u0441\u043f\u0438\u0441\u043a\u0430",
    uk : "\u041d\u0430 \u043f\u043e\u0447\u0430\u0442\u043e\u043a \u0441\u043f\u0438\u0441\u043a\u0443",
    be : "\u0414\u0430 \u043f\u0430\u0447\u0430\u0442\u043a\u0443 \u0441\u043f\u0456\u0441\u0443",
    en : "To the top of the list",
    zh : "\u5230\u5217\u8868\u9876\u90e8"
  });
  require("favorites_move_up", {
    ru : "\u0421\u0434\u0432\u0438\u043d\u0443\u0442\u044c \u0432\u0432\u0435\u0440\u0445",
    uk : "\u0417\u0440\u0443\u0448\u0438\u0442\u0438 \u0432\u0433\u043e\u0440\u0443",
    be : "\u0421\u0441\u0443\u043d\u0443\u0446\u044c \u0443\u0432\u0435\u0440\u0445",
    en : "Move up",
    zh : "\u4e0a\u79fb"
  });
  require("favorites_move_down", {
    ru : "\u0421\u0434\u0432\u0438\u043d\u0443\u0442\u044c \u0432\u043d\u0438\u0437",
    uk : "\u0417\u0440\u0443\u0448\u0438\u0442\u0438 \u0432\u043d\u0438\u0437",
    be : "\u0421\u0441\u0443\u043d\u0443\u0446\u044c \u0443\u043d\u0456\u0437",
    en : "Move down",
    zh : "\u4e0b\u79fb"
  });
  require("favorites_move_end", {
    ru : "\u0412 \u043a\u043e\u043d\u0435\u0446 \u0441\u043f\u0438\u0441\u043a\u0430",
    uk : "\u0412 \u043a\u0456\u043d\u0435\u0446\u044c \u0441\u043f\u0438\u0441\u043a\u0443",
    be : "\u0423 \u043a\u0430\u043d\u0435\u0446 \u0441\u043f\u0456\u0441\u0443",
    en : "To the end of the list",
    zh : "\u5230\u5217\u8868\u672b\u5c3e"
  });
  require("epg_on", {
    ru : "\u0412\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0442\u0435\u043b\u0435\u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0443",
    uk : "\u0423\u0432\u0456\u043c\u043a\u043d\u0443\u0442\u0438 \u0442\u0435\u043b\u0435\u043f\u0440\u043e\u0433\u0440\u0430\u043c\u0443",
    be : "\u0423\u043a\u043b\u044e\u0447\u044b\u0446\u044c \u0442\u044d\u043b\u0435\u043f\u0440\u0430\u0433\u0440\u0430\u043c\u0443",
    en : "TV Guide: On",
    zh : "\u96fb\u8996\u6307\u5357\uff1a\u958b"
  });
  require("epg_off", {
    ru : "\u041e\u0442\u043a\u043b\u044e\u0447\u0438\u0442\u044c \u0442\u0435\u043b\u0435\u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0443",
    uk : "\u0412\u0438\u043c\u043a\u043d\u0443\u0442\u0438 \u0442\u0435\u043b\u0435\u043f\u0440\u043e\u0433\u0440\u0430\u043c\u0443",
    be : "\u0410\u0434\u043a\u043b\u044e\u0447\u044b\u0446\u044c \u0442\u044d\u043b\u0435\u043f\u0440\u0430\u0433\u0440\u0430\u043c\u0443",
    en : "TV Guide: Off",
    zh : "\u96fb\u8996\u6307\u5357\uff1a\u95dc\u9589"
  });
  require("epg_title", {
    ru : "\u0422\u0435\u043b\u0435\u043f\u0440\u043e\u0433\u0440\u0430\u043c\u043c\u0430",
    uk : "\u0422\u0435\u043b\u0435\u043f\u0440\u043e\u0433\u0440\u0430\u043c\u0430",
    be : "\u0422\u044d\u043b\u0435\u043f\u0440\u0430\u0433\u0440\u0430\u043c\u0430",
    en : "TV Guide",
    zh : "\u96fb\u8996\u6307\u5357"
  });
  Lampa.Lang.add(methods);
  Lampa.Component.add(event.component, create);
  Lampa.SettingsApi.addComponent(event);
  /** @type {number} */
  var left = 0;
  for (; left <= rules.length; left++) {
    left = open(left);
  }
  result = set("uid", "");
  if (!result) {
    result = Lampa.Utils.uid(10).toUpperCase().replace(/(.{4})/g, "$1-");
    remove("uid", result);
  }
  render("title", {
    title : get("uid")
  });
  render("static", {
    title : result,
    description : get("unique_id")
  });
  if (localStorage.getItem("my_iptv_uid") === null) {
  } else {
    var outer_html = Lampa.Storage.get("my_iptv_uid");
    Lampa.Storage.set("diesel_iptv_uid", outer_html);
  }
  if (!!window.appready) {
    destroy();
  } else {
    Lampa.Listener.follow("app", function(event) {
      if (event.type === "ready") {
        destroy();
      }
    });
  }
})();
