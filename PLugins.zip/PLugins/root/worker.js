(function() {
	'use strict';
//Lampa.Platform.tv();

self.addEventListener('message', function(e) {
  var ipAddresses = e.data;
  var openPorts = [];
  
  for (var i = 0; i < ipAddresses.length; i++) {
    var ipAddress = ipAddresses[i];
    var url = 'http://' + ipAddress + ':8090';
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, false);
    xhr.timeout = 1000;
    try {
      xhr.send();
      if (xhr.status == 200) {
        openPorts.push(ipAddress);
      }
    } catch (e) {
      console.log(ipAddress + ': ошибка соединения');
    }
  }

  self.postMessage(openPorts);
});