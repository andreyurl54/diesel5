(function() {
	'use strict';
	//  Lampa.Platform.tv();
			var TubeSVGG = '<div id="TubeSVGG" class="head__action selector"><svg width="256px" height="256px" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" fill="#ffffff" stroke="#ffffff" stroke-width="0.00048000000000000007"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <title>youtube</title> <g id="Layer_2" data-name="Layer 2">  <g id="icons_Q2" data-name="icons Q2"> <path d="M45.1,12.8a5.5,5.5,0,0,0-3.9-3.9C37.8,8,24,8,24,8S10.2,8,6.8,8.9a5.5,5.5,0,0,0-3.9,3.9C2,16.2,2,23.4,2,23.4s0,7.2.9,10.6a5.5,5.5,0,0,0,3.9,3.9c3.4.9,17.2.9,17.2.9s13.8,0,17.2-.9A5.5,5.5,0,0,0,45.1,34c.9-3.4.9-10.6.9-10.6S46,16.2,45.1,12.8ZM19.6,30V16.8L31,23.4Z" fill="currentColor"></path> </g> </g> </g></svg></div>';
			$('#app > div.head > div > div.head__actions').append(TubeSVGG);
			$('#TubeSVGG').on('hover:enter hover:click hover:touch', function() {
				tizen.application.launch('9Ur5IzDKqV.TizenYouTube')
				});

		Lampa.Listener.follow('app', function(e) {
			if(e.type == 'ready') $('#app > div.head > div > div.head__actions').append(TubeSVGG);
		});

})();