(function() {
	'use strict';

var DivHtml = $('.head__title').innerHTML;
//Lampa.Noty.show('' + DivHtml);
console.log('' + $('.head__title').innerHTML);
})();