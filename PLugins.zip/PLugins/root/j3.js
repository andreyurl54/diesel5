(async function() {
	'use strict';
Lampa.Platform.tv();

/* Задаём список для опроса серверов */
Lampa.Storage.set('LocalServ_1', '')	//при запуске обнуляем статус сервера_1
Lampa.Storage.set('LocalServ_2', '')	//при запуске обнуляем статус сервера_2
Lampa.Storage.set('LocalServ_3', '')	//при запуске обнуляем статус сервера_3
var LocalServ_1 = 'http://192.168.1.160:8090'			//Первый сервер для проверки 127.0.0.1
/*
var LocalServ_2 = 'http://lampatv.fun' //Второй сервер для проверки 192.168.*.* - алиас localhost в диапазоне 192
var LocalServ_3 = 'http://lampatv.site' //Третий сервер для проверки 192.168.*.* - если где-то на ПК или Android
*/
/* Прячем пустые строчки в списке серверов */
/*if (Lampa.Storage.get('torrserver_url_two') == 'StringToRemove:8090') Lampa.Storage.set('torrserver_url_two', '')
setInterval(function() { 
	var element2Remove = $('.selectbox-item.selector > div:contains("StringToRemove")');
	if(element2Remove.length > 0) element2Remove.parent('div').hide();
}, 100); //End Interval
*/
/* Опрашиваем серверы */
fetch(LocalServ_1 + '/echo')														//Проверяем первого кандидата
	.then(response => {
		Lampa.Storage.set('LocalServ_1', LocalServ_1)					//127.0.0.1
		})		//если кандидат ответил на запрос
	.catch(err => Lampa.Storage.set('LocalServ_1', '160 не ответил'))//'StringToRemove'))	//если не ответил

for (var i=150; i<165; i++) {												//Цикл перебора адресов
	//if (Lampa.Storage.get('LocalServ_2_break') == true) break
	var full_address = 'http://192.168.1.' + i + ':8090/echo'
	fetch(full_address)													//Проверяем второго кандидата
		.then(response => {
			//Lampa.Storage.set('LocalServ_2_use', true)					//использовать? да!
			Lampa.Storage.set('LocalServ_2', full_address)				//задаём адрес в LAN-сети
			//Lampa.Storage.set('LocalServ_2_to_continue', i + 1)			//где начинать искать следующий сервер
			Lampa.Noty.Show(full_address)
			//Lampa.Storage.set('LocalServ_2_break', true)
			})	//если кандидат ответил на запрос
		.catch(err => console.log ('SERVER', full_address + ' не ответил'))	//если не ответил Lampa.Storage.set('LocalServ_2', 'StringToRemove')
} // конец цикла
/*
for (var i=Lampa.Storage.get('LocalServ_2_to_continue'); i<255; i++) {	//Цикл перебора адресов
	var full_address_continue = 'http://192.168.1.' + i +
	fetch(full_address_continue)										//Проверяем второго кандидата
		.then(response => {
			Lampa.Storage.set('LocalServ_3_use', true)					//использовать? да!
			Lampa.Storage.set('LocalServ_3', full_address_continue)		//задаём адрес в LAN-сети
			//break
			})	//если кандидат ответил на запрос
		.catch(err => Lampa.Storage.set('LocalServ_3', 'StringToRemove'))	//если не ответил
} // конец цикла
*/
/* Формируем меню после опроса серверов */
setTimeout(function() { //выставляем таймаут для получения правильного значения в меню выбора локального сервера
	Lampa.SettingsApi.addParam({
					component: 'server',
					param: {
						name: 'localtorrserv',
						type: 'select',
						values: {
						   0: 'Не выбран',
						   1: Lampa.Storage.get('LocalServ_1'),// + ':8090',
						   2: Lampa.Storage.get('LocalServ_2') //берём значение из Storage т.к. видимость переменных ограничена
						   //3: Lampa.Storage.get('LocalServ_3') + ':8090'
						},
						default: 0
					},
					field: {
						name: 'Локальный TorrServer',
						description: 'Нажмите для выбора сервера из списка найденных'
					},
					onChange: function (value) {
						if (value == '0') Lampa.Storage.set('torrserver_url_two', '');
						if (value == '1') Lampa.Storage.set('torrserver_url_two', Lampa.Storage.get('LocalServ_1'))// + ':8090'); //127.0.0.1
						//if (value == '2') Lampa.Storage.set('torrserver_url_two', Lampa.Storage.get('LocalServ_2') + ':8090'); //alias for LocalHost
						//if (value == '3') Lampa.Storage.set('torrserver_url_two', Lampa.Storage.get('LocalServ_3') + ':8090'); //ПК или Android
						Lampa.Storage.set('torrserver_use_link', 'two');
						//Lampa.Storage.set('torrserver_use_link', (value == '0') ? 'one' : 'two');
						Lampa.Settings.update();
					},
					onRender: function (item) {
						setTimeout(function() {
							if($('div[data-name="localtorrserv"]').length > 1) item.hide();
							//if(Lampa.Platform.is('android')) Lampa.Storage.set('internal_torrclient', true);
							$('.settings-param__name', item).css('color','f3d900');
							$('div[data-name="localtorrserv"]').insertAfter('div[data-name="torrserver_use_link"]');
						}, 0);
					}
	});
}, 3000) // end TimeOut

 })(); 

