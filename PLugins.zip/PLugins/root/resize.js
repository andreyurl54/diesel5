(function () {
    'use strict';
Lampa.Platform.tv(); 
setTimeout(function() {
	window.resizeBy(1920, 1080);
	Lampa.Noty.show('Resize')
}, 1500);
})();