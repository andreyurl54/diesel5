(function() {
	'use strict';

Lampa.Listener.follow('app', function(e) {
	if(e.type == 'ready') {
		
		var encode1 = 'eyJ0IjoiciIsInYiOiIxLjIiLCJsYW5nIjoicnUiLCJsb2NzIjpb'
		var encode2 = 'XSwic3NvdCI6ImMiLCJzaWNzIjoiZHMiLCJjYmtnIjoiIzQ1NUE2NCIsImNmbnQiOiIjRkZGRkZGIiwiY29kZCI6IiM1NDZFN0EiLCJjb250IjoiI0UwRTBFMCIsInN0b2YiOiIxIn0'
		var citycode = '1789' //639
		const decode1 = window.atob(encode1)
		const decode2 = window.atob(encode2)

		var widget = "<div id='idb664835bf6fe2' style='z-index: 0!important; display: none;' a='" + decode1 + citycode + decode2 + "'>Источник данных о погоде: <a href='https://meteolabs.ru/погода_киев/завтра/'>Киев прогноз погоды на завтра</a></div>"
		var scr_pogoda = "<script async src='https://static1.meteolabs.ru/widgetjs/?id=idb664835bf6fe2'></script>"
		$('body').append(widget)
		$('body').append(scr_pogoda)
		var table = '<div id="pogoda" class="hide" height="70%" style="z-index: 51!important; position: fixed!important; right: 87%; top: 75%;"><table><tr><td class="city" style="text-align: center; color: darkgray; font-size: 22px; font-family: "SegoeUI", sans-serif;"></td></tr><tr style="text-align: center;"><td class="iconcloud"></td></tr><tr style="text-align: center;font-size: xx-large;color: darkgray;"><td class="temp"></td></tr></table></div>'
		$("html").append(table)

		setInterval(function() {
			var chromecastelem = $('.screensaver-chrome')
			if(chromecastelem.length > 0) {
				//setTimeout(function() {
					$('#pogoda').removeClass("hide") 
				//}, 100)
			} else {$('#pogoda').addClass("hide")}
		}, 1000)

		setTimeout(function() {
			var city = document.querySelector(".wlr__name").innerHTML
			var temp = document.querySelector(".wlr__temp").innerHTML
			var icon = document.querySelector(".wlr__icon").innerHTML
			//console.log('город:' + city)
			//console.log('температура:' + temp)
			document.querySelector(".city").textContent = city
			document.querySelector(".iconcloud").innerHTML = '<td class="icon" style=""><svg fill="#565656" height="115px" width="115px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 511.999 511.999" xml:space="preserve"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g> <g> <g> <path d="M223.69,100.079c1.428,1.027,3.078,1.521,4.713,1.521c2.514,0,4.991-1.168,6.571-3.365l18.933-26.332 c2.606-3.625,1.781-8.677-1.844-11.283c-3.626-2.606-8.677-1.782-11.283,1.844l-18.933,26.333 C219.241,92.422,220.067,97.473,223.69,100.079z"></path> <path d="M65.877,205.138c0.465,2.89,1.065,5.783,1.786,8.598c0.935,3.653,4.221,6.081,7.826,6.081 c0.664,0,1.339-0.082,2.011-0.254c4.325-1.107,6.933-5.511,5.826-9.837c-0.598-2.339-1.098-4.746-1.484-7.151 c-6.866-42.756,22.163-83.148,64.71-90.041c23.149-3.749,46.522,3.043,64.135,18.635c3.345,2.96,8.453,2.648,11.412-0.695 c2.959-3.343,2.648-8.452-0.695-11.412c-21.259-18.82-49.485-27.017-77.437-22.488C92.63,104.891,57.6,153.593,65.877,205.138z"></path> <path d="M132.128,73.77c0.638,3.974,4.072,6.804,7.972,6.804c0.426,0,0.858-0.033,1.291-0.104c4.409-0.708,7.408-4.855,6.7-9.263 l-5.149-32.066c-0.708-4.409-4.861-7.407-9.263-6.7c-4.409,0.708-7.408,4.855-6.7,9.263L132.128,73.77z"></path> <path d="M459.243,170.759c-34.291-34.647-79.675-53.727-127.791-53.727c-65.599,0-126.133,35.828-157.981,93.502 c-2.158,3.908-0.739,8.826,3.169,10.985c3.91,2.159,8.827,0.739,10.985-3.169c29.003-52.521,84.115-85.149,143.828-85.149 c43.766,0,85.067,17.378,116.299,48.931c31.455,31.781,48.528,73.673,48.072,117.959 c-0.886,86.143-68.571,157.773-154.092,163.071c-0.64,0.04-10.28,0.332-10.28,0.332h-204.8 c-60.295,0-109.856-49.274-110.479-109.84c-0.305-29.687,11.052-57.768,31.979-79.067c20.771-21.14,48.357-32.901,77.677-33.115 c11.284-0.094,23.008,1.715,34.778,5.344c6.627,2.043,20.513,8.941,24.528,11.463c32.562,20.455,52.001,55.67,52.001,94.202 c0,4.465,3.62,8.084,8.084,8.084c4.465,0,8.084-3.62,8.084-8.084c0-44.127-22.268-84.461-59.567-107.892 c-4.79-3.01-20.062-10.664-28.366-13.224c-13.353-4.116-26.69-6.163-39.66-6.062c-33.648,0.247-65.288,13.725-89.092,37.952 c-23.961,24.385-36.963,56.55-36.614,90.565c0.346,33.683,13.67,65.297,37.515,89.018c23.873,23.746,55.527,36.824,89.131,36.824 h204.8c0,0,12.759-0.185,13.65-0.525c44.602-3.351,86.103-23.093,117.089-55.752c31.639-33.348,49.324-77.076,49.798-123.128 C512.491,251.621,493.758,205.631,459.243,170.759z"></path> <path d="M10,222.286c0.429,0,0.866-0.034,1.302-0.106l31.924-5.172c4.407-0.714,7.402-4.866,6.687-9.273 c-0.714-4.408-4.867-7.402-9.273-6.687L8.716,206.22c-4.408,0.714-7.402,4.866-6.687,9.273 C2.674,219.463,6.104,222.286,10,222.286z"></path> <path d="M31.907,107.861l26.214,19.017c1.434,1.04,3.095,1.541,4.74,1.541c2.502,0,4.969-1.158,6.55-3.338 c2.621-3.614,1.817-8.668-1.797-11.291L41.4,94.774c-3.614-2.621-8.668-1.816-11.291,1.797 C27.489,100.185,28.293,105.24,31.907,107.861z"></path> </g> </g> </g> </g></svg></td>'
			document.querySelector(".temp").textContent = temp
		},5000)

	} //End IF
	
	
	
	
	
	});
})();