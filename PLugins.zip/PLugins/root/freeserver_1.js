(async function() {
	'use strict';
Lampa.Platform.tv();
/* Задаём переменные */
var ipAddress;
var storageCell;
var FreeServ_1
var FreeServ_2
var FreeServ_3
var FreeServ_4
var FreeServ_5
var FreeServ_6

/* Задаём значения адресов серверов, с портом */
var server_1 = 'trs.my.to:8595';
var server_2 = 'tr.my.to:8595';
var server_3 = '176.124.198.209:8595';
var server_4 = 'Trs.ix.tc:8595';
var server_5 = 'Jaos.ix.tc:8595';
var server_6 = 'ts.ozerki.org:8090';

/* Задаём начальные значения списка серверов */
Lampa.Storage.set('FreeServ_1', server_1);	
Lampa.Storage.set('FreeServ_2', server_2);	
Lampa.Storage.set('FreeServ_3', server_3);	
Lampa.Storage.set('FreeServ_4', server_4);	
Lampa.Storage.set('FreeServ_5', server_5);	
Lampa.Storage.set('FreeServ_6', server_6);	

/* Прячем пустые значения серверов: NotFound */
setInterval(function() { 
	var element2Remove = $('.selectbox-item.selector > div:contains("NotFound")');
	if(element2Remove.length > 0) element2Remove.parent('div').hide();
}, 100); //End Interval

//////////////
function checkServer(ipAddress, storageCell) {
  var url = 'http://' + ipAddress + '/echo'; // формирование URL адреса соединения
  var xhr = new XMLHttpRequest();
  xhr.open('GET', url, true);
  xhr.timeout = 1000; // установка таймаута для запроса (1 секунда)
  xhr.send();

  xhr.onload = function() {
    if (xhr.status == 200) {
      console.log('SERVER', ipAddress + ': доступен');
    }
    if (xhr.status == 404) {
      console.log('SERVER', ipAddress + ': НЕ доступен');
    }
  };

  xhr.ontimeout = function() {
    console.log('SERVER', ipAddress + ': превышено время ожидания');
	Lampa.Storage.set(storageCell, 'NotFound');
  };

  xhr.onerror = function() {
    console.log('SERVER', ipAddress + ': ошибка соединения');
	Lampa.Storage.set(storageCell, 'NotFound');
  };
}
//////////////

setTimeout(function() { 
/* Опрашиваем Сервер_1 === резервный метод */
	checkServer(server_1, 'FreeServ_1')
}, 2000)

setTimeout(function() { 
/* Опрашиваем Сервер_2 === резервный метод */
	checkServer(server_2, 'FreeServ_2')
}, 4000)

setTimeout(function() { 
/* Опрашиваем Сервер_3 === резервный метод */
	checkServer(server_3, 'FreeServ_3')
}, 6000)

setTimeout(function() { 
/* Опрашиваем Сервер_4 === резервный метод */
	checkServer(server_4, 'FreeServ_4')
}, 8000)
	
setTimeout(function() { 
/* Опрашиваем Сервер_5 === резервный метод */
	checkServer(server_5, 'FreeServ_5')
}, 10000)

setTimeout(function() { 
/* Опрашиваем Сервер_6 === резервный метод */
	checkServer(server_6, 'FreeServ_6')
}, 12000)


/* Формируем меню после опроса серверов */
setTimeout(function() { //выставляем таймаут для получения правильного значения в меню выбора сервера
	Lampa.SettingsApi.addParam({
					component: 'server',
					param: {
						name: 'freetorrserv',
						type: 'select',
						values: {
						   1: Lampa.Storage.get('FreeServ_1') + '',
						   2: Lampa.Storage.get('FreeServ_2') + '',
						   3: Lampa.Storage.get('FreeServ_3') + '',
						   4: Lampa.Storage.get('FreeServ_4') + '',
						   5: Lampa.Storage.get('FreeServ_5') + '',
						   6: Lampa.Storage.get('FreeServ_6') + '',
						   7: 'Не выбран',
						},
						default: 7
					},
					field: {
						name: 'Бесплатный TorrServer #free',
						description: 'Заменит собой значение в дополнительной ссылке'
					},
					onChange: function (value) {
						if (value == '0') Lampa.Storage.set('torrserver_url_two', '');
						if (value == '1') Lampa.Storage.set('torrserver_url_two', server_1);
						if (value == '2') Lampa.Storage.set('torrserver_url_two', server_2);
						if (value == '3') Lampa.Storage.set('torrserver_url_two', server_3);
						if (value == '4') Lampa.Storage.set('torrserver_url_two', server_4);
						if (value == '5') Lampa.Storage.set('torrserver_url_two', server_5);
						if (value == '6') Lampa.Storage.set('torrserver_url_two', server_6);
						Lampa.Storage.set('torrserver_use_link', 'two');
						Lampa.Settings.update();
					},
					onRender: function (item) {
						setTimeout(function() {
							if($('div[data-name="freetorrserv"]').length > 1) item.hide();
							//if(Lampa.Platform.is('android')) Lampa.Storage.set('internal_torrclient', true);
							$('.settings-param__name', item).css('color','f3d900');
							$('div[data-name="freetorrserv"]').insertAfter('div[data-name="torrserver_use_link"]');
						}, 0);
					}
	});
}, 15000) // end TimeOut



 })(); 