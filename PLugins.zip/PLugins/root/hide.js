(function() {
	'use strict';
Lampa.Platform.tv();

if(window.appready) {
	setInterval(function() {
		var multitarget = $('.icon--history').parent('div').parent('div').parent('div').parent('div')
		$(multitarget).hide()
	}, 30)
	} else {
		Lampa.Listener.follow('app', function(e) {
			if(e.type == 'ready') {
				setInterval(function() {
					var multitarget = $('.icon--history').parent('div').parent('div').parent('div').parent('div')
					$(multitarget).hide()
				}, 30)
			}
		});
	}
})();