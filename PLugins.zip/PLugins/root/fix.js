(function () {
    'use strict';
Lampa.Platform.tv(); 
	setInterval(function() {
		if (!Lampa.Activity.active().component == "my_iptv") {
			$('#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div > div.card__view').css({"padding-bottom": "150%!important;"})
		}
	}, 1000)
})();