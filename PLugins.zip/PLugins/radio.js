(function () {
Lampa.Platform.tv(); 
 'use strict';

Lampa.Keypad.listener.destroy(); 
Lampa.Keypad.listener.follow('keydown', function (e) {
	  var code = e.code;
      // -- if (Lampa.Player.opened()) {
        if (code === 406) {
		  Lampa.Screensaver.stop()
		  console.log ("Заставка выключена");
		  Lampa.Noty.show("Заставка выключена");
        }; 
		if (code === 405) {
		  Lampa.Screensaver.show()
		  console.log ("Заставка включена");
		  Lampa.Noty.show("Заставка включена");
		}; 
        // -- }; 
      });

})();