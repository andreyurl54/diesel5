;(function () {
'use strict';

Lampa.Template.add('notimedatescreen', '<style>.screensaver__datetime{opacity: 0%!important;display: none;}</style></style>');
$('body').append(Lampa.Template.get('notimedatescreen', {}, true));

})();