(function() {
	'use strict';
Lampa.Platform.tv();
Lampa.Template.add('green_style', '<style>.torrent-item.selector.focus{box-shadow: 0 0 0 0.5em #1aff00!important;}</style>');
Lampa.Template.add('greenn_style', '<style>.torrent-serial.selector.focus{box-shadow: 0 0 0 0.3em #1aff00!important;}</style>');
Lampa.Template.add('greennn_style', '<style>.torrent-file.selector.focus{box-shadow: 0 0 0 0.3em #1aff00!important;}</style>');
Lampa.Template.add('greennnn_style', '<style>.scroll__body{margin: 5px!important;}</style>');
Lampa.Template.add('speedd_style', '<style>div.value--speed span{opacity: 0%!important;display: none;}</style>');
$('body').append(Lampa.Template.get('green_style', {}, true));
$('body').append(Lampa.Template.get('greenn_style', {}, true));
$('body').append(Lampa.Template.get('greennn_style', {}, true));
$('body').append(Lampa.Template.get('greennnn_style', {}, true));
$('body').append(Lampa.Template.get('speedd_style', {}, true));

//Lampa.Template.add('timeendd', '<style>div.player-panel__timeend{opacity: 0%!important;display: none;}</style>');
//$('body').append(Lampa.Template.get('timeendd', {}, true));

			})();