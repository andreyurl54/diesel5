(function() {
	'use strict';
Lampa.Platform.tv();

//	var usermailLC = Lampa.Storage.field('account_email').toLowerCase();
//	console.log ("" + usermailLC);
	//localStorage.getItem('account_email');
Lampa.Template.add('green_style', '<style>.torrent-item.selector.focus{box-shadow: 0 0 0 0.5em #1aff00!important;}</style>');
Lampa.Template.add('greenn_style', '<style>.torrent-serial.selector.focus{box-shadow: 0 0 0 0.3em #1aff00!important;}</style>');
Lampa.Template.add('greennn_style', '<style>.torrent-file.selector.focus{box-shadow: 0 0 0 0.3em #1aff00!important;}</style>');
Lampa.Template.add('greennnn_style', '<style>.scroll__body{margin: 5px!important;}</style>');
//Lampa.Template.add('speedd_style', '<style>div.value--speed span{opacity: 0%!important;display: none;}</style>');
//Lampa.Template.add('remove_lang_ua', '<style>body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(2){opacity: 0%!important;display: none;}</style>');
//Lampa.Template.add('tv_style', '<style>#app > div.wrap.layer--height.layer--width > div.wrap__content.layer--height.layer--width > div > div > div.activity.layer--width.activity--active > div.activity__body > div > div.scroll.scroll--mask.scroll--over.layer--wheight > div > div > div > div.card.selector.card--collection.card--loaded.focus > div.card__view > img{box-shadow: 0 0 0 0.4em #fff10d!important;}</style>');
//Lampa.Template.add('no_ua_lang_style', '<style>div.body > div.selectbox > div.selectbox__content.layer--height > div.selectbox__body.layer--wheight > div > div > div > div:nth-child(2) > div{opacity: 0%!important;display: none;}</style>');
//Lampa.Template.add('NaN_style', '<style>body > div.player > div.player-panel > div > div:nth-child(2) > div.player-panel__timeend{opacity: 0%!important;display: none;}</style>');
$('body').append(Lampa.Template.get('green_style', {}, true));
$('body').append(Lampa.Template.get('greenn_style', {}, true));
$('body').append(Lampa.Template.get('greennn_style', {}, true));
$('body').append(Lampa.Template.get('greennnn_style', {}, true));
//$('body').append(Lampa.Template.get('speedd_style', {}, true));
//$('body').append(Lampa.Template.get('remove_lang_ua', {}, true));
//$('body').append(Lampa.Template.get('tv_style', {}, true));
//$('body').append(Lampa.Template.get('no_ua_lang_style', {}, true));
//if (Lampa.Player.opened()) {
//Lampa.Template.add('clock_style', '<style>div.head{z-index: 555!important;}</style>');
//$('body').append(Lampa.Template.get('clock_style', {}, true));
//};
//$('body').append(Lampa.Template.get('NaN_style', {}, true));
//Lampa.Keypad.listener.follow('keydown', function (e) {
//	  var code = e.code;
//		Lampa.Storage.set('start_page', 'last');
        //if (code === 27) { //ESCAPE
//          var usermail = Lampa.Storage.field('account_email').toLowerCase(); //почта пользователя
//		  var diesel_server_selected = Lampa.Storage.field('diesel_source'); //извлекается из меню последством переменной
//		  var diesel_playlist = 'http://45.15.159.227/users/' + usermail + '/' + diesel_server_selected; //полный путь до плейлиста по выбранному серверу (из трёх частей)

//		  Lampa.Storage.set('activity', '{"id":0,"url":"' + diesel_playlist + '","title":"Дизель ТВ","groups":[],"currentGroup":"Russia","component":"my_iptv","page":1}');
//		  console.log ("ESC");
		  //Lampa.Noty.show("ESC");
        //}; 

 //     });


			})();