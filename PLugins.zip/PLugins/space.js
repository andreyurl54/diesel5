	Lampa.Platform.tv();
document.addEventListener("keydown", function(inEvent){

  if (inEvent.keyCode === 32) {
	  Lampa.Player.play;
	  //document.querySelector('.player-panel__playpause.button.selector').click();
  }

});