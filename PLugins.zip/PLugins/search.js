(function () {
Lampa.Platform.tv(); 
 'use strict';
 //ВСЁ РАБОТАЕТ,НЕ ТРОГАЙ, мешают киллеры прослушки клавы в плагинах ТВ
Lampa.Keypad.listener.follow('keydown', function (e) {
	  var code = e.code;
//var app = $('#app').empty();
		if (code === 33) { //404
		  Lampa.Search.open(); //9723 11220
		  $(this).removeClass('focus');
		  $('.search-source.selector').click();
		  //$('.focus').blur();
		  document.querySelector("#app > div.main-search > div > div > div > div > div.search__sources > div > div > div > div.search-source.selector").focus();
		  //$("search-history-key.selector").eq(1).remove();
		  $('boby').find('.search-history-key.selector').eq(1).remove();
		};		

      });
			})();