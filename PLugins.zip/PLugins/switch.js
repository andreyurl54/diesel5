(function () {
    'use strict';

    Lampa.Storage.set('player_hls_method', 'application'); //обработка потока --> системный

		Lampa.Listener.follow('app',(e)=>{
        if(e.type == 'ready'){
			setTimeout(function(){
				$("[1901885695]").eq(0).remove();
			},10); 
        }
    });


});