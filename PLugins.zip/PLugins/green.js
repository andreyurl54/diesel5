(function() {
	'use strict';
Lampa.Platform.tv();
Lampa.Template.add('green_style', '<style>.torrent-item.selector.focus{box-shadow: 0 0 0 0.5em #1aff00!important;}</style>');
$('body').append(Lampa.Template.get('green_style', {}, true));
			})();